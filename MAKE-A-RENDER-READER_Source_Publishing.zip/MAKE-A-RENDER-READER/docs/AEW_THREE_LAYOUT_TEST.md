# Other AEW cards: one-on-one, 2v2 and 4v4

The user subsequently requests every supplied match type after reporting the
smaller five-person test working and six-person returning to portraits. The
[all-layout per-arena experiment](ALL_AEW_LAYOUTS_TEST.md) expands all twenty
provided layout keys. This three-layout ZIP remains a smaller alternative;
it does not contain six-person free-for-all, 3v3 or every other layout.

The [per-arena test ZIP](https://github.com/janeg7207-droid/MAKE-A-RENDER-READER/raw/refs/heads/main/downloads/GorillaStudio_AEW_1v1_2v2_4v4_Per_Arena_Test.zip)
prepares the three requested layouts separately for Redemption, Forbidden Door,
Dynasty, Double or Nothing and optional ROH Supercard. Choose **one arena folder
per trial**. This is experimental input for the user's working Discovery writer,
not a prebuilt CAK or a confirmed loading/playback fix.

| Match layout | Wrestler portrait slots |
| --- | ---: |
| One-on-one (`1on1`) | 2 |
| 2 vs 2 tag (`2on2`) | 4 |
| 4 vs 4 tag (`4on4`) | 8 |

Each project has **14 movie layers**, using 14 shared placeholder movies. Each
individual choice contains 15 BakeMe files: one project plus those movies.
Across the five choices there are 75 input files and 70 movie layers. Four-on-four
means eight participants; fatal four-way uses a different file layout. The game
determines available match modes/menu options. This package creates no new modes.

## Arena scope and source bindings

| Choice under `Tests` | Latest reported card binding | Next check |
| --- | --- | --- |
| `808_Redemption` | Matches original | Actual prepared project/bake and all three gameplay modes |
| `807_Forbidden_Door` | Matches original in newest report | Original project resolves from CAK, then all three modes |
| `805_Dynasty` | Card record absent | Apply current missing-card repair first |
| `806_Double_or_Nothing` | Card record absent | Apply current missing-card repair first |
| `804_ROH_Supercard` | Card record absent | Apply current missing-card repair first |

Those states come from the supplied 2026-10-25 17:35:53 UTC report. Later local
changes must be checked again. [Checker 1.2](CURRENT_ARENA_CARD_LINKS.md) can export
only eligible absent card records from current local tables, preserving existing
custom entries and including an exact backup. Copy its exported `BakeMe/CreateShow`
beside `UI` in the working input when those records remain absent. A correct
project on disk does not supply the missing table record that selects it.

Revolution 803 has a prepared 14-layer source candidate for analysis, but no
Revolution BakeMe input is included in this download. Earlier moving and static
trials had loading failures despite matching references. `HOLD/Revolution_803.txt`
records that dependency. The new 2v2/4v4 layers do not establish a fix for its
existing one-on-one failure. The actual failing baked CAK and affected movie
payloads remain needed for that investigation. The original transition movies,
arena profiles, native plugin and GMRs are unchanged.

## Apply one choice through the working bake

1. Close WWE. Restore and confirm the saved working one-on-one/2v2 CAK first.
   Back up that dedicated CAK **and input** outside the game/bake folders, keeping
   the exact CAK filename. Keep the original arena, character/data CAKs, plugins
   and installed GMRs. The failed all-layout input is not a working baseline.
2. Extract the ZIP into a fresh folder. Make a fresh copy of the saved working
   dedicated matchup input for this trial. Choose one `Tests/<arena>/BakeMe` and
   merge **its contents** into that copy. Keep the working input's existing UI
   projects and any Arena/CreateShow content. The resulting input has sibling
   `Arena`, `UI`, and, when needed, `CreateShow` folders:

   ```text
   WorkingBakeMe/
     Arena/Titavius/<selected arena>/Interface/Matchup/<project>.jsfb
     UI/Assets/movies/gorilla_renders/<14 supplied movies>
     UI/Projects/...                 (retain the working baseline)
     CreateShow/MatchUpScreenAsset.jsfb  (current missing-link export if needed)
   ```

   Put `Arena` beside `UI`. The ZIP root, `Tests`, `HOLD`, reports and original
   table backups must remain outside the actual bake input.
3. Use that complete working-input folder in the **same Discovery entry**, with
   the **same output filename/path**, working WWE 2K26/version-9.9 settings and
   one dedicated matchup patch active. Bake once and fully restart WWE. No
   prebuilt CAK is supplied. Full Studio Game setup would expand the deliberately
   omitted layouts, changing this test; do not run it on this isolated input.
4. In the selected arena, test one-on-one, then 2v2, then 4v4. Every participant
   needs a valid installed logical-ID GMR with Match card enabled; Both screens
   is suitable. Count every moving portrait and verify the match reaches
   gameplay. If an earlier control fails, stop before 4v4. `TEST_MATRIX.csv` has
   one row per arena/layout, including green, portrait-count and gameplay fields.

For rollback, close WWE and restore the saved working CAK under its exact
original filename and the saved input. Restore any loose source table too if it
was manually replaced. Removing loose input alone does not undo a bake. Start
from the saved input for each new arena trial, so an earlier failing override is
not carried forward. A failed trial needs its actual baked CAK and affected GMRs
to investigate paths, routing and alpha; the earlier diagnostic ZIP included no
runtime logs, CAK or movie payloads.

## Verification and remaining limits

Each candidate starts from its supplied original show project with the earlier
two one-on-one layers. Twelve layers are appended for 2v2/4v4. All 61 existing
one-on-one node properties per project remain unchanged. Existing node identities,
background/foreground properties and other non-target layout properties are
retained. Original-prefix changes are limited to twelve extended player child
pointers per project. All fourteen movie references, autoplay flags and exact
slot markers pass the native checks.

Independent managed readonly checks pass for the five supplied candidates and
the held Revolution candidate: 14 valid existing movie layers per project, zero
invalid existing layers, no unsupported schemas and unchanged input bytes. The
remaining 87 slots/placeholders per project are intentionally omitted. All 14
unique placeholder movies fully decode with FFmpeg without errors and match
the already verified native placeholder encoding.

These are checks on source files, not Windows/WWE execution. New 4v4 playback,
loading and every portrait remain **unverified**. Current local customizations
have not been supplied for comparison with the original-source graphics. The
smaller five-person trial result is still pending at packaging time; the full
Dynamite/Collision all-layout expansion remains held after its reported failures.
NOC26/AAA/WWF, Rev SummerSlam and other file layouts remain separate work. See
[exact preparation and independent-check evidence](AEW_THREE_LAYOUT_AUDIT.json).
