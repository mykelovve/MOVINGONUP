# All supplied Titavius card layouts — experimental per-arena rebuild

**Held after the latest user request:** restore the
[smaller five-person checkpoint](FIVE_PERSON_RECOVERY.md). Keep six-person and
larger layouts original for now. The expanded source below is not that rollback.

**Subsequent trial:** the user reports Dynamite 3v3 paused about three seconds,
then showed original photos, without a moving custom clip playing first.
They also confirm that the same combined CAK produces a green/pink five-person
Dynamite card. Keep the previous working smaller bake as the recovery baseline.
The actual uploaded combined CAK now matches all 109 expected payloads byte for
byte, with the correct virtual paths and all six 3v3 movie layers. Runtime
archive priority, selected GMRs and slot replacement remain unverified. These
are failed playback trials, not a confirmed all-mode result. See
[the focused bake/runtime distinction](DYNAMITE_3V3_RUNTIME_TRIAL.md).

The user subsequently requested a single input instead of merging each arena.
The [combined BakeMe UI package](COMBINED_BAKEME_UI.md) contains the same eight
projects and shared movies under one already arranged UI/Arena root. Every
payload byte/path is preserved; this is not a loading fix. The per-arena option
below remains available for isolating an individual show.

The user reports the smaller five-person test was **“perfect”**, then six-person
returned to original portraits, and explicitly requests every match type.
The [all-layout per-arena ZIP](https://github.com/janeg7207-droid/MAKE-A-RENDER-READER/raw/refs/heads/main/downloads/GorillaStudio_Titavius_All_Layouts_Per_Arena_Experimental.zip)
contains every player layout actually found in the eight supplied Titavius
projects. The smaller subsets did not include every six-person layout.

**The earlier full-layout build had green/mixed portraits and loading failures.
That cause is not fixed or established by this rebuild.** The source now starts
from the later five-person subset for Dynamite/Collision and the later three-layout
subsets for other shows. Existing layer properties are retained; a larger active
project can still regress loading. Keep the working five-person CAK and input
as the rollback. The old failed full-layout download stays withdrawn.

## Complete layout coverage

| File layout | Portrait slots |
| --- | ---: |
| One-on-one | 2 |
| Triple threat | 3 |
| Fatal four-way | 4 |
| Five-person free-for-all | 5 |
| Six-person free-for-all | 6 |
| Eight-person free-for-all | 8 |
| 2 vs 2 tag | 4 |
| 3 vs 3 tag | 6 |
| 4 vs 4 tag | 8 |
| 2 vs 3 handicap | 5 |
| 1 vs 2 handicap | 3 |
| 1 vs 3 handicap | 4 |
| 1 vs 4 handicap | 5 |
| 1 vs 5 handicap | 6 |
| 1 vs 6 handicap | 7 |
| 1 vs 7 handicap | 8 |
| Triple-threat tag | 6 |
| Fatal-four-way tag | 8 |
| One-portrait promo layout | 1 |
| Two-portrait promo layout | 2 |

There are **20 file layouts and 101 portrait slots per project**, with up to
eight portraits in a single layout. All supported player groups found in each
source project belong to these twenty layouts; no other groups were found.
The game determines which menu modes exist. Rules that share a listed
project/layout use its layers. A specialty match with a separate UI project,
or more than eight simultaneous portraits, needs separate inspection; the
package does not create those game modes or claim their playback verified.

## Choose one arena scope

The seven choices contain eight projects and 715 BakeMe files:

- `Tests/Dynamite_Collision/BakeMe` — two projects plus 101 shared movies.
- `Tests/808_Redemption/BakeMe`.
- `Tests/807_Forbidden_Door/BakeMe`.
- `Tests/805_Dynasty/BakeMe`.
- `Tests/806_Double_or_Nothing/BakeMe`.
- `Tests/804_ROH_Supercard/BakeMe`.
- `Experimental/803_Revolution_Unresolved/BakeMe` — provided as an explicitly
  unresolved experiment. Prior moving/static Revolution trials failed loading
  despite matching source references. Complete layer coverage does not fix that
  diagnosed failure; its actual failing CAK/movie payloads remain needed.

Single-project choices have 102 inputs. The eight projects contain 808 movie
layers in total. This is not one combined game bake. Choose one scope per trial,
preserving current working inputs rather than merging all seven choices at once.

## Bake through the working entry

1. Close WWE. Back up the **working five-person dedicated CAK and its input**
   outside game/bake folders, retaining the exact CAK filename. Keep original
   arena/character/data CAKs, plugins and GMRs. The prior failed full-layout input
   is not the base for this trial.
2. Extract into a fresh folder. Make a fresh copy of the saved working input.
   Merge the contents of **one chosen `BakeMe`** above into that copy. Preserve
   current working projects and any CreateShow data. `Arena`, `UI` and, when
   required, `CreateShow` are siblings under the actual input root:

   ```text
   WorkingBakeMe/
     UI/Assets/movies/gorilla_renders/   (101 supplied movies)
     UI/Projects/...                    (Dynamite/Collision)
     Arena/Titavius/...                 (other chosen arena)
     CreateShow/...                     (current missing-link export if needed)
   ```

   Keep `Tests`, `Experimental`, instructions, reports, checksums and table
   backups outside the bake input. Put `Arena` beside `UI`, not inside it.
3. [Checker 1.2's local export](CURRENT_ARENA_CARD_LINKS.md) is still required for
   ROH 804, Dynasty 805 and Double or Nothing 806 if those card records remain
   absent. Copy only that export's `BakeMe/CreateShow` beside UI. The package
   supplies no stale or reconstructed replacement user table. Correct project
   files do not provide the data record that selects the branded card.
4. Keep the **same working Discovery entry/output filename/path** and working
   WWE 2K26/version-9.9 settings. Bake once, retain one dedicated matchup patch
   and fully restart WWE. No prebuilt CAK is supplied. Full Studio Game setup can
   import other projects and change the trial's scope; use the existing working
   bake directly.
5. First retest the previously working five-person case and one-on-one/2v2.
   Then try six-person free-for-all, 3v3, triple-threat tag and other available
   modes. Every participant needs a valid installed logical-ID GMR with Match
   card enabled. Count every expected moving portrait and confirm gameplay
   loads. `TEST_MATRIX.csv` covers all eight shows and twenty layouts. An
   unavailable menu option can be recorded as unavailable.

If the working case regresses or loading stalls, close WWE and restore the saved
working CAK under its exact original filename and the saved input. Restore any
manually replaced loose table too. Removing loose input alone does not undo a
bake. Send the actual failing baked CAK and affected GMRs for path, routing and
movie investigation; the earlier diagnostic ZIP contained no runtime log, CAK or
movie payload. Start from the saved input for each new arena trial.

## File evidence and limits

Each project retains all fourteen existing source movie layers and adds the
remaining 87. Dynamite/Collision keeps the prior one-on-one, 2v2, triple-threat
and five-person node properties byte-for-byte at the property level. Other
choices keep the prior one-on-one, 2v2 and 4v4 properties. Every existing node
identity, supplied background/foreground and other non-target property remains
unchanged; original-prefix edits are limited to 87 extended child pointers per
project. Current personal UI customizations have not been supplied for comparison.

Native and independent managed readonly checks pass for all 808 layers, with
zero missing or invalid layers/placeholders, unsupported schemas or input writes.
Every movie hash matches one of the 101 previously fully decoded Bink1
placeholders. The new Dynamite/Collision project bytes differ from the old
withdrawn build because the later five-person source changes append order; the
coverage and layer recipe are the same. **That difference is not an identified
runtime loading fix.**

The exact arena/active CAK for the latest “perfect” five-person report was not
supplied. New all-layout gameplay, all rule variants, native routing, alpha and
transition execution remain unverified. No plugin, transition movie, profile,
GMR or stock global UI replacement is included. NOC26/AAA/WWF, Rev SummerSlam and
automatic alternate-attire routing remain separate tasks. See
[the complete source/check evidence](ALL_AEW_LAYOUTS_AUDIT.json).
