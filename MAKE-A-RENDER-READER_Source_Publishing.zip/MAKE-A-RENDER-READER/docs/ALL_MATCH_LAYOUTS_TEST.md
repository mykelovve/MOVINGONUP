# Every supplied Dynamite and Collision card layout

The user subsequently reports the smaller five-person case working and explicitly
requests every match type. A [new per-arena full-layout rebuild](ALL_AEW_LAYOUTS_TEST.md)
starts from the later subsets and covers all twenty layouts. It is experimental;
the earlier full-layout loading failure remains unresolved. The historical ZIP
below stays withdrawn, and is not relabeled as a proven fix.

**Held after the five-person trial:** the user reports a large green area,
original portraits mixed with rendered ones, and loading stalling or crashing,
despite all five GMRs being set to Both screens. Restore the saved working
one-on-one/2v2 CAK. The full expansion's main-branch ZIP is withdrawn; historical
pinned URLs remain accessible. Use the [five-person isolation test](FIVE_PERSON_MATCHCARD_TEST.md)
to separate this one layout from the full expansion. No all-mode gameplay fix
is claimed by the structural evidence below.

The user confirms **one-on-one and 2v2 work** through the corrected Discovery
bake. The historical all-layout input ZIP
expands those same two projects to every player layout found in them. It keeps
the working Discovery bake method and supplies no prebuilt CAK.

## Coverage

| File layout | Portrait slots |
| --- | ---: |
| One-on-one | 2 |
| Triple threat | 3 |
| Fatal four-way | 4 |
| Five-person | 5 |
| Six-person | 6 |
| Eight-person | 8 |
| 2 vs 2 | 4 |
| 3 vs 3 | 6 |
| 4 vs 4 | 8 |
| 2 vs 3 handicap | 5 |
| 1 vs 2 handicap | 3 |
| 1 vs 3 handicap | 4 |
| 1 vs 4 handicap | 5 |
| 1 vs 5 handicap | 6 |
| 1 vs 6 handicap | 7 |
| 1 vs 7 handicap | 8 |
| Triple-threat tag | 6 |
| Fatal-four-way tag | 8 |
| Promo with one portrait | 1 |
| Promo with two portraits | 2 |

The 20 file layouts contain 101 portrait slots per arena project, with eight
portraits in the largest layout. The package has **two projects, 101 shared
placeholder movies and 103 BakeMe files**, giving 202 movie layers across
Titavius Dynamite 800 and Collision 801. No player groups outside those 20
layouts were found in the two supplied projects.

The game determines which match modes and menu options exist. Eight-person and
other file layouts are included for screens it exposes; this package creates no
new match modes. Rule variations that use the same project/layout receive its
layers. A specialty match with a separate UI project or different layout needs
its own review. These checks do not establish every rule variation's runtime
behavior. Only one-on-one and 2v2 have the user's latest gameplay confirmation;
the exact tested arena was not specified in that confirmation.

## Bake with the working entry

1. Close WWE. Back up the working dedicated matchup CAK **and input** outside the
   game/bake roots, retaining the exact CAK filename. Keep the original arena
   mods/profiles, character/data CAKs, plugins and installed GMRs.
2. Extract into a fresh folder. Select this ZIP's **BakeMe** folder, which contains
   `UI`, as the input of the **same working Discovery bake entry**. Do not select
   `UI` itself or the ZIP root; do not merge old input folders.
3. Keep the **same output filename/path and working WWE 2K26/version-9.9 bake
   settings**. Bake once in Discovery. The 103 supplied files must retain their
   `UI/Assets/...` and `UI/Projects/...` paths. Discovery may also add its empty
   `_textures.tdb`.
4. Keep one dedicated matchup patch active and restart WWE. Do not install an
   additional generated patch alongside the old output. Do not use the withdrawn
   prebuilt CAKs or run full Studio Game setup over this isolated input.

First check one-on-one and normal 2v2. Then try triple threat, fatal four-way,
five- and six-person, followed by the available larger tag/handicap/eight-person
types. For each, verify **every expected portrait moves and gameplay loads**.
Each participant needs a valid installed logical-ID GMR with Match card enabled;
valid existing renders need no new MAKE. `TEST_MATRIX.csv` has one row per layout
for each arena, with blank fields for menu availability, moving portrait count
and gameplay. An unavailable menu choice can remain unavailable.

To roll back, close WWE, move only the generated test CAK outside the game and
restore the saved working CAK under its original filename. Restore its saved
input before another bake.

## Verification

- Starting from the user's working 11-file input, 92 new movie layers are appended
  to each project. The existing one-on-one, 2v2 and triple-threat node properties
  and all nine previous placeholder bytes remain unchanged.
- Original node identities are retained. Original-prefix changes are limited to
  the 92 newly extended player child pointers per project. Background/foreground
  and existing layout properties are preserved.
- Original-engine inspection verifies all 202 references, player markers and
  autoplay values. All 101 placeholder hashes match their virtual paths. The
  49 originally supplied layout movies match byte for byte; the remaining 52
  follow the same measured native encoding.
- An independent managed readonly check recognizes 202 valid layers with zero
  missing layers, missing placeholders, invalid layers, failures or unsupported
  structures. Input bytes remain unchanged.
- All 101 Bink1 placeholder movies fully decode with FFmpeg with no errors.
  ZIP CRCs, all file checksums, the 103 input paths and the 40-row test matrix
  pass their package checks.

New-layout WWE playback remains unverified. The app, native plugin, GMRs,
transitions, arena profiles and other arena projects are outside this artifact.
See [the exact layout, file and preservation audit](ALL_MATCH_LAYOUTS_AUDIT.json).
