# Hand and facial animation follow-up

These findings extend the source audit after the 1.7.22 diagnostic release. No
hand-pose or facial-curve replacement is shipped by that release.

## Too Sweet

The requested taunt is ID 16001 / `16001a000`. Both available raw archive
variants were rechecked with the production body decoder: each has 26 body
tracks, 344 frames at 60 fps, zero finger-joint tracks and zero extra38/extra60
sections. All decoded body transforms are finite. The 38 exact non-stub finger
IDs from the supplied skeleton are absent in both variants.

The native missing-finger fallback supplies a static relaxed hand. It cannot
recreate Too Sweet's authored gesture from these body inputs. The game's
separate hand-pose/event association remains unresolved; this does not mean the
game lacks a hand source. No guessed gesture or animation replacement is shipped.
See [exact variant hashes and decode results](TOO_SWEET_FINGER_AUDIT.json).

## Stone Cold 1

The exact requested taunt is t37255 / 37255a000. Its bundled decode contains 26
body tracks, 206 samples, zero finger tracks and zero supplemental scalar tracks.
All three available raw archive variants also contain 26 tracks and no finger
joints. The native capture builder fills missing fingers with a static relaxed
hand. The game's matching hand-pose/event association remains unverified. This
explains the missing authored point/middle-finger pose in the inspected inputs;
it does not establish that the entire game archive lacks the hand data.

## Adam Cole / Undisputed

All 14 available raw archive variants covering Undisputed 1–6 were decoded again
with the production reader. The seven distinct clips are 62540a000, 62541a000,
62542a000, 62543a000, 16537a000, 17038a000 and 17332a000. The two Undisputed 5
records remain distinct. Every variant has 26 body tracks, no finger-joint tracks
and zero extra38/extra60 scalar tracks. Source SHA-256 values match the archive
evidence. The bundled Undisputed 1, 3 and 4 decodes also contain no finger tracks.

The relaxed-hand fallback cannot recreate the missing authored gesture. A matching
hand-pose/event association remains unproven; these source checks do not establish
that the game has no separate hand data. No Cole model, replacement pose or live
gameplay test was performed, and this is not a shipped hand-animation fix.

## Roar

Roar 1, 37280a000, has no verified matching facial entry in the supplied facial
index. Its correct facial event association remains unresolved.

Roar 2, t62436 / 62436a000, does have indexed male and female facial files with
712 channels and 556 samples, offset zero. The original native capture and
renderer were exercised on the complete supplied Jeff model with its production
181-bone rest. The facial hook mapped 762 morph instances and two jaws. Facial
morphs changed, but the jaw rotation delta was zero during the body motion.

The native hook drives the jaws from au027_u. That channel is zero throughout
the active 221-sample body capture. Its full facial file peaks at only 0.0078125
at sample 291, outside that body window. This reproduces the closed jaw with
these exact inputs. It does not prove a general jaw mapping failure or justify
inventing a roar curve. The correct facial source/event timing still needs to be
established. No user-specific Stone Cold/Roar outfit or live WWE playback was
verified.

Existing native Jeff Hardy finger and We The One facial probes demonstrate that
authored tracks can work when the selected motion supplies matching data. Those
cases do not establish the missing Stone Cold or Roar associations.
