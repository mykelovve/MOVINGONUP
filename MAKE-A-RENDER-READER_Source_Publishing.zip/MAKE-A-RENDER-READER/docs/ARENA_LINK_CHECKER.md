# Check the current arena, card and transition links

The [arena link checker ZIP](https://github.com/janeg7207-droid/MAKE-A-RENDER-READER/raw/refs/heads/main/downloads/GorillaStudio_Arena_Card_Transition_Checker.zip)
checks all eight supplied Titavius shows: Dynamite, Collision, Revolution, ROH
Supercard of Honor, Dynasty, Double or Nothing, Forbidden Door and Redemption.
It is a separate read-only Windows tool, with no application update or bake.

**Version 1.2** adds an optional **Export missing card links…** action. It writes
a repaired table and exact original backup to a new Desktop folder while
leaving the selected Discovery data unchanged. The newest supplied report has
three absent card records: ROH Supercard, Dynasty and Double or Nothing. Their
arena/movie links match; Forbidden Door's links are now present. See
[the current findings and repair steps](CURRENT_ARENA_CARD_LINKS.md). Exporting
does not install a fix or add moving layers; applying the exported table needs
the explicit working-bake steps in that guide.

**Version 1.1** adds a path box, Enter-to-check, file/folder drag-and-drop and a
remembered last folder. **Browse file…** uses the normal Windows file picker with
an address bar, replacing the old folder tree. The usual Steam data location is
prefilled on first use if it exists; custom drives can be pasted directly.

1. Extract the ZIP and run `GorillaArenaLinkChecker.exe` on Windows with .NET
   Framework 4.8, the framework already used by Studio.
2. Save any Discovery edits. Paste the **full data root containing `Arena`,
   `CreateShow` and `Movies`** into the path box and press **Enter** or **Check**.
   Alternatively, drop the folder or any of the three table files onto the box,
   or select a table through **Browse file…**. The tool resolves the table's data
   root automatically. Quoted File Explorer paths and environment variables are
   accepted. The dedicated Dynamite/Collision `BakeMe` folder intentionally lacks
   those tables and is not the data root for this check.
3. Click **Open report folder**. The tool creates a new
   `GorillaStudio-Arena-Check-…` folder on the Desktop, containing
   `arena-links.txt`, `.csv` and `.json`. Send `arena-links.txt` to diagnose the
   current bindings. It includes the selected local path and file hashes; it
   does not collect credentials, plugin configuration or unrelated files.

The last successfully read folder is saved to
`%LOCALAPPDATA%\GorillaStudio\ArenaLinkChecker\last-discovery-root.txt` and
restored on the next launch. It stores only the selected local path. Folder
resolution checks nearby parent folders without recursively searching drives.
Reports and this preference are written outside game/Discovery data; the game
and bake files remain unchanged.

The checker reads the binary files Discovery bakes:

- `CreateShow/MatchUpScreenAsset.jsfb`: the show's actual matchup project hash.
- `Arena/ArenaData.jsfb`: its actual transition movie ID.
- `Movies/MovieDataTable.jsfb`: the movie record selected by that ID and its
  actual asset hash.

Each is compared with the exact supplied original profile. Changed IDs are
followed to their actual current movie records, rather than silently checking
the expected movie instead. Duplicate records, zero links, missing records and
unreadable tables remain distinct. Exact virtual paths and unsigned 64-bit hash
values are retained. A full JSON export is never substituted for an incomplete
binary table. This matters when edits were exported but not saved to the binary
data that is being baked.

Loose projects and transitions receive separate header/path checks. A file not
extracted into this folder may still be inside a CAK; the checker does not call
it missing from the installed game. A header check cannot establish decoding or
in-game playback. It does not inspect archive priority, the currently winning
bake, game hooks or transition execution. A link differing from the supplied
profile may be an intentional customization and is not automatically repaired.
IDs remapped from the supplied profile require reviewing those current records.

## Evidence and scope

In the **earlier uploaded metadata**, all eight card links and all eight expected
transition movie records match the supplied source, but the binary arena table
lacks IDs **804, 805, 806 and 807**: ROH Supercard, Dynasty, Double or Nothing and
Forbidden Door. The separate Arena JSON includes more records. This is a
concrete mismatch in that earlier copy, not evidence that those records remain
missing from the user's current setup, nor proof of the Revolution loading
failure's cause. Revolution's three binary references match in that earlier
copy; its active bake/runtime still needs investigation.

The original pack contains all eight projects and transitions. All transitions
were extracted and their headers checked. Dynamite/Collision Bink1 movies fully
decode with FFmpeg; the other six KB2n movies exceed the available decoder's
support and were not fully decoded. See [the original-source audit](MOD_ARENA_CARD_LINKS.md).

The checker package contains **no game assets, replacement tables, profile
imports, plugins, CAKs or BakeMe input**. It preserves the working
Dynamite/Collision bake. The [held all-layout test](ALL_MATCH_LAYOUTS_TEST.md)
targets those two cards only; this checker does not add moving layers to
other arenas or establish new match-type gameplay support.

Nineteen parser/relationship checks pass against copies of the supplied binary
metadata, including edited IDs, duplicate records, full-width hashes, malformed
tables, stale JSON, incorrectly rooted assets and inconsistent movie lengths.
The Windows executable builds with no warnings. Windows GUI execution and game
playback have not been tested here. Source and reproducible packaging are in
`tools/GorillaArenaLinkChecker` and `tools/package_arena_link_checker.py`.

For automated use, a new report folder outside the checked data is required:

```text
GorillaArenaLinkChecker.exe --check "C:\path\discovery_data" "C:\path\new-report-folder"
```
