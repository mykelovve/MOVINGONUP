# Current arena match-card results

These results cover the supplied reduced one-on-one projects. User-reported
game results are separate from the source and package checks performed here.

| Arena / match | Latest user result | Meaning |
| --- | --- | --- |
| Dynamite / one-on-one | Moving portraits and gameplay | Confirmed in the user's reduced baseline setup. |
| Collision / one-on-one | Moving portraits and gameplay | Confirmed in the user's reduced baseline setup. |
| Redemption / one-on-one | User reports it worked | New positive user result; not a local game test. |
| Revolution / one-on-one | Moving portraits; loading stops near 3%. Same bake reportedly still stops with playback plugins removed. | Playback plugins are not required to reproduce the reported stall. Cause unresolved. |
| Revolution / original static-card control | Card appears, then loading crashes | Diagnostic withdrawn; restore the prior working backup. Cause unresolved. |
| Dynasty / one-on-one | Default matchup card appears | Correct custom-card selection/loading is unverified. Cause unresolved. |
| Other supplied arenas / one-on-one | No individual gameplay confirmation | Package/structure checks only. |
| Triple threat / earlier one-on-one pack | No moving matchup portraits | Expected for the earlier one-on-one-only downloads. |
| Latest basic-pack one-on-one report | Still portraits; DLP restored and enabled 1 reported | Arena/participants and active baked output remain unidentified; this is not yet a confirmed regression in the two patched arenas. |
| New scoped tag/triple experiment | User reports selection moves but matchup cards stay static, including one-on-one | Shared match-card playback is unresolved; no tag/triple success is claimed. |

The combined download is not a confirmed working setup for Revolution or Dynasty.
Keep the working Dynamite/Collision test input and CAK backed up outside the game.
The earlier full-layout pack remains withdrawn.

## Revolution package audit

The published combined add-on contains:

`Arena/Titavius/803_-_AEW_Revolution_2026/Interface/Matchup/matchup_aewrevolution_26.jsfb`

- Original project SHA-256:
  `f490948561894e5dbd3ebb22ebc40dd47adf5e2b175421546256c43c2fd5658a`.
- Packaged reduced project SHA-256:
  `b3eb0425167d3ee15b7a24f77d41114c607cdd15159339060eb2b44a4d69038a`.
- The supplied arena profile's project hash is `FBD326AF3588DB9E`, matching the
  canonical path and original archive index.
- Exactly two moving slots exist, at `matchup/1on1/1P/GM_clip` and
  `matchup/1on1/2P/GM_clip`. Both use the expected shared placeholder, native
  player marker and autoplay flag. No other GM clip was added.
- Original-prefix changes are limited to the two player child-vector pointers.
  Background properties are unchanged; both the background and transition
  references resolve in the supplied original mod archive.
- The four user-confirmed Dynamite/Collision inputs are byte-identical to the
  working baseline. No native plugin, GMR or character mapping was changed.

This audit does not inspect the active user CAK, establish actual override
priority, decode the game's current card videos or establish a stall cause.
No WWE execution took place here. Moving portraits alone do not prove a match
can reach gameplay. A similar visible loading percentage does not prove the
same cause as the earlier Dynamite/Collision stall.

## Plugin-unloaded control: reported result

1. Close WWE completely.
2. Temporarily move `WWE2K26_MovingRenders.dlp` out of the game's `Plugins`
   folder. If `WWE2K26_SelectionLoop.dlp` is installed, move that out as well.
3. Keep the current Revolution bake, arena, wrestlers and attires unchanged.
   Do not rebake or alter profiles for this test.
4. Restart WWE and repeat that same Revolution match.

The user answered **"Still stops near 3%."** This is a user-reported control,
not independently observed execution. It keeps the bake while unloading the
playback-plugin family; the plugin is therefore not required for this reported
reproduction. Bake/assets and other runtime factors remain under investigation.
This result does not establish that an arena, model or video is corrupt.

## Original Revolution card control: withdrawn

The static control restored the exact original Revolution project and retained
the other eleven combined inputs. Its source/payload/structure checks passed, but
the user reports **the card appears, then loading crashes** and requests the
previous setup. The main-branch diagnostic ZIP/checksum are removed. Historical
pinned downloads cannot be revoked; do not use them as repairs. This report does
not establish whether the active bake, original project/assets or other runtime
data caused the crash. Restore the known-working dedicated test CAK/input backup
and previous plugin locations/state with WWE closed.

## Reconstructing the successful Dynamite/Collision recipe

The native patch algorithm reproduces the exact successful Dynamite and Collision
SHA-256 values. It also reproduces the existing published Revolution, Dynasty
and Redemption moving-project bytes. Each has two GM clips, unchanged CAS dummy
properties and only the intended SS marker-scale changes. Actual changes in the
original file prefix are four bytes within the two player child-vector pointers.
The appended nodes differ in absolute offsets because the source projects differ.
See [the exact comparison](DYNAMITE_COLLISION_RECIPE_AUDIT.json).

The successful user test also changed bake scope: four UI-only inputs instead of
the earlier large full-data/full-layout bake. The later combined expansion has
twelve inputs and ten projects. The original success therefore does not establish
that movie count alone was the cause, nor does source equality prove the current
game is using those bytes. The actual failed user CAK remains unavailable here.

## Minimal moving Revolution test

`GorillaStudio_Revolution_1v1_Minimal_Test.zip` has exactly the four unchanged
Dynamite/Collision inputs plus Revolution's unchanged two-slot moving project.
This repeats the narrow bake recipe with only one added arena. Five inputs,
three projects and six existing movie slots pass readonly checks; the other 297
full-layout slots and 99 placeholders are intentionally omitted. No repair is
applied by that checker. The stable app, plugins, GMRs and profiles are unchanged.

Restore the known-working setup first. For the optional test, back up the working
input and dedicated generated test CAK outside the game. Move that old generated
output out before rebuilding to prevent leftover entries. Use the fresh complete
BakeMe, both Arena and UI, and the SAME dedicated output filename. Keep original
mod archives and unrelated CAKs intact. Use the previous working moving-plugin
state; do not mix this with the plugin-unloaded static control. Do not run full
Studio Game setup. This tests scope/fresh output, not a new Revolution serializer
fix, and its runtime result is pending.

The user requested multi-man matches after resolving the current arena issues.
That is the next scope; no new tag-team or triple-threat support is claimed here.

The user lifted the UIFIXES hold. All 30 volumes were downloaded, and 133 selected
JSFB files were extracted with their individual CRCs verified. The archive has
2,208 files and 3,157,604,586 uncompressed bytes, mostly arena assets/textures and
videos. Only `NOC26/matchup.jsfb` is a matchup project; no Dynasty/Revolution
project/profile or `CreateShow/MatchUpScreenAsset.jsfb` is supplied. That NOC26
project has zero GM clips and its background reference is not in this upload;
the asset may depend on the base game or another archive. No missing arena ID
or profile assignment is guessed. See [the upload audit](UIFIXES_AUDIT.json).

## Separate tag / triple-threat experiment

The user renewed the multi-man request. Separate optional test files now add
normal 2v2 tag and triple-threat movie layers to Dynamite/Collision, with a second
choice adding Redemption. Each project has nine slots: the existing two one-on-one
slots, four tag and three triple. All prior one-on-one node properties are retained.
Game loading and moving portraits for these new layouts remain unverified; the
current basic still-picture report is not claimed fixed by this experiment.

The user confirms that the current still-picture test had two wrestlers, with the
DLP restored and enabled 1. The basic ZIP still matches its original hash and
has four inputs for Dynamite/Collision only. The actual tested arena/participants
are pending, so testing a different arena remains a possible scope mismatch.
The active user CAK and running hook have not been inspected. Keep that current
bake unchanged while collecting the exact run report/log. See
[the scoped test instructions](TAG_TRIPLE_MATCHCARD_TEST.md).

The latest multi-man trial still shows motion only in selection and static
matchup cards even in one-on-one. A whole-package comparison of seven releases
confirms the basic four inputs exactly match the original successful diagnostic.
The tag/triple experiment adds seven movie nodes and placeholders per project;
its retained one-on-one properties do not establish runtime equivalence.

Before 1.7.24, installed-render bulk Show on defaulted to selection-only.
Applying it could remove match-card eligibility while retaining selection motion.
The user reports the checked row already shows Both screens, so selection-only
does not explain that render. Its metadata and the actual current bake/log have
not been read directly here. Version 1.7.24
defaults to Both screens. That is a specific workflow fix, not a
confirmed diagnosis or an automatic repair of installed GMRs. The existing 36
transaction checks and a zero-warning helper build pass. Native plugins remain
unchanged. See [the comparison](MATCHCARD_REGRESSION_AUDIT.json).

The received diagnostic finds 59 header-compatible root GMRs, original 4.21,
enabled/verbose 1, no selected GMR and zero runtime logs. It checks the main
Discovery data with 13,433 slots and 91/91 linked projects found, not the limited
test input. This does not establish the loaded CAK. Version 1.7.24 removes the
automatic Game setup calls after both normal and batch installation; explicit
setup remains available. Existing expanded input/bakes still need restoration.
See [the install/setup regression](INSTALL_UI_SETUP_REGRESSION.md).
