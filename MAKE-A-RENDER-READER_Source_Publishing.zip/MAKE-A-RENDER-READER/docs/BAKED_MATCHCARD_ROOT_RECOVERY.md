# Dynamite and Collision bake path repair

The received `TITAVUSREVATCHCARD-20261024-173411.cak` contains the exact two
projects and two placeholder movies from the previously working one-on-one
recipe, but all four are stored without their required `UI/` prefix.

| Received archive path | Required game path |
| --- | --- |
| `Assets/movies/gorilla_renders/ph_L00_1P.bk2` | `UI/Assets/movies/gorilla_renders/ph_L00_1P.bk2` |
| `Assets/movies/gorilla_renders/ph_L00_2P.bk2` | `UI/Assets/movies/gorilla_renders/ph_L00_2P.bk2` |
| `Projects/ShowAssets/matchup/AEW_Collision_2026.jsfb` | `UI/Projects/ShowAssets/matchup/AEW_Collision_2026.jsfb` |
| `Projects/ShowAssets/matchup/AEW_Dynamite_2026.jsfb` | `UI/Projects/ShowAssets/matchup/AEW_Dynamite_2026.jsfb` |

Paths determine archive asset hashes. The received project hashes are
`DB33FD46EBF28CFC` and `AC73E07EF80E28DB`; the original arena index expects
`B9684E1CC73CF513` and `2380C945533596CA`. Consequently this bake does not replace
those arena projects. Renaming the CAK cannot correct its internal paths.

The prefix loss is consistent with baking the contents of `UI` as the input
root. The resulting archive demonstrates the path error; the user's exact
Discovery input selection was not observed.

## Use the working Discovery bake

The user corrected the folder structure in Discovery and reports returning to
the working setup. Retain that Discovery writer, entry settings and exact
output filename for subsequent tests. Keep the original arena CAKs installed.

The separately prepared `gs_aew_1v1_paths.cak` is now **held** and its main-branch
download was removed. It shares the writer format of the later prebuilt multi-man
test, which the user reports also lost one-on-one playback. The one-on-one-only
prebuilt file has no independent user runtime result; it is not claimed to have
the same failure. Historical pinned downloads remain accessible.

For the next multi-man test, use the [11-file BakeMe package and working Discovery
bake workflow](READY_MULTIMAN_MATCHCARD_TEST.md). Close WWE, remove the prebuilt
`gs_aew_tag_triple.cak`, back up the working dedicated CAK/input outside the game,
and rebuild that same working output from a fresh complete BakeMe. Keep original
arena mods/profiles, character/data and installed GMRs in place.

## Correct manual bake input

The input must be the parent folder containing `UI`:

```text
BakeMe/                  <- Discovery input
  UI/
    Assets/
    Projects/
```

After baking, CakeView must list `UI/Assets/...` and `UI/Projects/...` inside the
CAK. Selecting `BakeMe/UI` strips the required prefix. Keep the original arena
CAKs installed, use WWE 2K26/version 9.9 and Regular type, and back up the previous
dedicated output outside the game before rebuilding it. Do not run full Studio
Game setup over this reduced four-file input.

## Verification

The single uploaded 7z part is complete. Its start and next-header CRCs pass;
the contained CAK was extracted without an archive error. A local compatibility
correction was required for a boundary error in the original v9.9 reader's hash
routine. All five encrypted metadata section checksums then passed and all four
extracted payload SHA-256 hashes matched the earlier working recipe exactly.
The original upload was preserved.

The held prepared replacement was indexed and fully extracted with the **unmodified
original Bakery.CLI 2.0.1**. All four extracted payloads again match the working
recipe byte for byte, and both project hashes match the original arena index.
These checks establish the archive's paths and payloads, not in-game playback.
See [the measured audit](RECEIVED_BAKED_MATCHCARD_AUDIT.json).
