# Batch speed and alternate-attire routing follow-up

This is a source review for the user's secondary requests while the multi-man
runtime test proceeds. It ships no batch-performance or attire-switching fix.

## Batch preparation

The current batch loop awaits model/attire loading and the original MAKE command
for each job. Each job refreshes its Discovery attire selection, resolves its
sources, prepares its roster pictures and compatibility alias, waits for native
preparation and then runs MAKE in an isolated output folder. Picture lookup can
walk the selected Discovery directory. Some picture/alias file work occurs after
returning to the dispatcher. The native preparation key uses folder, logical ID
and taunt; each next wrestler changes that key.

These are concrete candidates for a measured optimization: reuse one validated
batch-level picture inventory, keep shared taunt preparation reusable across
characters, and move eligible file preparation off the dispatcher. Existing
model/texture caches already have source/revision checks and should be measured
before assuming they are recreated. A useful change needs per-stage times on a
real repeated batch, plus correct invalidation when mappings, models, textures
or attire choices change. Parallel MAKE calls cannot safely share the current
window/output state. No faster timing or percentage is claimed by this review.

Source locations: `BatchRosterUI.BatchLoadCharacterAsync`, its per-job loop,
`DiscoveryRenderBridge.PrepareRenderImages`, `DiscoveryRenderImages.Scan`,
`DiscoveryLivePictureBridge` and the original native preparation/MAKE calls.

## Multiple attire files versus runtime switching

Studio already plans separate saved GMRs for multiple selected attires using the
same taunt. The current native playback plugin is keyed by logical wrestler ID;
it suppresses duplicate primary/alias ID claims before applying screen filters.
Saving two outfit movies therefore does not make them automatically switch
when a different costume is selected in the game.

Discovery's costume metadata provides an exact costume key/index and model hash.
The current SelectionLoop range consumer passes only wrestler ID, segment start,
end, freeze and segment address; it exposes no verified selected-costume field.
The next runtime piece requires a verified selected-costume value and a route
keyed by logical ID plus costume identity. No guessed memory offset or native
plugin rewrite was made. The one-active-GMR installer rule remains necessary
for the current plugin.

The available older Discovery metadata lists eleven active costumes each for
CM Punk 312 and Jeff Hardy '02 695, but their exact mapped alternate-model files
are absent from the supplied character pack. Punk's physical 312 default belongs
to another logical profile and cannot prove those eleven mapped outfits exist.
The two missing Demon Finn 626 references are also absent from that upload.
The prior source-folder wrapper refresh fix is already included; these older
counts do not establish which local PC folders are available today.

This review preserves the active multi-man test's application, plugin, GMRs and
character mappings. Runtime attire switching and any batch speed improvement
remain separate implementation/validation work.
