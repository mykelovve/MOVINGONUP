# One combined BakeMe UI folder

**Held after the latest user request:** use the
[smaller five-person recovery](FIVE_PERSON_RECOVERY.md) now. This full-layout pack
is not the recovery input and must not be merged into it.

**Latest runtime reports:** Dynamite 3v3 paused about three seconds, then displayed
original photos. The user also confirms that the same CAK gives a green/pink,
mixed-portrait five-person Dynamite card. Keep the previous working smaller
bake as the recovery baseline; this combined pack has failed playback trials.
The actual uploaded CAK has now been extracted: all 109
payloads match this ZIP byte for byte, including the six 3v3 movie layers and
correct virtual paths. Runtime archive priority, selected GMRs and replacement
remain unverified; the cause is unresolved. See
[the focused investigation](DYNAMITE_3V3_RUNTIME_TRIAL.md).

The [combined BakeMe UI ZIP](https://github.com/janeg7207-droid/MAKE-A-RENDER-READER/raw/refs/heads/main/downloads/GorillaStudio_Titavius_All_Layouts_Combined_BakeMe_UI.zip)
puts all previously supplied Titavius card projects and shared movies into one
input. No arena-by-arena file merging is required:

```text
BakeMe/
  UI/
    Assets/movies/gorilla_renders/   (101 shared movies)
    Projects/ShowAssets/matchup/     (Dynamite and Collision)
  Arena/Titavius/                    (the six other card projects)
```

`UI` contains both Assets and Projects. The other six projects keep their
original `Arena/Titavius/...` paths beside UI; moving them under UI changes
their virtual references. The package has **109 input files**: eight projects
and 101 unique shared movies. It removes 606 redundant movie copies from the
per-arena ZIP without changing any payload byte or virtual path. The eight
projects retain all twenty layouts/808 portrait movie layers.

1. Close WWE and back up the **working five-person dedicated CAK and input**
   outside game/bake folders, retaining the exact CAK filename. Keep original
   arena/character/data CAKs, plugins and installed GMRs.
2. Extract into a fresh folder. The UI/Arena project files are already arranged.
   If the previous working input contains `CreateShow` or other required current
   custom data, copy that data into this BakeMe once so rebuilding the same
   output does not discard it. Keep original/backup folders outside BakeMe.
   [Checker 1.2's current local export](CURRENT_ARENA_CARD_LINKS.md) is still
   needed where ROH 804, Dynasty 805 or Double or Nothing 806 card links remain
   absent. Copy only its exported `BakeMe/CreateShow` beside UI here.
3. Select this **BakeMe folder containing both UI and Arena** in the same
   working Discovery entry. Keep the same output filename/path and working
   WWE 2K26/version-9.9 settings. Bake once, retain one dedicated matchup patch
   and fully restart WWE. Select the parent BakeMe, rather than UI, Assets or
   the ZIP root. Use the working bake directly; full Studio Game setup can import
   additional projects and change this scope.
4. Retest the working five-person case before other modes. Each participant
   needs a valid logical-ID GMR with Match card enabled. Confirm every expected
   portrait moves and gameplay loads.

This is **packaging only**. It includes the unresolved Revolution project and
does not fix its earlier loading failures or the earlier full-layout failures.
Gameplay remains experimental. For rollback, close WWE and restore the working
CAK under its exact original filename and the saved input. Restore any manually
replaced loose table too. Removing loose input alone does not undo a bake.

The combined input passes independent readonly checks: eight projects, 808 valid
movie layers, zero missing/invalid layers or placeholders, no unsupported schemas
and unchanged bytes. All source file hashes are preserved. See
[combined-file checks](COMBINED_BAKEME_UI_AUDIT.json) and
[full-layout coverage and runtime limits](ALL_AEW_LAYOUTS_TEST.md).

The user requested the finger/mouth indicators for an application update and
only the combined input now. No app update, animation guide or indicator UI is
included in this archive; the feature is recorded in [queued updates](QUEUED_UPDATES.md).
