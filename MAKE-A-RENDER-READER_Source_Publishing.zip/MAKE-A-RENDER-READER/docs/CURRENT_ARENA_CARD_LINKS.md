# Current supplied arena-link reports

**Newer received-CAK evidence:** the uploaded `discovery_data.cak` contains 181
card rows, 303 arena rows and 7,329 movie rows. All eight expected card records
are present; Revolution 803 and Forbidden Door 807 lack arena rows in that
baked table. The earlier three-missing-card export below is not indicated for
this snapshot. The user has restored a different working CAK, so this upload
does not establish the currently running data. See
[the received archive audit](RECEIVED_DISCOVERY_STARTUP_AUDIT.md).

The remaining report describes the earlier loose-data snapshot.

The newer report is dated **2026-10-25 17:35:53 UTC**. Its JSON, text and CSV
agree. It checks the selected full Discovery data folder, with 173 card records,
308 arena records and 7,307 movie records, and no parser warnings. These are
loose data checks, not proof of the active game bake.

| Show | Card record | Arena transition / movie references |
| --- | --- | --- |
| Dynamite 800 | Matches original | Match |
| Collision 801 | Matches original | Match |
| Revolution 803 | Matches original | Match |
| ROH Supercard 804 | **Absent** | Match |
| Dynasty 805 | **Absent** | Match |
| Double or Nothing 806 | **Absent** | Match |
| Forbidden Door 807 | Matches original | Match |
| Redemption 808 | Matches original | Match |

Forbidden Door's card and arena record were absent in the 17:34:27 UTC report
and are present in the newer one. The three other absent cards are unchanged.
This supersedes assumptions drawn from the much older uploaded metadata, which
had the inverse problem of more card rows and fewer arena rows.

The absent card records identify a missing binding for the three branded cards;
they are not evidence of missing transition movies. All eight expected movie
records match their source hashes. No transition is loose in the selected root;
the original movies can remain in `titavius_aew_2026.cak`. Revolution and
Redemption have matching card/arena/movie references and loose Scre project
headers. Their reported runtime issues require examining the actual baked card,
archive priority and movie playback, not replacing those IDs on this evidence.

Separate [one-on-one/2v2/4v4 source tests](AEW_THREE_LAYOUT_TEST.md) are now available
for the other five arena choices. They need these repaired bindings where absent
and their actual baked override selected in-game; they do not replace this table
repair or establish new gameplay support.

## Export a repair from current local data

The [checker 1.2 ZIP](https://github.com/janeg7207-droid/MAKE-A-RENDER-READER/raw/refs/heads/main/downloads/GorillaStudio_Arena_Card_Transition_Checker.zip)
adds **Export missing card links…** after a check. It rereads the current binary
tables and exports a repaired table plus an exact original backup to a new
Desktop folder. It does not modify the selected data folder. Given the newer
report's state, the planned additions are only **804, 805 and 806**, for
**173 → 176 records**. Changes made since that report are checked again locally.

Only absent cards whose actual arena transition and movie references match the
supplied profile are eligible. Existing cards, including zero/different hashes
and duplicates, are never overwritten. An absent arena or unreadable source
table blocks the corresponding repair. Each new card preserves its exact
original project hash, common movie hash, secondary ID and template strings.

The exporter changes one root-vector pointer in its output and appends a new
vector, a byte-identical copy of all existing source payloads, and the new rows.
Existing rows keep their order, every unknown row field and referenced byte
survives, and other root fields retain their original references. This avoids
reconstructing the user's custom records from the summary report. The repaired
table is larger because the original payload copy is retained.

1. Run the new checker against your full data root, then click **Export 3 missing
   card link(s)…** if those records remain absent. Open the generated repair folder.
2. Close WWE. Back up the working dedicated matchup CAK and its input outside the
   game/bake folders, preserving the exact CAK filename. Copy **only the exported
   `BakeMe/CreateShow`** into that working input **beside `UI`**:

   ```text
   WorkingBakeMe/
     UI/                    (keep existing working files)
     Arena/                 (keep it if already present)
     CreateShow/
       MatchUpScreenAsset.jsfb
   ```

3. Keep the same working Discovery entry/output filename and working WWE
   2K26/version-9.9 settings. Bake once and fully restart WWE, with one dedicated
   matchup patch active. Do not run full Studio Game setup on the isolated input.
   Keep the original Titavius arena CAK and arena/movie records installed. Do not
   bake the whole export folder or its `Original` backup.
4. Check the three affected branded cards individually. The export repairs their
   references only; it supplies no moving-render layers or transition changes.
   Original-source card projects may still be static until their specific moving
   layers are installed and verified. If a card still falls back, provide the
   actual newly baked CAK for path/reference/override inspection.

If the full data root is your editing source, back up its current table outside
that root and copy the same repaired `CreateShow/MatchUpScreenAsset.jsfb` there
too, before further edits. The exported README records source hashes so later
edits are not silently replaced. Checking that source again can verify the added
records; checking it before copying the export will still report them absent.

Rollback restores the saved working CAK under its exact original filename and
its saved input. Restore the loose original table too if it was replaced.
Removing loose inputs alone does not undo a bake.

Twenty-six repair checks pass using a 173-row fixture derived from earlier
supplied binary data and the newest report's missing-ID pattern. It is not the
user's current binary table, which has not been uploaded. Tests cover complete
payload preservation, 173 → 176 records, exact original labels/uint64 hashes,
idempotence/refusal, source immutability, backup protection and metadata guards.
The Windows executable builds with zero warnings. Windows repair UI execution
and in-game results remain unverified. See [test evidence](CARD_LINK_REPAIR_TESTS.json)
and [the sanitized current-report comparison](CURRENT_ARENA_CARD_LINKS_AUDIT.json).
