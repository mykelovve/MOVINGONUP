# Combined-pack failures: Dynamite 3v3 and five-person

**Post-activation result:** the user-supplied log reports the capacity companion
ACTIVE, with sampled counts of 4 and 15. Green/pink corruption remains and the
user reports another 3% loading stall. The supplied CM Punk ROH movie has correct
both-screen metadata and all 112 frames fully decode in FFmpeg with intact
alpha; this is not verification with the game's own Bink decoder or GPU.
CakeHook committed 82 of 84 discovered archives and repeatedly reports two
pending archives without filenames. No specific archive can be blamed from
that report. See [the new evidence](CM_PUNK_ROH_POST_ACTIVATION_AUDIT.json).

The [capacity companion](MATCHCARD_CAPACITY_TEST.md)
reproduces and corrects a native defect where a seventeenth opened movie evicts
the first tracked context. Its 120-entry table, all readers and visibility scan
pass native and Wine host tests. This is a separate runtime change; it requires
no new UI bake. Its successful activation has not established a fix for the
reported screenshot or stall.

**Follow-up:** the user confirms that `Screenshot 2026-10-25 150505.png` uses
the same combined CAK inspected here. Its five-person Dynamite card has a large
green area, faint portraits and a pink region at the right edge. Five-person
therefore also has a visible failure with this bake. A still image does not
establish whether portraits move or gameplay loads.

The user reports that the screen pauses for approximately three seconds and
then displays the original photos. They explicitly distinguish this from a
custom render playing first and then freezing. The outcome after the card
(gameplay loading or failure) was not supplied in this report.

This behavior is not evidence of the intended play-once/flash-freeze result,
which would retain the final frame of the custom animation. It directs the
investigation toward loading and slot replacement but establishes no specific
native, movie or bake cause.

## Confirmed in the published input

The combined input ZIP has SHA-256
`59be059852b5227bf39ac0a2c53558e2059e09af22bd8a2838bf88dc0a0a3b82`.
Its Dynamite project is at
`UI/Projects/ShowAssets/matchup/AEW_Dynamite_2026.jsfb`.

All six `matchup/3on3/<player>P/GM_clip` layers are present. Each has the expected
movie type, autoplay flag, `ph_L09_<player>P.bk2` hash, encoded placeholder rate
and exact static-picture scale marker. The movie leaf properties use the same
recipe as the five-person movie layers. All 145 five-person node properties
from the smaller five-person source remain unchanged. Missing 3v3 movie layers
therefore do not explain the failure **in this published source ZIP**.

The source check alone does not verify Discovery's output or in-game playback.
The actual uploaded output has now been checked separately below. The subsequent
capacity companion addresses an independently reproduced native defect; an
unchanged source repack is not presented as a fix. See
[the focused source audit](DYNAMITE_3V3_RUNTIME_SOURCE_AUDIT.json).

## Confirmed in the actual uploaded bake

The latest uploaded `TITAVUSREVATCHCARD-20261024-173411.7z.001` is a complete
737,252-byte archive, and its member CRC checks pass. It contains the original
908,129-byte `TITAVUSREVATCHCARD-20261024-173411.cak`, SHA-256
`a7d1db5c9ed950f959eb9ebfe2177f9088d1528c1d1487f8de723c1a481acbd7`.

The native reader identifies a regular version 9.9 CAK, with valid metadata
section checksums. All **109 expected payload files** extract and match the
published combined ZIP byte for byte: eight card projects and 101 movies. The
only extra file is the empty texture database. Dynamite and Collision have
their correct `UI/` paths and asset hashes, and all six `ph_L09_<player>P.bk2`
movies are present at the referenced paths. The uploaded Dynamite project is
identical to the source whose six 3v3 layers were checked above.

This latest bake therefore has the expected contents and virtual paths. It is
different from the much smaller, earlier upload with the same CAK basename that
omitted `UI/`; that earlier root error does not apply to this archive. Original
upload bytes and the baked filename were preserved during inspection. See
[the received CAK audit](DYNAMITE_3V3_RECEIVED_CAK_AUDIT.json).

This archive contains no `CreateShow` table. The three missing card-link repairs
for other shows must be supplied elsewhere if applied; that omission does not
explain Dynamite 3v3, whose supplied current card references already match.

## Evidence needed next

The user has now confirmed that the corrupted five-person screenshot uses this
same combined CAK. A direct comparison with the smaller pack finds all 145
five-person node properties unchanged in each of Dynamite and Collision. All
five five-person movie payloads are also byte-identical. Full decoding of the
five movies extracted from the received CAK passes: RGB is black and alpha is
0–2/255 throughout. The green/pink regions are not present in those placeholder
pixels. See [the comparison](FIVE_PERSON_COMBINED_COMPARISON.json).

The complete project has 101 movie layers instead of the smaller pack's 14.
Handling additional layout objects or resource lifetime is a hypothesis, not a
measured runtime cause. The earlier smaller-pack success did not identify the
exact same five wrestlers/GMRs. Restore the saved smaller working dedicated CAK
and compare the same five wrestlers with GMRs and plugin settings unchanged.
Back up the current dedicated test output first, keep one dedicated matchup
patch active and retain original arena archives. Do not expand the recovery
input with Game setup.

The new diagnostics contains 68 header-compatible candidates, but zero GMR
movies and zero runtime logs. Verbose is already enabled. Its archive-reader
warnings do not prove that the game-readable archives are damaged. The source
catalog's unresolved ID 30 does not explain the verified Dynamite 800 card.
See [the diagnostic audit](FIVE_PERSON_LATEST_DIAGNOSTICS_AUDIT.json).

The actual `1459_CM_PUNK_ROH.gmr` has now been supplied and checked: its logical
ID is 1459, aliases are empty, screens are both, ending is loop, dimensions are
1024 by 1024, and it contains 112 correctly indexed keyframes at 30/1 fps with
alpha and no audio. Full independent decoding and representative RGB/alpha
images show the expected character, with no screenshot-like green/pink field.
This validates this sample's independent decode, not every installed GMR or the
game's actual decoder. The same installation's `bink2w64.dll` is not available in
this workspace and is the next input for a native movie/transition decode.

The current 3% comparison must keep the identical arena, wrestlers, attires,
match type and bake while moving MovingRenders, MatchCardCapacity and, if
present, SelectionLoop outside Plugins with WWE closed, then restarting. No
bake is needed. A stall persisting without those plugins points beyond their
runtime playback; loading without them implicates that runtime path, including
its interaction with the baked movies. The latest exact arena/match type is
pending clarification. Neither result alone establishes all UI asset priority
or character-model correctness.

A private 1024-square transparent carrier candidate has also been prepared
with the original 101 paths/FPS identities and tested transparent pixels. The
delivered carriers are 32-square while the GMR is 1024-square; a surface-size
handoff issue remains only a hypothesis. This candidate is held, not shipped
or claimed as a fix, pending the controlled runtime comparison.

Only two supplied projects belong in `UI/Projects/ShowAssets/matchup/`: Dynamite
and Collision. The other six Titavius projects are referenced under
`Arena/Titavius/<show>/Interface/Matchup/`. The combined ZIP contains all eight
at those original paths; moving the other projects into ShowAssets would change
their asset references. That folder count does not establish the 3v3 cause.

Keep the saved working five-person CAK/input available. Original uploads remain
unchanged. Native-decoder testing and the controlled gameplay comparison remain
pending; the runtime cause is unresolved.
