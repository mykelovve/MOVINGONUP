# Five-person subset and latest result

**Newest status:** the user reports another possible launch crash after the
AEW-only attempt. All current packages of this 16-file source are held pending
the actual latest baked CAK. Follow [current rollback/evidence steps](RECURRING_UI_STARTUP_CRASH.md);
the trial instructions below are historical.

**Current user direction:** return to this smaller source checkpoint and leave
six-person and larger matches on their original portraits. Use the
[new recovery ZIP and instructions](FIVE_PERSON_RECOVERY.md), which preserve all
16 payloads below exactly and put aside the later optional capacity companion.
The rest of this document records the earlier trials, not a request to expand
the recovery or repeat the failed full-layout installation.

**Latest combined-pack trial:** the user confirms a green/pink five-person
Dynamite screenshot with the exact combined CAK inspected here. Its five-person
node properties and five movies match the smaller package below, but the full
project has 101 layers instead of 14. The runtime cause remains unresolved;
the smaller-pack success must not be extended to the combined pack. See
[the current investigation](DYNAMITE_3V3_RUNTIME_TRIAL.md).

**Earlier smaller-pack report:** the five-person test was “perfect”; six-person returned
to original portraits. The smaller package below contains `5man` but omits
`6man`, `3on3` and other layouts. The exact arena/active CAK was not supplied in
that message. The subsequently requested [all-layout per-arena rebuild](ALL_AEW_LAYOUTS_TEST.md)
adds every supplied layout while retaining this source's five-person properties.
The expanded pack has since failed playback trials; the runtime cause remains unresolved.
Keep the current working five-person CAK and input as the rollback.

**Earlier full-layout trial:** the user's five-person Dynamite screenshot shows a large green area and mixed
rendered/original portraits. They confirm **loading stalled or crashed** and
**all five installed renders are set to Both screens**. Five-person playback is
therefore failing in this trial. Another match also got stuck while the
all-layout test remained installed. The all-layout expansion is held; its previous
structural checks did not establish gameplay compatibility.

The now-held smaller five-person source
starts from the user's working Discovery-baked one-on-one/2v2 input. It preserves
that input's existing nine layers per project (one-on-one, 2v2 and triple threat)
and adds **only the five `5man` layers** to Dynamite and Collision. Triple threat
properties are preserved; their successful gameplay is not inferred from 2v2.

There are 14 movie layers per project, 28 total, and **16 BakeMe inputs**: two
projects plus 14 placeholder movies. The other 87 slots per project remain
intentionally unpatched. This tests whether the five-person layout fails in a
small input too, instead of attributing the result to every added layout or a
four-person plugin limit. This is an isolation test, **not a verified fix**.

## Use the same working Discovery bake

1. Close WWE. Put aside the generated **all-layout test CAK**, and restore your
   saved working one-on-one/2v2 CAK with its exact original filename. Keep original
   arena, character and data CAKs, plugins and GMRs. Confirm the working baseline
   before attempting the new test.
2. Back up that working dedicated CAK and its input outside the game/bake folders.
   Extract this ZIP into a fresh folder. In the same working Discovery entry,
   select **BakeMe**, the folder containing `UI`, as input. Do not merge the old
   all-layout input into it.
3. Keep the same working output filename/path and WWE 2K26/version-9.9 settings.
   Bake once in Discovery, with one dedicated matchup patch active, then fully
   restart WWE. No prebuilt CAK is supplied. Do not run full Studio Game setup on
   this isolated folder; its proposed 87 additional placeholders/layout slots
   are deliberately omitted here.
4. Check one-on-one and 2v2, then repeat the same five-person Dynamite match. Record
   how many portraits move, whether green appears and whether gameplay loads.
   If it fails, restore the saved working CAK and saved input before rebaking.

For the next diagnosis, provide the **actual dedicated CAK baked for this trial**
and a **GMR belonging to one of the green/right-side slots**. Current source
inputs alone cannot establish the internal paths or archive that won at runtime;
a still image cannot establish which portraits animated.

## Evidence checked

- The latest diagnostic ZIP is 2,033 bytes with SHA-256
  `8d9b1f93a4d5bb6c795f167b5c97f4d80d880a1716adc340a8ca50a457a964e6`.
  It contains the setup report, numeric logging settings and included-file list.
  It reports 63 header-compatible root GMRs, selected logical ID 624/Zack Ryder,
  verified original MovingRenders 4.21 and `enabled 1`/`verbose 1`. It includes
  **zero runtime logs**, no GMR payload and no baked CAK. Its checks concern the
  full Discovery root, not proof of the active dedicated bake.
- The verified original plugin's 20-entry layout-count table exactly matches
  the supplied layout recipe, including five slots for `5man` and eight for the
  largest layouts. This does not establish that every live slot resolves or
  that its movie is composited correctly.
- Full decoding of supplied `ph_L11_5P.bk2` gives only black RGB, with alpha
  values 0–2/255. It does not contain a green background. The screenshot's green
  area still requires examining the affected GMR/runtime compositing; it is not
  proof that the user rendered against the wrong background.
- Native checks preserve every existing node identity and every other layout's
  node properties. Original-prefix changes are limited to five newly extended
  child pointers per project. Existing nine placeholder files are byte-identical.
- Independent managed checks find 28 valid existing movie layers, no invalid
  layer repairs or unsupported schemas, and unchanged input bytes. The remaining
  174 layers and 87 shared placeholders are intentionally omitted.
- All 14 supplied placeholder movies fully decode with FFmpeg without errors.
  No Windows/WWE gameplay execution was performed here.

The separate [arena/card/transition checker](ARENA_LINK_CHECKER.md) checks current
metadata for Revolution and the other supplied Titavius shows. It changes no
bake and adds no moving layers to those shows.
