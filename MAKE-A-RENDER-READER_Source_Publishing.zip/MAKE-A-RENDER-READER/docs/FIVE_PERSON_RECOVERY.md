# Restore the smaller five-person checkpoint

**Held after the newest startup-crash report:** current five-person/AEW-only
downloads are withdrawn while the actual newest baked CAK is identified. These
source packages match the earlier source; startup compatibility is unverified.
Use [the current rollback and evidence steps](RECURRING_UI_STARTUP_CRASH.md).
The remaining text documents the earlier package rather than recommending a
new bake.

The user now requests the earlier smaller checkpoint and regular portraits for
six-person and larger matches. New all-layout and capacity experiments are held.
The held recovery ZIP contains exactly the earlier 16 input files, with unchanged
paths and bytes. Preserved source bytes do not verify a newly installed CAK.

This is the Dynamite/Collision source associated with the user's report that
five-person was “perfect” and six-person returned to renders. The exact active
CAK/arena for that earlier success was not supplied. Restoring its source is
not a newly verified game-loading fix.

| Layout | Recovery behavior |
| --- | --- |
| One-on-one | Earlier moving layers retained |
| Normal two-on-two tag | Earlier moving layers retained |
| Triple threat | Earlier moving layers retained; gameplay not newly confirmed |
| Five-person free-for-all (`5man`) | Earlier five moving layers retained |
| Six-person free-for-all / three-on-three | Original portrait nodes retained |
| Eight-person / four-on-four | Original portrait nodes retained |
| Other omitted layouts | Original portrait nodes retained |

This deliberately restores the four earlier layouts. It does not introduce
every other match type with five or fewer participants. Other arenas and
transitions are reviewed separately.

## Install the recovery

**Full-data archive clarification:** the subsequently supplied `discovery_data.cak`
contains 1,113 files, including roster/character data. Keep the restored working
full-data CAK installed. The 16-file UI-only input here must not replace that
whole data archive. References below to the same entry/output filename mean an
existing **dedicated matchup/UI bake**; if none exists, a later separate
dedicated entry is required. The received full-data bake still has 101-layer
Dynamite/Collision projects, and its startup investigation remains open. See
[the current archive findings](RECEIVED_DISCOVERY_STARTUP_AUDIT.md).

1. Close WWE. Back up the current dedicated matchup CAK and its input outside
   the game/bake folders. If installed, put `WWE2K26_MatchCardCapacity.dlp` and
   its `.cfg` outside `Plugins` to restore the earlier plugin state. Keep the
   original MovingRenders plugin, config and installed GMRs.
2. Prefer restoring the actual saved smaller CAK that worked, under its exact
   original filename, together with its saved source. Otherwise extract the
   recovery ZIP to a **fresh folder**, select **BakeMe**, which contains `UI`, in
   the same working Discovery entry, and retain its exact output CAK name/path,
   WWE 2K26/version-9.9 settings and other working options. Bake once.
3. Keep **one dedicated matchup override** active; put aside the replaced
   all-layout/test CAK. Keep original arena, character and normal setup archives.
   Fully restart WWE, then check the same earlier five-person case followed by
   a six-person match, which should use its regular portraits.

Do not merge this into the full all-layout input or run full Studio Game setup
on it. Either expands the isolated recovery again. Removing loose files alone
does not remove their replacements from an existing baked CAK. No prebuilt CAK,
plugin, config or GMR is distributed in this ZIP.

## Checks

Both projects have 14 moving layers each, and share 14 existing movies. All 16
BakeMe files match the original smaller ZIP byte for byte. Each of the other
16 layout subtrees per project was compared with the original supplied project:
all nodes/properties match, including six-person and larger layouts. Background
and foreground properties and all original node identities are retained. All
14 movies fully decode. Independent managed readonly checks find 28 valid
layers and zero invalid layers; the omitted 174 slots are intentional.

See [the exact source and per-file audit](FIVE_PERSON_RECOVERY_AUDIT.json).
These checks verify source restoration; this environment cannot run WWE to
confirm current playback or loading.

The [other UI preparation](OTHER_MATCHCARD_READINESS.md) stays separate so its
unknown bindings or runtime behavior do not expand this recovery.
