# Installing renders could reconfigure UI automatically

Normal Install into the game copied the GMR and then awaited native
`GameSetup(false)`. The batch Install completed callback separately called
`RunCombinedGameSetupAsync`. The helper's setup completion invokes the full
101-slot layout preparation. Installing an existing movie could therefore change
the selected loose UI recipe even without clicking Game setup. A later bake
could publish those changes. This is a verified source/control-flow problem,
not proof of the currently loaded archive or a sole cause of the observed failures.

The received diagnostic checks the main Discovery folder with 13,433 supported
slots, zero missing layers, and 91/91 linked projects found. It does not identify
which input the bake entry used or which CAK the game loads. It also contains no
selected GMR or runtime logs despite enabled 1 and verbose 1. The 59 installed
GMRs pass header checks, not movie decode/live playback checks. See
[the sanitized findings](RECEIVED_MATCHCARD_DIAGNOSTICS.json).

## Changes in 1.7.24

- Normal render installation retains the original copy logic and await shape,
  but the one automatic GameSetup(false) call is redirected to a completed task
  without setup or I/O.
- Batch installation copies the selected movies and reports success without
  invoking UI setup.
- Both explicit setup controls remain available.
- Installed renders -> Show on defaults to Both screens. Explicit other modes
  remain available; existing GMR metadata is not changed on startup.

The patcher verifies an eight-method allowlist. For OnInstall, only the one
five-byte call may change; all other IL bytes, stack/local headers and exception
regions are compared exactly. Existing method/resource checks remain. A real
binary integration test confirms the previous automatic calls existed and the
candidate normal/batch paths no longer invoke setup. The helper retains only its
two manual setup routes. No Windows or WWE execution is claimed.

## Recover a limited test

The app update prevents future automatic setup; it does not reverse loose UI
edits or an existing bake. Keep the current failing generated archive for review.

Restore the saved working dedicated input/CAK backup, or extract the limited test
ZIP into a fresh folder. In Studio's Check match-card setup, use Choose UI folder
to select that exact BakeMe instead of the main Discovery root. Select that same
complete BakeMe in the bake entry, including Arena and UI when both are present.
Back up the dedicated generated test CAK and input outside the game/bake roots,
move the old generated output out, then rebuild to its original dedicated name.
Keep unrelated and original arena CAKs intact. Do not replace a main data CAK
with the small test.

Do not run explicit Game setup over the limited recipe: it remains a full-setup
action. The checker will report deliberately omitted full-layout slots and
placeholders, which is expected for this experiment. Existing installed GMRs do
not need a new MAKE. Fully restart WWE after the bake.

If cards remain static, choose an actual installed participant GMR, enable logging
with WWE closed, restart, reproduce the same match and Save diagnostics. Supply
the generated dedicated test CAK under its original filename. These distinguish
the active bake and logical-ID lookup from source-file readiness. Selection
animation does not confirm match-card playback; the checked participant already
reports Both screens.
