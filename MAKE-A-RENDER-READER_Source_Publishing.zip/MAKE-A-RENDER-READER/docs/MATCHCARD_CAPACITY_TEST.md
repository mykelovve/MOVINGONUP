# Match-card capacity fix test

**User trial update:** the uploaded log reports successful activation and sampled
active-context counts of 4 and 15. Green/pink portrait corruption remains, and a
subsequent 3% loading stall is reported. This companion has **not resolved** the
reported rendering/loading problem. One-second sampling does not establish an
absolute maximum concurrent count. The actual CM Punk ROH GMR fully decodes in
FFmpeg with intact alpha and both-screen settings; native game decoding and GPU
surfaces are not verified by that test. See
[the post-activation audit](CM_PUNK_ROH_POST_ACTIVATION_AUDIT.json).

[Download the separate capacity companion](https://github.com/mykelovve/MOVE-A-RENDER-/raw/refs/heads/main/downloads/GorillaStudio_MatchCard_Capacity_Fix_Test.zip).

This corrects a reproduced movie-tracking defect in the original MovingRenders
4.21: opening a seventeenth distinct match-card movie overwrites the first live
record. The companion expands tracking from **16 to 120** records and updates
every associated reader. It keeps the original plugin file, your current baked
UI and all installed GMRs unchanged. **No new bake or MAKE is required.**

The combined-pack screenshot shows five-person green/pink corruption and the
user reports 3v3 falling back to original photos. The uploaded CAK is correctly
baked. Capacity is a verified native defect; whether this correction resolves
those particular game symptoms still needs the user's in-game test.

## Install and try

1. Close WWE completely.
2. Extract this ZIP. Copy its `Plugins` folder into the WWE 2K26 game folder,
   merging it with the existing `Plugins` folder. It adds only
   `WWE2K26_MatchCardCapacity.dlp` and `WWE2K26_MatchCardCapacity.cfg`.
3. Keep `WWE2K26_MovingRenders.dlp`, its configuration, the current combined CAK,
   your original arena archives and installed renders in place. The supplied
   companion configuration is `enabled 1`.
4. This trial now has a reported failure. For the current 3% investigation,
   retain the same bake and exact match while comparing with all moving-render
   playback plugins temporarily moved outside `Plugins` after closing WWE.
   Restart WWE for the comparison; no new MAKE or bake is needed.

Keep this comparison on the existing bake. Running Game setup or replacing UI
files at the same time would introduce a second change.

`Plugins/WWE2K26_MatchCardCapacity.log` must contain:

```text
ACTIVE: match-card contexts expanded from 16 to 120; original file and UI unchanged
```

It also records newly observed sampled peaks of active match-card contexts.
An activation failure includes its reason. If the card still fails, supply this
new log directly; earlier Studio diagnostics versions do not collect it.
The companion supports the exact original **4.21** file and waits for its
existing initialized hook. It does not enable or replace a missing original.

## Remove

Close WWE, move only `WWE2K26_MatchCardCapacity.dlp` and its `.cfg` outside
`Plugins`, then restart. All code changes were in memory, so restarting without
the companion restores the original 16-record behavior. Existing CAKs and GMRs
were not edited.

## Validation and limits

- 2,689 native x64 checks execute the original and corrected instruction blocks:
  the original loses its first record on registration 17; the correction retains
  all 120 records, reuses closed holes and supports every reader index.
- The Win64 host passed under Wine: mapped PE allocation, thread-IP refusal and
  resume, live-record refusal, guarded publication, 120 actual native lookups,
  restored RX page protection and original file integrity.
- The production companion loads normally under Wine, resolves its imports and
  writes the disabled-configuration startup log.
- WWE, CakeHook activation, Bink playback, GPU resources and game transitions
  were not exercised here. Other runtime causes remain possible. This is a
  focused capacity correction for testing, not confirmed all-mode compatibility.

The six inline readers, public lookup, seven table bases and both loop bounds
are guarded against the pinned original. No game address, native authorization
instruction, caller-routing detour or selection consumer instruction changes.
See the [source and build notes](../src/MatchCardCapacityPlugin/README.md).
