# Original Titavius matchup and transition links

All eight supplied original profiles resolve to both a matchup project and a
transition movie in the original `titavius_aew_2026.cak` index. The requested
four shows have these exact project references:

| Show | Arena ID | Matchup project hash | Project directory |
| --- | ---: | --- | --- |
| Revolution | 803 | `FBD326AF3588DB9E` | `Arena/Titavius/803_-_AEW_Revolution_2026/Interface/Matchup/` |
| Dynasty | 805 | `5F49C7CFCD20A530` | `Arena/Titavius/805_-_AEW_Dynasty_2026/Interface/Matchup/` |
| Double or Nothing | 806 | `342FF29B4876B646` | `Arena/Titavius/806_-_Double_or_Nothing_2026/Interface/Matchup/` |
| Redemption | 808 | `CEA7666BC0CAA4CA` | `Arena/Titavius/808_-_AEW_Redemption_2026/Interface/Matchup/` |

Dynamite and Collision instead use `UI/Projects/ShowAssets/matchup/`. A later
multi-arena bake must preserve both `Arena` and `UI` under its input root when
both appear in the package. Moving the whole project tree under `UI` changes
asset paths and hashes. The current five-person isolation input contains only the
two Dynamite/Collision projects and 14 shared placeholders. It supplies no
other arena project, transition or profile-table replacement.

Each original `ArenaData.transition_movie_id` matches its profile's
`MovieData_Transition.id`, and that record's `bk2_path` resolves to the same
arena's `Movie/Transition.bk2`. All eight movies were extracted with the original
reader. Their Bink signatures, declared file lengths, dimensions and frame/rate
fields pass. The original Dynamite/Collision Bink1 transitions also fully decode
with FFmpeg. The other six use KB2n Bink2, unsupported by the available FFmpeg;
those probe errors are not evidence of corruption or missing files.

The original project and transition records are therefore present in the source
pack. This does not establish the user's **current** imported tables, bake or
winning archive. A show falling back to the default card requires comparing its
current `CreateShow/MatchUpScreenAsset.jsfb` record and baked project path with
these references. A transition is a separate link from the matchup project.
Neither the moving portraits in roster selection nor the presence of an arena
in the arena menu verifies those two links.

The [current-data checker](ARENA_LINK_CHECKER.md) reads those three binary tables
independently. The newer 17:35:53 UTC user report has matching references for
five shows, including Forbidden Door, but absent card records for ROH Supercard,
Dynasty and Double or Nothing. Their arena/movie references match. This
supersedes the inverse omissions in much older supplied metadata. Checker 1.2
can export those absent cards from current local data with an exact backup;
it adds no movie layers. See [current findings](CURRENT_ARENA_CARD_LINKS.md).

No transition, original card, arena profile or current user table was changed by
this audit or the checker. See [all exact source references, hashes and movie
checks](MOD_ARENA_CARD_LINKS.json).
