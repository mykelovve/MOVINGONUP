# Match-card diagnostics

The setup report checks installed files and extracted Discovery data. It does not
observe the running game, its active baked archive, or the CakeHook/Bink hooks.

With WWE closed, choose **Check match-card setup -> Choose GMR** and select an
existing movie from Plugins/GorillaRenders. No new MAKE is required. An installed
movie's Show on setting can be changed to Both screens in Installed renders.

To collect a failed run, use **Enable playback logging**, fully restart WWE,
reproduce the same match and use **Save diagnostics**. This changes only verbose
logging in a verified original 4.21 configuration, retaining the other options and
an original backup. It does not enable a disabled plugin or perform a bake.

The ZIP includes the report, available MovingRenders and optional SelectionLoop
logs, and a numeric allowlist of native diagnostic flags. Unrelated config keys
and values are excluded. Missing logs leave plugin activation unverified; they do
not by themselves establish that the plugin failed to load. If verbose is enabled
and logs remain absent, check CakeHook loading, the running game folder and write
permissions with that exact run held constant.

## Optional mapping input

The original MovingRenders 4.21 binary has SHA-256
`b752da3c9a9dc48dc377972a7183db0194c2b3b551074f7d0f0c9766432bf75c`.
Its routine at VA 0x180006e00 reads GorillaRenders/_roster_pictures.txt and falls
back to GorillaRenders/_scan_ids.txt using `_wfopen` in mode `r` at VA
0x180006e66/0x180006e9f. These are optional mapping inputs, not generated scan logs.
Earlier diagnostic wording incorrectly described _scan_ids.txt as a runtime log.
Version 1.7.22 corrects that label and collects it under inputs only when present.

Do not create an empty mapping file to obtain logs. Enabling verbose logging does
not set scan_ids, diag or mu_scale_test; those flags can change native diagnostic
behavior and are retained for inspection rather than guessed or enabled.

## Current evidence

The supplied recording shows Zilla Fatu versus Roman Reigns on RAW. The progress
bar remains near 41 percent for about 20 seconds, then the recording reaches black.
The clip ends about six seconds later. Entrances are off in the recorded options.
The received diagnostic ZIP contains no runtime logs. Its latest read-only layout
check reports zero pending repairs; its 28 unresolved project references and
Bakery CAK reader failures remain separate issues. Neither the recording nor the
report establishes the loading-stall cause.

The original supplied Wrestlepalooza 2025 project, show 645, matches Discovery hash
658B828C2477E338 at UI/Projects/ShowAssets/matchups/matchup_0645_WRESTLEPALOOZA_25.jsfb.
Both one-on-one players have the exact native autoplay, transform and still-picture
marker; both referenced placeholders decode. These are source-file checks. The
user's active project, bake and live playback remain unverified.
