# Non-AEW matchup screens

**Later upload:** UI_2 now supplies four actual AAA layout projects. Their `bg`
references match the previously supplied AAA 2026, Noche de los Grandes, Ola
de Calor and Rey de Reyes movies. Each project has 101 movie layers. Current
show assignments are not verified, and rebake trials remain held after the
startup-crash reports. See [the UI_2 source checks](UI2_SOURCE_AUDIT.md). The
UIFIXES-only inventory below remains accurate for that earlier archive.

The user requests work on the other uploaded matchup UI ZIPs. This continues
with UIFIXES (30 volumes) and Rev's SummerSlam 2026 (eight volumes), keeping the
requested smaller Dynamite/Collision recovery unchanged.

## SummerSlam source test withdrawn after a startup-crash report

The user reports WWE crashes **when launching**, with this test installed. The
download is removed from the current tree and retained privately for source
comparison. Historical commits/local copies cannot be revoked. Do not install
or rebake this candidate. Restore the actual saved working CAK and saved input
as described in [the startup-crash recovery](SUMMERSLAM_STARTUP_CRASH.md).

The actual newly baked CAK and the launch result after restoring the previous
bake have not been supplied. The source checks below do not establish the cause
of this startup crash or prove the installed archive matches this input.

The remaining text records the withdrawn source and its earlier file checks.

This contains the exact 16 smaller Dynamite/Collision recovery inputs plus one
SummerSlam matchup project, for **17 game input files**. The 14 existing shared
movies are reused byte for byte. All folders are already arranged:

```text
BakeMe/
  UI/Projects/ShowAssets/matchup/                two unchanged recovery projects
  UI/Assets/movies/gorilla_renders/              fourteen shared movies
  Arena/Rev's_Arenas/SUMMERSLAM_2026/Data/
    matchup.jsfb                               SummerSlam source test
```

SummerSlam's source Day/Evening/Night profiles, originally IDs 254/255/256, all
reference project hash `CEE14CECD61F3402` at that exact `Arena` path. Its
background reference `9CA2D542F6A553A2` resolves to
`Arena/Rev's_Arenas/SUMMERSLAM_2026/UI/matchup.bk2` in the supplied
`Rev16_Summerslam_2026.cak`. Current local profile assignments and active baked
override priority have not been supplied. This ZIP replaces no profiles,
backgrounds, logos, transitions or arena models.

The SummerSlam project adds only one-on-one, normal 2v2 tag, triple threat and
five-person free-for-all: **14 portrait movie layers**. All omitted layouts,
including six-person, 3v3, 4v4 and eight-person, retain original portrait nodes.
This is not every match type with five or fewer participants.

Native comparisons preserve all original node identities, backgrounds, logos
and every omitted layout's node properties. Original-prefix changes are limited
to 14 player child pointers. Exact slot markers, autoplay and movie references
are checked. Independent managed readonly checks confirm 14 valid layers, zero
invalid layers and no source changes. The existing movies are identical to the
smaller checkpoint's fully decoded files. **Live WWE playback and match loading
are unverified for this new SummerSlam candidate.**

The final combined 17-file input was also checked independently as one folder:
three projects, 42 valid movie layers, no invalid layers and no byte changes.
The other 261 slots and 87 shared movies proposed by the full-layout checker are
deliberately omitted, rather than applied to the smaller source.

The original trial used the working Discovery entry/output filename and version
9.9 settings, retaining original arena archives and GMRs. That was an intended
test method, not evidence that the user's resulting archive passed checks.
Further installation/testing is held after the startup-crash report.

## NOC26 candidate held for its actual links

UIFIXES contains one identified matchup project, `NOC26/matchup.jsfb`. A
private 14-layer source candidate is now prepared and passes the same native
and managed readonly checks, including original six-person-and-larger layouts.
It is not distributed in the SummerSlam test.

Neither the archive nor the supplied current tables establish its arena binding
or the actual source of background movie `41F5D1A813176D5C`.
`NOC26/bg.jsfb` references that same movie; it is not its movie payload. A filename
alone cannot prove the installed project's canonical path or show assignment.
No arena ID, replacement background or CreateShow record is guessed.

## AAA movie integrity and missing layout associations

All **13 complete movie members** were streamed from all 30 volumes and checked
against their individual archive CRCs: **808,030,316 payload bytes**, without
retaining another large extracted copy. SHA-256 hashes and bounded headers are
recorded. These checks passed. They do not decode frames or confirm in-game
playback. No claim is made about CRCs of every other file in the archive.

| Matchup background | Header format | Declared dimensions |
| --- | --- | --- |
| AAA 2026 | BIKi | 3840 × 2160 |
| Alianzas | BIKi | 1920 × 1080 |
| Noche de los Grandes | KB2n | 1920 × 1080 |
| Ola de Calor | KB2n | 1920 × 1080 |
| Rey de Reyes | BIKi | 1920 × 1080 |
| Triplemania 34 CDMX | KB2n | 1920 × 1080 |
| Triplemania 34 Vegas | KB2n | 1920 × 1080 |

The six remaining movies are locators. The 133 supplied JSFB payloads contain
no exact references to those seven AAA movie-path hashes. The filename inventory
also supplies no AAA matchup portrait layout, CreateShow matchup table or JSON
profiles. This exact-hash scan does not rule out an external alias or base-game
source; it establishes that their current live layout associations cannot be
joined from this archive alone. The current Discovery project/table links are
needed before assigning portrait slots to AAA shows.

The WWF-named archive files remain arena textures, materials and a ring model;
three distinct WWF matchup UI projects have not been identified in this upload.

See [source hashes, native/managed checks, all movie CRCs and link-scan evidence](NON_AEW_UI_PREPARATION.json).
