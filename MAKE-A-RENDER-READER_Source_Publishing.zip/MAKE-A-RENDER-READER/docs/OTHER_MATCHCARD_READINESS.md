# Other matchup-screen preparation

**New raw-source evidence:** UI_2 supplies four AAA matchup projects whose exact
background hashes join to the earlier UIFIXES movies. All four are currently
101-layer layouts. The full upload has 127 such matchup projects plus two
bundle-identical selection templates; all 281 member CRCs pass. It contains no
AEW or NOC26 source override. None of the four AAA project-path hashes occurs
in the older received CAK's card table, and current game assignments are not
established. This source inspection does not lift the current rebake hold. See
[the new source audit](UI2_SOURCE_AUDIT.md).

**SummerSlam test withdrawn:** the user reports a crash when launching WWE.
The source adds one SummerSlam project without changing any of the 16 recovery
payloads, but the actual newly baked CAK and rollback launch result are not yet
available. Restore the actual saved working CAK/input; no replacement experiment
is supplied. See [startup-crash recovery](SUMMERSLAM_STARTUP_CRASH.md).
NOC26 remains held for its actual binding/background. All thirteen AAA
movie-member CRCs pass, but matching layout references were not found in the
supplied JSFBs. [Preparation checks remain historical source evidence](NON_AEW_UI_PREPARATION.md).

**Review resumed alongside the requested rollback (2026-10-26):** the
[smaller five-person recovery](FIVE_PERSON_RECOVERY.md) contains only its exact
earlier Dynamite/Collision inputs. None of the other UI candidates below is
merged into it. Six-person and larger layouts remain original in that recovery.
The staged source checks below establish preparation, not new gameplay support.

The subsequently requested **one-on-one/2v2/4v4** source tests are now prepared
separately for Redemption, Forbidden Door, Dynasty, Double or Nothing and optional
ROH Supercard. Each contains 14 movie layers. Revolution's prepared three-layout
candidate remains held after earlier loading failures. See
[the per-arena download and checks](AEW_THREE_LAYOUT_TEST.md); runtime is unverified.
The seven-candidate one-on-one preparation below remains the source baseline.

Seven independent one-on-one source candidates have been staged and checked.
Each contains one original-source project extended with two portrait movie
layers and the two existing verified placeholders. They are not a combined
bake or a newly verified game fix. Their staged files have not replaced the
user's current loose projects or working CAK.

| Screen | Preparation | Current dependency |
| --- | --- | --- |
| Redemption 808 | Two one-on-one layers checked | References match; actual loose project payload, winning bake and gameplay unverified |
| Dynasty 805 | Two one-on-one layers checked | Export/apply the missing card record first |
| Double or Nothing 806 | Two one-on-one layers checked | Export/apply the missing card record first |
| ROH Supercard 804 | Two one-on-one layers checked | Export/apply the missing card record first |
| Forbidden Door 807 | Two one-on-one layers checked | Newest report's references now match; project remains inside the original CAK or otherwise unextracted |
| Rev SummerSlam 2026 | Two one-on-one layers checked in the shared project | Original Day/Evening/Night profiles use IDs 254/255/256; current assignments are not in the eight-show report |
| NOC26 from UIFIXES | New two-layer source candidate checked | Arena binding and background asset `41F5D1A813176D5C` remain unverified |

The first six candidates are byte-identical to the same individual projects in
the earlier one-on-one add-on. Preparing and checking them does not create a new
runtime fix. The newly established missing-record problem is addressed by
[checker 1.2's export](CURRENT_ARENA_CARD_LINKS.md), not by relabeling unchanged
UI projects. A current local UI customization has not been supplied for comparison
with the original-source candidates.

Revolution remains a separate investigation: its latest references match, but
earlier moving and static trials had loading failures. No unchanged Revolution
project is being sent as a new fix. The Dynamite/Collision full-layout expansion
also stays held while the requested smaller checkpoint is restored.

The subsequent user report called the smaller five-person case “perfect,” with
six-person returning to original portraits. After later expanded-pack failures,
the user now explicitly requests that smaller source as the recovery checkpoint.
Its exact active CAK/arena at the earlier success was not supplied, and a fresh
recovery bake has not been retested here.

## UIFIXES and the remembered WWF screens

All 30 uploaded UIFIXES volumes are available. The archive lists 2,208 files:
2,187 under `Arena`, 13 under `UI`, and eight under `NOC26`. All 133 JSFB files
were previously extracted with their individual CRCs verified. The archive has
one identified matchup layout project, `NOC26/matchup.jsfb`, and these seven
matchup background movies:

- `AAA_2026.bk2`
- `AAA_Alianzas.bk2`
- `AAA_NocheDeLosGrandes.bk2`
- `AAA_OlaDeCalor.bk2`
- `AAA_ReyDeReyes.bk2`
- `Triplemania34_CDMX.bk2`
- `Triplemania34_VEGAS.bk2`

The other six UI movies are locators. A background movie alone is not the
project that places portraits, selects a match layout or links an arena to the
card. Those linked AAA layout projects must be identified before inserting
portrait layers. The WWF-named files in this archive are arena textures,
materials and a ring model; three distinct WWF matchup projects have not been
identified. No show IDs or asset paths have been invented for them.

The resumed full filename inventory finds no JSON profiles, text instructions,
CSV links or other metadata documents in UIFIXES that establish additional
bindings. Its non-Arena inputs remain exactly the eight NOC26 JSFBs and thirteen
AAA movies above. This does not establish the canonical project paths or the
current installed arena assignments for NOC/AAA.

`NOC26/matchup.jsfb` hashes to `7C873D79EEB44E91`, but neither UIFIXES nor the
earlier supplied matchup metadata establishes an arena record referencing that
exact hash. Its staged candidate is therefore not ready for an assigned arena
bake. The unresolved background may be supplied by the base game; absence from
UIFIXES does not prove it is missing from the installation.

The resumed source inspection also checks `NOC26/bg.jsfb`: its only movie node
references that same `41F5D1A813176D5C` asset. It is not the missing background
movie itself. Its path hash is `26DA661945E79EFC`, so copying it as though it
resolved the referenced movie would not establish that dependency. Both original
JSFB files are retained unchanged; no guessed background replacement is included.

## Checks and next sequence

All seven candidates preserve existing node identities, background/foreground
properties and other layout properties. Original-prefix changes are limited to
the two extended one-on-one player child pointers. Native checks verify movie
asset references, autoplay and exact slot markers. Independent managed readonly
checks find two valid movie layers per project, no invalid layer repairs or
unsupported schemas, and unchanged staged input bytes. The other 99 movie slots
per project are intentionally omitted. No new movie content was encoded; the
placeholders match previously decoded files.

First restore/confirm the requested smaller five-person baseline. Separately,
apply the three missing card bindings from the current local data, then
verify the affected branded cards individually. Each other screen can then be
tested with its own narrow candidate and actual baked-path checks before adding
multi-man layouts. The original project paths under `Arena` and `UI` must be
preserved, with the same working Discovery writer/output filename. NOC26/AAA and
any separately supplied WWF UIs need their current project bindings first.

Preparation does not confirm game loading, portrait compositing, transition
execution, bake priority or automatic alternate-attire routing. No app, plugin,
transition movie, user table or current CAK was changed by this preparation.
See [machine-readable preparation and independent checks](OTHER_MATCHCARD_READINESS.json)
and [current binding findings and repair steps](CURRENT_ARENA_CARD_LINKS.md).
