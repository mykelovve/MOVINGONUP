# Queued updates

## UI_2 inspected: broad source and four AAA background joins

The new complete source upload passes every member CRC: 129 projects and 152
placeholders. All 127 matchup projects have 101 movie layers. Two selection
templates match the unmodified supplied bundle. Four AAA projects now join to
their UIFIXES background movies; their project hashes are not in the earlier
181-row received card table, and current running data has not been checked.
There is no AEW override or baked CAK in this upload. The exact-source launch
result is pending, and no trial-release hold is lifted. See
[the inspection](UI2_SOURCE_AUDIT.md).

## Newest launch-crash report: all small-source UI trials held

The user reports a possible launch crash after the AEW-only attempt. The 16
source payloads still match the earlier checkpoint, but the exact successful
historical baked CAK was never provided and the newest CAK/filename/installation
are not yet known. Current AEW-only, five-person recovery and isolation source
downloads are held with exact evidence retained. Packaging guards prevent
silently recreating them. Restore the actual working full-data archive or put
aside only the new dedicated UI archive, depending on whether it replaced or
accompanied that full-data file. The previous 1,113-file upload must not be
treated as this newest bake without evidence. See
[the current investigation](RECURRING_UI_STARTUP_CRASH.md).

## Received full-data bake inspected; smaller recovery absent

The previous CAK restores normal launch. The uploaded `discovery_data.cak`
passes archive/header/index checks and contains 1,113 files, 131 UI projects
and 377 layout backups. Dynamite/Collision still have 101 movie layers; the
four earlier layout node properties are retained, but the additional layouts
remain. Rev SummerSlam and NOC26 overrides are absent. This is a full data
bake rather than the withdrawn 17-file test input.

Three startup-related assets fail the local ooz substitute. Their zero-byte
extraction outputs are not treated as valid assets or proof of corruption. The
original game/Discovery `oo2core_9_win64.dll` is needed for the next check.
Keep the restored working full-data archive; a minimal UI source must not
overwrite its roster/mod data. No repaired CAK is shipped. See
[the actual archive, source-scope and metadata evidence](RECEIVED_DISCOVERY_STARTUP_AUDIT.md).

## Startup crash: SummerSlam source test withdrawn

The user reports the new test crashes WWE at launch. The current ZIP/checksum
downloads are removed and the exact failed source is preserved privately. The
17-file trial adds one SummerSlam project and changes none of the 16 recovery
inputs. These source checks do not validate the actual new CAK or its runtime
load order. The actual baked archive and previous-bake launch comparison are
needed; no cause or replacement fix is claimed. Restore the saved working CAK
under its exact original filename and restore its saved source. Hold further
SummerSlam/NOC/AAA releases until this regression is isolated. See
[the audit and recovery instructions](SUMMERSLAM_STARTUP_CRASH.md).

## Non-AEW UI work and Too Sweet follow-up

The user requests starting the other uploaded UI packs. SummerSlam and NOC26
now have 14-layer candidates using only the smaller checkpoint's four layouts.
The now-withdrawn [SummerSlam test](NON_AEW_UI_PREPARATION.md) preserves all 16 recovery inputs
and adds its exact canonical project. Original source profile/background links
are verified; current gameplay is not. NOC26 is held for its actual arena and
background association. All 13 AAA movie-member CRCs pass; their corresponding
portrait layouts/current bindings are absent from UIFIXES. No guessed bindings,
background replacements or new six-person layouts are included.

Both Too Sweet raw variants fully decode with 26 body tracks and zero finger
tracks. Its separate authored hand-pose/event source remains unresolved. See
[the exact animation audit](TOO_SWEET_FINGER_AUDIT.json).

## Current priority: restore the earlier smaller five-person checkpoint

The user requests the source associated with the five-person success and regular
portraits for six-person and larger matches. The [recovery ZIP](FIVE_PERSON_RECOVERY.md)
retains all 16 earlier Dynamite/Collision payloads exactly, including the earlier
one-on-one, 2v2 and triple-threat layers. All 32 omitted layout subtrees across
both projects match the supplied originals. No extra layouts or private carrier
candidate are included. Put aside the optional MatchCardCapacity companion and
replace the dedicated all-layout bake, keeping original arena archives and GMRs.
Current gameplay must still be checked after restoring the earlier bake state.

All-layout/capacity runtime work below is held at the user's request. Continue
reviewing the other uploaded UI packs separately; do not merge unverified
projects, table edits or new match modes into this recovery.

## Native match-card capacity correction: activation reported, corruption remains

The user's log now reports ACTIVE and sampled counts of 4 and 15. Green/pink
corruption remains and another 3% stall is reported. CM Punk ROH 1459 passes
all 112 FFmpeg frame decodes and its both-screen/alpha checks. CakeHook leaves
two unnamed archives pending. The exact-match playback-disabled comparison and
game Bink decoder are needed next; the capacity change is not a confirmed
rendering/loading fix. A size-matched carrier candidate is private and held.
See [the post-activation audit](CM_PUNK_ROH_POST_ACTIVATION_AUDIT.json).

The user explicitly requests a fix after the same combined CAK also produces
green/pink five-person corruption. The original instruction harness reproduces
registration 17 overwriting context 0. A separate guarded companion expands the
table, every reader and visibility scan from 16 to 120, retaining the original
on-disk plugin and existing UI/GMR files. All 2,689 native checks and the Wine
mapped-PE/production-load hosts pass. In-game activation and playback are
pending; no all-layout success is claimed. See
[the installation and validation](MATCHCARD_CAPACITY_TEST.md).

## Current Dynamite 3v3 runtime investigation

The user reports a roughly three-second screen pause followed by original photos,
and clarifies that custom renders did not play first. Source inspection confirms
six correctly referenced/autoplaying 3v3 movie layers and preserves all 145
five-person node properties from the smaller source. Input coverage therefore
does not explain this source's failure. The latest actual CAK has now been
extracted and all 109 combined-pack payloads match byte for byte, with the
correct virtual paths and six 3v3 movies. The user now confirms a green/pink
five-person screenshot with that same combined CAK. Its five-person node
properties and five decoded movies match the smaller source, while total movie
layers increase from 14 to 101. The runtime cause is not established. The latest
diagnostic contains 68 headers, zero GMR movies and zero runtime logs; verbose
is already enabled. Affected GMR payloads, active archive priority and native runtime
replacement remain unverified. No runtime cause/fix is established. Only two
projects under ShowAssets is expected; the other six use Arena/Titavius paths.
See [the investigation](DYNAMITE_3V3_RUNTIME_TRIAL.md).

## Finger/hand and mouth indicators for an application update

The user requests a way to identify usable finger/hand and mouth animations,
and explicitly places it in an application update while requesting only the
combined BakeMe input now. This feature is **queued, not implemented in the
current helper or included in the combined data ZIP**.

The measured source catalog is already available for 1,586 entries: 610 have
changing finger rotations, 884 have indexed mouth curves and 342 have both.
The planned picker indicators/filters should distinguish detected finger data,
indexed mouth curves, separate jaw movement and unresolved sources. They must
use the exact clip/alias association and preserve unknown states. Source curves
are not proof of visible playback on every model; an entry should be called
render-confirmed only with corresponding model/preview evidence. No separate
hand-pose association or talking loop should be guessed for unsupported entries.
See [the measured catalog](TAUNT_MOTION_CATALOG.md).

## Combined BakeMe UI input

The [combined download](COMBINED_BAKEME_UI.md) arranges the same eight card projects
and 101 shared movies in one `BakeMe` root with UI/Assets, UI/Projects and Arena
already placed correctly. It contains 109 payload files instead of 715 copies
across choices; every byte/path is preserved. Independent checks find 808 valid
layers and no missing/invalid layers or placeholders. No app/guide additions or
runtime loading fix are included.

## Every supplied layout, explicitly requested

The latest user reports five-person “perfect,” six-person returning to portraits,
then requests every match type. The [all-layout per-arena experiment](ALL_AEW_LAYOUTS_TEST.md)
contains all twenty player layouts in all eight supplied Titavius cards: 808
movie layers, with 101 per project. It preserves the existing layer properties
from the later subsets, including Dynamite/Collision's five-person source.
Native/managed checks pass and all 101 placeholder hashes match previously
decoded files. The prior full-layout loading failure is not fixed or explained;
the old download stays withdrawn. Revolution is an explicitly unresolved
experimental option. New full-layout gameplay remains unverified. Keep the
working five-person CAK/input backup and retest it before other modes.

## Other AEW cards: one-on-one / 2v2 / 4v4

The requested three layouts are prepared in separate experimental inputs for
Redemption, Forbidden Door, Dynasty, Double or Nothing and optional ROH Supercard.
Each project contains 14 movie layers; 4v4 has eight participants. All 70
delivered layers and 14 unique placeholder movie decodes pass file checks.
Preserved one-on-one properties do not retest gameplay. Three missing card
records require the current local link export first. Revolution's source was
prepared for analysis but is held from the download after its earlier loading
failures. Other layouts and transitions are unchanged. See
[the per-arena test and bake steps](AEW_THREE_LAYOUT_TEST.md). The small five-person
result and new eight-portrait gameplay remain unverified at packaging time.

## Other matchup-screen preparation

Seven separate one-on-one source candidates are staged and pass native/managed
file checks: Redemption, Dynasty, Double or Nothing, ROH Supercard, Forbidden Door,
the shared Rev SummerSlam project and NOC26 from UIFIXES. The first six match the
earlier individual candidate bytes; this preparation is not a new runtime fix.
NOC26 has no verified arena/background binding. UIFIXES also supplies seven AAA
matchup background movies, but no identified three WWF matchup projects; its
WWF-named files are arena textures/materials/models. See
[the inventory, gates and checks](OTHER_MATCHCARD_READINESS.md). New multi-man
work remains dependent on each card baseline and the small five-person result.

## Current multi-man and background follow-up

The user previously confirmed one-on-one and 2v2 through the corrected Discovery
bake. The subsequent [20-layout expansion](ALL_MATCH_LAYOUTS_TEST.md) is held
after green/mixed portraits and a loading stall/crash in the five-person trial,
with all five GMRs set to Both screens. Another match also got stuck with the all-layout test still installed. Restore and confirm the working CAK first. A
[five-person isolation input](FIVE_PERSON_MATCHCARD_TEST.md) then adds only five
layers per project to the earlier nine-layer input; gameplay is unverified.

The [current-link checker](ARENA_LINK_CHECKER.md) compares card hashes, arena
transition IDs and movie hashes for all eight supplied Titavius shows. The newer
user reports supersede the old metadata: Forbidden Door's links are restored,
and three card records remain absent (ROH Supercard, Dynasty, Double or Nothing)
despite matching arena/movie references. Version 1.2 exports a narrow repair
from current local binaries plus an exact original backup, preserving all
existing rows and leaving the selected source unchanged. Twenty-six repair
checks pass; game playback remains unverified. See [current findings and
bake steps](CURRENT_ARENA_CARD_LINKS.md).

The prebuilt multi-man CAK trial showed static Dynamite triple-threat portraits
while reaching gameplay, then also lost the working one-on-one result. The user
confirmed the older dedicated patch was removed. That prebuilt download is
withdrawn; use the [fresh BakeMe inputs with the working Discovery writer and
output filename](READY_MULTIMAN_MATCHCARD_TEST.md). New multi-man playback is not
yet verified. No other arena UI override is included in that scoped input.

The [complete known-entry finger/mouth catalog](TAUNT_MOTION_CATALOG.md) now
records measured source movement and unresolved associations. The
[original arena-link audit](MOD_ARENA_CARD_LINKS.md) finds the supplied matchup
projects and transition movies for all eight shows. Runtime alternate-attire
switching and batch speed are [reviewed separately](BATCH_AND_ATTIRE_FOLLOWUP.md);
neither is claimed implemented by these data artifacts.

## Included in 1.7.22

The match-card report distinguishes installed-render/file-presence checks from UI
layout and runtime checks, offers Choose GMR for existing saved or installed files,
and points selection-only movies to the bulk screen-setting action. A missing
current selection does not tell users to render their installed movies again.

Enable playback logging changes only the verified native plugin's verbose flag,
with a backup and WWE closed. Diagnostic ZIPs separate runtime logs from optional
mapping inputs, include only known numeric configuration flags, and explicitly
report when no runtime logs were collected. These changes do not establish or fix
the cause of the reported match-loading stall.

## Hand-animation investigation

Stone Cold 1 uses clip 37255a000. The bundled decode and all three available raw
archive variants contain 26 body tracks, zero finger tracks and no supplemental
scalar tracks. Native capture fills missing finger joints with its relaxed-hand
fallback. The game's matching hand-pose/event association has not been established;
this is not claimed fixed in 1.7.22. Existing Jeff Hardy source/capture checks show
that authored finger tracks can be applied when the selected motion supplies them.

Roar follow-up: Roar 2 has an indexed facial file but its native jaw driver is
zero over the active body motion; a native Jeff-model probe reproduces the closed
jaw. Roar 1 has no verified indexed facial association. See
[animation findings](ANIMATION_FOLLOWUP.md). These remain unresolved source/event
associations, not shipped animation fixes.

## Included in 1.7.23

The local Patreon/Discord sign-in requirement and visible Patreon promotions are removed as explicitly authorized. The original StartLicensing wrapper now returns Task.CompletedTask; Unlocked permits the local workflow. Other licensing method bodies, online services and stored accounts/credentials are untouched. Sign-in controls and the paid-access overlay are hidden by the initialization hook. The patcher verifies exactly these two additional method changes and preserves all remaining method bodies and embedded resources. Windows startup, Preview, MAKE, batch and installation without saved credentials remain manual validation items.

Match cards is available from the top toolbar without choosing a model or GMR, with a fresh readonly check and exact prepared project paths. Per-project layer states do not claim verified baking or runtime playback. Entrance gear is the startup default. Bundled-preview metadata parsing is reused only while its exact reread text is unchanged; changed animations retain cache validation.

The actual Rev SummerSlam and Titavius AEW projects are supplied in a separate compatibility pack. Structural checks do not establish a fix for the user's loading stall. Adam Cole's Undisputed source audit is documented in ANIMATION_FOLLOWUP.md. Jimmy Uso's exact selected model/material/texture assets remain unavailable; his reported white hair is not claimed fixed.

## Reported startup crash after compatibility pack

The Rev/Titavius pack has been withdrawn from the main-branch downloads after a
startup crash report following installation/baking. The user subsequently noted
they had placed it in the bake folder to try it and is testing base Game setup UI
alone. Causality is unresolved. No replacement mod-card pack is approved by these
structural checks. Recovery must restore/quarantine the actual baked output, not
merely remove loose inputs. Version 1.7.23 can reimport linked mod projects during
Game setup; do not rerun it over the affected data during recovery. Existing GMRs
are independent and should be retained. Historical pinned artifacts remain
accessible, so this withdrawal does not pretend to revoke them.

## Dynamite / Collision diagnostic download

The user confirms the original arenas work and identifies Dynamite and Collision
as the current baseline tests. Other supplied pack cards have not been established
as working. Prior 3% tests still had MovingRenders.dlp present; a later run removed
both that plugin and the assistant-generated bake, so it was not an isolated
plugin-off control. The later end-of-load crash has no verified cause.

A separate one-on-one diagnostic ZIP adds only two GM movie slots per card,
compared with the withdrawn full-layout version's 101 per project. Both original
background/foreground properties and the other layout leaves are preserved.
The native reader checks the two source hashes and intended pointer changes;
the managed readonly checker recognizes all four existing movie slots, reports
no invalid slots and leaves all four inputs unchanged. It correctly reports
the intentionally omitted other layouts. The ZIP is not a verified loading fix.

Use a fresh four-file input and a new test CAK, keeping all working archives
intact. Do not run full Game setup over the subset. The original GFX movies
remain in the existing mod CAK; their KB2n headers pass size checks but the
available FFmpeg cannot validate their Bink2 bitstreams. No damage is inferred.
The app executable, updater feed and full app packages are unchanged.

## User-confirmed baseline and arena expansion

The user reports that the reduced one-on-one diagnostic reaches gameplay with
moving portraits in both Dynamite and Collision. This is user-reported runtime
validation; Windows/WWE execution here remains unavailable. The successful setup
changed both the UI recipe and bake scope, so it does not prove a sole cause for
the earlier stall. The full 101-layer pack remains withdrawn.

The user clarified that the requested next scope is other arenas in the supplied
pack, not other match types. The modular expansion preserves all four confirmed
inputs byte-for-byte. Eight optional project additions each receive only two
one-on-one movie slots. Native checks retain source bytes except the two player
child pointers, all existing identities and 720 background/other-layout leaves per
added project. The managed readonly check recognizes all 20 existing movie slots
in the combined ten-project corpus without modifying inputs. Additional-arena
gameplay remains unverified. Original arena assets and profiles are required.

Use only the working BakeMe plus one chosen add-on at a time, backing up both the
working input and its generated test CAK outside the game. Keep the test output
filename unchanged and do not stack old/new test CAKs. Full Game setup would add
the omitted layouts, so it is excluded from this test workflow. The stable app,
updater feed, installed GMRs and character mappings are unchanged.

## Ready-to-bake optional packages

The user requested two preassembled choices: Dynamite/Collision only and all
supplied arenas combined. Separate add-on ZIPs now contain complete BakeMe inputs
with 4 and 12 files respectively. Every input matches the earlier modular
expansion byte-for-byte; all four confirmed baseline files match the original
successful diagnostic as well. ZIP integrity, unique member paths, file counts,
per-file SHA-256 values and the exact combined structural-check corpus were
verified during repackaging. No project serialization or native patch changed.

Both choices remain one-on-one only. The combined option includes the supplied
Alberta project but invents no profile or arena ID; an existing link is required.
Only Dynamite and Collision have user-reported gameplay confirmation. Neither
the combined package nor its structural evidence establishes runtime support for
the other shows, tag teams, triple threats or larger matches.

Use one fresh BakeMe input and rebake the same backed-up working test CAK rather
than activating two option archives together. No individual add-on copying is
needed. The original modular download remains available for incremental testing.
The app, updater, installed GMRs and plugins are unchanged.

## Revolution / Dynasty runtime follow-up

The user now reports moving portraits followed by a near-3% loading stall in
Revolution, and a default-card fallback in Dynasty. These are separate symptoms;
the combined expansion is not a confirmed working setup for those shows. A
triple-threat match showing no moving cards is expected for these one-on-one-only
packages, not evidence that triple-threat support has been implemented.

A new audit of the published combined ZIP confirms Revolution has exactly two
GM clips and the correct placeholders, autoplay flags and per-player markers.
Its packaged path matches the supplied profile's exact project hash, and the
original background properties and transition reference remain unchanged. The
four confirmed Dynamite/Collision inputs remain byte-identical. These checks
do not establish what is in the user's active baked archive or why loading stalls.

The user reports that the same Revolution match and bake still stop near 3%
with MovingRenders and optional SelectionLoop removed. The playback plugins are
therefore not required for this reported reproduction; it does not establish a
cause. Redemption is newly reported working. The user requests multi-man layouts
after the current arena issues are resolved; those layouts remain unchanged.

A separate original-card control restores only Revolution's exact author project
inside the same combined input, retaining the other 11 bake files byte-for-byte.
It removes the two added Revolution portrait movies for a controlled comparison
with plugins still unloaded. Original static portraits are expected. The full
fresh BakeMe must replace the test entry's input and rebake the same backed-up
output filename, keeping unrelated CAKs intact. This diagnostic has source,
payload and readonly structure checks, not a verified runtime fix. Its game result
is pending. The uploaded UIFIXES archive remains untouched as requested. No native
plugin, app, updater or profile change was published.

## Return to working baseline and investigate the successful recipe

The user lifted the UIFIXES hold, then reported that Revolution's static control
shows its card and crashes while loading. They request the previous setup and a
deep comparison with the successful Dynamite/Collision fix. The static control
is withdrawn from main-branch downloads; pinned history cannot be revoked. Its
exact generated ZIP is retained privately for comparison. Restore the previous
working dedicated CAK/input and prior plugin state before any new experiment.

All 30 UIFIXES volumes were acquired. The 133 selected JSFB files passed archive
CRC checks; the full 3.16 GB asset payload was not needlessly extracted. Only one
matchup project, NOC26, is present; no AEW profiles or matchup-link table are supplied.
No instructions from archive contents were executed. The NOC26 background hash
does not resolve within the upload and may require existing game/mod assets.

The exact native algorithm reproduces the successful Dynamite/Collision project
hashes and the current released Revolution/Dynasty/Redemption hashes. CAS nodes
are unchanged; SS nodes differ only in the expected marker scales. There is no
found regression to 101 portrait layers. The successful setup also used a small
four-file dedicated UI bake; the combined addon later expanded to ten projects.
That difference remains a real variable, not an established root cause.

A new optional minimal moving test preserves the four working baseline inputs
and adds only Revolution's existing two-slot moving project, for five inputs.
Readonly checks recognize six valid slots without changes or errors. It tests
small bake scope and a fresh generated output under the same dedicated filename;
it does not claim a new source-code fix or verified Revolution gameplay. Source,
package checks and the new ZIP are separate from the stable app/updater. Multi-man
layouts remain separate while the latest crash and recovery are investigated.

## Basic still-picture report and scoped multi-man files

The user reports that the basic pack shows still pictures in a two-wrestler match,
with the DLP restored and enabled 1. The basic ZIP hash and its four source inputs
are unchanged. The arena/participants have not been identified, so this does not
yet establish a regression in the two patched arenas; the basic pack has no
Revolution or other-arena override. Actual baked output and runtime hook/logging
remain unverified. Do not treat source checks as proof of live playback.

The renewed multi-man request has a separate experimental data increment for
normal 2v2 tag and triple threat on Dynamite/Collision, optionally plus Redemption.
Seven added slots per project retain every existing one-on-one node property and
other-layout/background properties. Source-prefix changes are restricted to the
seven new player child-vector pointers. Native checks verify exactly nine total
clips per project, correct markers, placeholder hashes and autoplay. Managed
readonly checks recognize 18 clips in the two-project option and 27 in the
three-project option, with no repairs, failures, unsupported slots or byte changes.
The omitted 92 other slots per project/92 placeholders remain intentional.

The user explicitly requested just the multi-man download to try. These ZIPs are
therefore a separate optional runtime test, with the prior bake retained for
comparison. No new tag/triple gameplay is claimed. Other match types, unresolved
Revolution/Dynasty behavior, native plugins, app/updater and profiles are unchanged.

## Regression audit before 1.7.24

The latest tag/triple trial shows moving selection but static matchup cards,
including one-on-one. The user requested a full comparison with the earlier
working setup. Seven actual packages were compared: the basic pack's four bake
files match the successful diagnostic exactly; later one-on-one data retains
those bytes. Tag/triple changes each project by adding seven movie nodes plus
seven placeholders, while preserving the one-on-one properties. Those runtime
additions can still matter; unchanged old properties are not proof of game
equivalence. None of the data ZIPs changes GMR flags, DLPs, config or program files.
The basic still-picture report predates the tag/triple release, so attributing
the whole regression to that release alone would ignore the observed sequence.

A concrete UI issue was found: Installed renders bulk Show on starts at Roster
selection only. Applying its default writes screens=select and prevents match
cards while retaining selection motion. That operation's effect is covered by
the existing transaction tests. Whether the user applied it is still unknown.
The source default is changed to Both screens, retaining the explicit other
choices. The helper builds with zero warnings/errors and the existing 36 checks
pass, including preservation of video bytes, metadata, unrelated files, backups
and rollback. No test that merely matches a UI source literal was added.

This default fix is queued for the next app build; no app ZIP or updater feed has
been changed in this follow-up. It does not silently rewrite installed GMRs.
The user now reports the checked participant already shows Both screens, so
selection-only does not explain that checked row. The actual GMR metadata,
generated CAK and fresh runtime logs have not been read directly here and are
still needed to establish the cause. No further speculative
UI/data ZIP was generated for this report. Windows/WWE execution remains unavailable.

## Included in 1.7.24: preserve UI after installing renders

The newly received diagnostic finds 59 header-compatible installed GMRs and
enabled/verbose 1, but no selected GMR or runtime logs. It checks the main data
root with 13,433 slots and no missing layouts, not the limited test input. This
is not proof of the loaded game bake.

Normal OnInstall awaited GameSetup(false); the batch completion callback also
called RunCombinedGameSetupAsync. Full layout completion could therefore expand
a limited recipe without an explicit Game setup click. The update redirects
only the native post-copy call to a completed, I/O-free task and removes the
automatic batch setup. Both explicit setup controls remain. Bulk Show on now
defaults to Both screens; existing GMR settings are not automatically rewritten.

The patcher verifies an eight-method allowlist. Only the one five-byte call in
OnInstall.MoveNext may change; all its other IL/header fields and other original
method bodies/resources are compared exactly. Ten real-binary integration checks
confirm both automatic routes are absent and both explicit setup controls remain.
The current failed game CAK/runtime is still unexamined, so this fixes an actual
workflow defect without claiming verified in-game playback. Expanded loose files
and previous bakes must still be restored from a known input or backup.
