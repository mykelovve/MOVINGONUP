# Dynamite and Collision multi-man: keep the working Discovery bake

## Latest user result

The user previously confirmed **one-on-one and 2v2 work** through the corrected
Discovery bake. The later [20-layout expansion](ALL_MATCH_LAYOUTS_TEST.md) is held
after the five-person trial showed green/mixed portraits and loading failure,
with all five GMRs set to Both screens. Another match also got stuck with the all-layout test still installed. Restore and confirm the working CAK first. The
[five-person isolation test](FIVE_PERSON_MATCHCARD_TEST.md) preserves this 11-file
recipe and adds five layers per project only. Its gameplay is unverified. The
failed prebuilt trial below remains historical evidence; its download stays withdrawn.

The prepared `gs_aew_tag_triple.cak` test is **withdrawn** after the user reports
that triple-threat portraits stay static and one-on-one also returns to default
portraits. The user confirms that the new CAK was installed and the older
dedicated patch removed. The supplied 10-second Dynamite triple-threat recording
shows the regular portraits, completes loading and reaches gameplay. It does
not reproduce the earlier 3% loading stall.

The prebuilt archive passes path, payload and marker checks, but this does not
establish whether the game loaded it or why its one-on-one baseline failed.
Its unencrypted header and uncompressed payloads differ from the received
Discovery-produced archive's encrypted header and compressed projects. That
difference is not a proven cause. The next test retains the writer and output
filename that worked for the user.

## Fresh loose-file test

[Download the multi-man BakeMe input](https://github.com/janeg7207-droid/MAKE-A-RENDER-READER/raw/refs/heads/main/downloads/GorillaStudio_Dynamite_Collision_Multiman_BakeMe_Test.zip).

This ZIP supplies 11 inputs with their correct `UI/` prefixes. It contains no
CAK. Select its **BakeMe** folder in the previously working Discovery bake entry:

```text
BakeMe/                  <- Discovery input
  UI/
    Assets/movies/gorilla_renders/  (9 movies)
    Projects/ShowAssets/matchup/    (2 projects)
```

1. Close WWE. Move `gs_aew_tag_triple.cak` outside the game. Back up the working
   dedicated one-on-one CAK and its input outside the game/bake roots, preserving
   the CAK's filename. Keep original arena CAKs/profiles, character/data and GMRs.
2. Use the **same working Discovery bake entry and exact output filename/path**,
   changing its input to this fresh complete BakeMe. Keep the same working
   WWE 2K26/version-9.9 settings. Do not select `UI` itself or the ZIP root.
3. Bake in Discovery. Inspect the resulting CAK for `UI/Assets/...` and
   `UI/Projects/...`. These 11 matchup inputs should be present; Discovery can
   also add an empty `_textures.tdb`. Do not merge main data or UIFIXES into it.
4. Keep one dedicated matchup patch active and the original arena mods installed.
   Do not leave either prebuilt test CAK alongside this output. Do not run full
   Studio Game setup over the reduced input. Fully restart WWE.

| Layout in Dynamite 800 / Collision 801 | Movie slots per project |
| --- | ---: |
| Normal one-on-one | 2 |
| Normal triple threat | 3 |
| Normal 2v2 tag | 4 |

Check the two-player baseline first, then all three/four moving portraits and
reaching gameplay. Every participant needs a valid installed logical-ID GMR
with Match card enabled; valid existing files need no new MAKE. Other layouts
and arenas are outside this test. Multi-man motion remains unverified.

To roll back, close WWE, restore the saved one-on-one CAK under its unchanged
original filename, and restore its saved input before another bake.

## Source and archive checks

The input payloads exactly match the earlier loose-file tag/triple experiment.
Original-engine inspection verifies nine clips per project, exact player markers,
autoplay and placeholder hashes. All prior one-on-one/background node properties
are preserved, and original-prefix changes affect only seven player child
pointers. An independent readonly check recognizes 18 valid movie layers with
zero failures or unsupported structures, without changing bytes. Its 184 omitted
other-layout slots and 92 omitted placeholders are intentional.

The withdrawn prebuilt CAK also re-extracts with the unmodified original reader
to the same 11 payloads and correct asset hashes. Those format checks did not
predict the actual runtime result. Its ZIP was removed from main, along with
the held one-on-one prebuilt writer output. Pinned historical downloads cannot
be revoked. No new plugin, guessed game offsets or GMR changes are prescribed.

See [the measured checks and runtime follow-up](READY_MULTIMAN_MATCHCARD_AUDIT.json).
