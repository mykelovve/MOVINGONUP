# Received full Discovery bake after the startup-crash report

The user reports restoring the previous working CAK makes WWE launch normally.
That is a useful rollback comparison. This environment cannot run WWE and has
not reproduced the startup crash.

All 13 newly supplied archive parts were read as one archive. They contain
`discovery_data.cak`, **616,642,682 bytes**, SHA-256
`2631c416dd52e0de7ff776bf2793becf7c2d98c3bedc8d2a565d045cf4467800`.
The complete archive-member CRC passes. The CAK filename was retained, and the
CAK header and all five index-section checksums pass with the original Bakery
reader. Indexed file paths are unique and their stored ranges remain inside
the file. The received archive was not changed.

## Confirmed source mismatch

This is a **1,113-file full Discovery bake**, including roster, animation,
character and movie tables, **131 UI projects** and **377 layout backup files**.
The backups occupy 173,935,358 stored bytes. Their presence is unnecessary bake
bloat; it is not proof they caused the startup crash.

The received CAK contains neither the Rev SummerSlam project at
`Arena/Rev's_Arenas/SUMMERSLAM_2026/Data/matchup.jsfb` nor the supplied
`NOC26/matchup.jsfb` path. It does not match the withdrawn 17-file SummerSlam
test. A project absent from this override may still be supplied by an original
arena CAK; this is not evidence that the base arena files are missing.

| Inspected project | Actual moving layers |
| --- | ---: |
| Dynamite | 101 |
| Collision | 101 |
| Revolution | 101 |
| Redemption | 101 |

The requested smaller Dynamite/Collision recovery has **14** layers per project.
Those recovery bytes are not installed in this received bake. Comparing the
four earlier layouts inside each received Dynamite/Collision project finds all
380 corresponding node properties unchanged; the expanded layouts remain in
the same project. This establishes the configuration mismatch, not a startup
crash mechanism.

## Actual baked metadata

The three extracted binary tables parse without warnings: 181 card rows,
303 arena rows and 7,329 movie rows. No duplicate card IDs were found.

- Dynamite, Collision, ROH, Dynasty, Double or Nothing and Redemption have the
  expected card/arena/transition chains in this uploaded CAK.
- Revolution 803 and Forbidden Door 807 have card and movie records, but their
  arena rows are absent from this baked ArenaData table. Do not infer a complete
  chain from the card record alone or blindly overwrite other custom tables.
- SummerSlam source ID 254 references the expected Rev project hash. Source
  IDs 255/256 and the NOC26 project hash are not present in this card table.
  Current custom assignments for those variants are not established.

This snapshot concerns the uploaded CAK, which has now been put aside. It does
not describe the restored working archive or prove runtime asset priority.
It supersedes the older loose-table report for this uploaded bake: the earlier
three absent card records are now present, so that old repair is not indicated.

## Three compressed assets still require the actual game decoder

The subsequent UI_2 upload supplies nonempty raw large/small character-selection
sources matching the original Studio bundle. This provides those raw source
templates for inspection, but does not validate or replace the failing compressed
payloads in this earlier CAK. See [the raw-source follow-up](UI2_SOURCE_AUDIT.md).

Nine selected assets decode to nonempty payloads. Three do not:

- `Roster/CharProfileTable.jsfb`
- `UI/Projects/2K23_CharacterSelect/CharacterSelectLargeCards.jsfb`
- `UI/Projects/2K23_CharacterSelect/CharacterSelectSmallCards.jsfb`

Bakery logs an Oodle decompression error, then still returns success and leaves
a zero-byte output file. Those local outputs are **failed extractions**, not
evidence that the original game assets have zero length. A read-only
filename-tail compatibility reader gives the same result with the same decoder.

The available DLL is an **ooz substitute**, not the game's original Oodle DLL.
These failures therefore do not establish corruption or the crash cause. The
next required file is the original game/Discovery **`oo2core_9_win64.dll`** to
repeat the failing decompression checks using the actual decoder. No empty
extraction is used as a replacement game file.

## Preserve the working state

Keep the restored working full-data CAK installed. Keep this received archive
outside loaded folders for inspection. Do not rebake it or overwrite the working
`discovery_data.cak` with a minimal UI-only pack: that omits its roster and other
mod data. A later isolated UI source belongs in a separate dedicated Discovery
bake, preserving the known-working full-data archive and its registered name.
Do not rename an already baked CAK.

Keep layout backups outside the selected bake input. Full Game setup expands
the limited UI recipe again; the requested 14-layer input should be checked as
an isolated scope before a future bake. No repaired CAK or replacement experiment
is supplied while the decoder/startup cause remains unresolved.

See [hashes, counts, exact screen comparisons, decoder limitations and binary-link results](RECEIVED_DISCOVERY_STARTUP_AUDIT.json).
