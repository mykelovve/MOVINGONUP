# Recurring startup-crash report: UI rebake trials held

The user now reports a possible return of the launch crash after the AEW-only
attempt. The exact newest CAK filename, its relationship to the working full
data archive and its actual baked contents have not been supplied yet.

The latest source ZIP passes CRC checks and contains the same 16 game input
files as the earlier smaller source: two AEW projects and 14 movies. It contains
no prebuilt CAK. That source identity does **not** establish the compatibility
of a new bake with the current installation. The exact CAK used during the
original reported five-person success was never supplied.

The three current downloads with those same source payloads are now held:
the AEW-only repack, five-person recovery repack and historical isolation source.
Their exact ZIPs/hashes are preserved privately and in history. Historical
downloaded copies cannot be revoked. Packaging scripts refuse to recreate the
current downloads while this investigation is held. No different replacement
experiment is supplied.

## Restore the known-working installation

Close WWE. If the latest dedicated UI CAK was installed **alongside** the known
working full-data CAK, put aside only that new UI CAK. Keep the original full
data, arena, character, plugin and GMR files.

If it **replaced** the working full-data CAK, restore the actual saved full-data
file under its original baked filename, plus its saved source. A small UI pack
cannot substitute for a full roster/mod-data archive. Do not rename a baked CAK
or keep two dedicated matchup test archives loaded together. Removing loose
input files alone does not undo an installed bake.

An earlier rollback restored normal launch before this newest attempt. That
result does not establish the result of the current rollback; it needs checking
for this attempt.

## Inspect this attempt rather than infer it from the previous one

The next required evidence is:

- The exact latest CAK filename and whether it replaced or accompanied the
  working full-data CAK.
- The actual newly baked CAK, with that baked filename preserved.
- The current startup load report, if available.

The subsequent UI_2 upload has been checked: it is a raw UI folder inside nested
archives, with no baked CAK or output filename. All 127 matchup projects have
101 layers, and the launch result for this exact source is pending. See
[its source scope and CRC checks](UI2_SOURCE_AUDIT.md).

The prior uploaded `discovery_data.cak` has 1,113 files and 101-layer cards.
It is not proof of the contents of this newest UI bake. Its separate
[decoder limitations and metadata findings](RECEIVED_DISCOVERY_STARTUP_AUDIT.md)
remain recorded, including the need for the actual Oodle DLL to finish three
compressed-asset checks. Those unresolved checks must not be presented as the
confirmed cause of this new launch crash.

No live WWE test is available in this environment and no startup fix is claimed.
See [the held-package hashes and exact evidence status](RECURRING_UI_STARTUP_CRASH.json).
