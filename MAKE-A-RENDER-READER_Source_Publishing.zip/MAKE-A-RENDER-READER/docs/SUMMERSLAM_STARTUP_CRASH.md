# SummerSlam test withdrawn after a startup crash

The user reports WWE crashes **when launching** with the new SummerSlam test
installed. This is different from the earlier matchup-screen stalls. The
current test ZIP/checksum downloads are withdrawn. The exact source package is
preserved privately, and no modified replacement is supplied for another blind
trial. Historical commits/downloaded copies cannot be revoked.

**Received-bake follow-up:** restoring the previous CAK makes WWE launch. The
new upload is a 1,113-file `discovery_data.cak`, not the 17-file SummerSlam input;
it has no Rev SummerSlam override and retains 101-layer Dynamite/Collision
projects. Header/index checks pass, but three compressed startup-related assets
do not decode with the available ooz substitute. The game's original Oodle DLL
is needed before calling them corrupt. See
[the actual archive findings and safe recovery scope](RECEIVED_DISCOVERY_STARTUP_AUDIT.md).

## Restore launch first

1. Close WWE completely. Move the newly baked dedicated test CAK outside the
   game's loaded folders. Keep it for inspection with its exact baked filename.
2. Restore the **actual saved CAK that previously launched and worked**, under
   its original filename, plus its saved Discovery input. Keep one dedicated
   matchup override active. Do not remove the original SummerSlam/Titavius arena
   archives, normal character/data archives, MovingRenders or installed GMRs.
3. Start WWE once to check whether the previous bake restores normal launch.
   Restoring loose source files without replacing the new CAK does not undo a
   bake. Do not merge or rebake the withdrawn SummerSlam source.

If no working CAK backup exists, the [earlier smaller recovery input](FIVE_PERSON_RECOVERY.md)
remains available as a source-rebuild option. Use a fresh input with the same
working Discovery entry/output name and version-9.9 settings; this is not a
guaranteed launch fix. Do not run full Game setup or copy the new SummerSlam
project into that recovery input.

## What was checked

The failed source ZIP contains 17 payloads. Compared with the smaller recovery:

- One added payload:
  `Arena/Rev's_Arenas/SUMMERSLAM_2026/Data/matchup.jsfb`.
- Zero removed payloads and zero changed recovery payloads.
- No added plugin, config, profile, CAK, GMR, background or transition payload.

The added project and source ZIP hashes are recorded in
[the startup audit](SUMMERSLAM_STARTUP_CRASH_AUDIT.json). The original smaller
recovery ZIP remains byte-identical. These facts isolate the **source change**;
they do not establish the contents/validity of the actual user-created CAK or
whether it is the only effective change in the game.

## Evidence needed for a concrete fix

The actual CAK and the previous-bake launch result have now been supplied and
checked as above. The remaining immediate dependency is the original
game/Discovery **`oo2core_9_win64.dll`** for the three failing decompression
checks. A current startup load report, if available, may also identify a load
failure. Older load reports predate this trial and do not establish its cause.

No startup crash was reproduced here: this environment cannot run WWE. The
root cause remains unresolved, and passing source checks is not a gameplay
compatibility result.
