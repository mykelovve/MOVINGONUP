# Scoped tag-team and triple-threat card test

**Latest result:** the earlier Discovery bake worked for one-on-one and 2v2.
The later [all-layout expansion](ALL_MATCH_LAYOUTS_TEST.md) is held after a
five-person green/mixed-portrait and loading failure despite all five GMRs set
to Both screens. Restore and confirm the working CAK first. The
[five-person isolation test](FIVE_PERSON_MATCHCARD_TEST.md) keeps this nine-layer
recipe and adds only that layout. Its gameplay is unverified. The earlier
prebuilt trial below remains withdrawn.

The ready-baked Dynamite/Collision test is now **withdrawn** after the user reports
static triple-threat portraits and loss of the working one-on-one result with
that new CAK alone. A recording reaches gameplay. The next test uses the same
11 loose inputs through the user's previously working Discovery writer and
output filename. See [the current BakeMe workflow](READY_MULTIMAN_MATCHCARD_TEST.md).
The earlier recording does not verify triple-threat playback. The user's later
2v2 confirmation concerns the corrected Discovery bake, not that prebuilt CAK.

## Received bake path error

The subsequently supplied `TITAVUSREVATCHCARD-20261024-173411.cak` has now been
opened and its four matchup payloads compared directly. They exactly match the
earlier working **one-on-one** baseline, but their internal paths omit `UI/`.
The project hashes consequently differ from the original arena references. This
is a confirmed bake error; the uploaded CAK does not contain the seven extra
tag/triple movie layers. It therefore cannot establish a new multi-man result.

Use the [working Discovery bake and correct input root](BAKED_MATCHCARD_ROOT_RECOVERY.md)
to restore the one-on-one baseline first. A manual bake input must contain `UI`
as a child. The prebuilt CAK alternatives are withdrawn/held. Keep one dedicated matchup patch
active, with the original arena mods/profiles installed. New playback and match
loading still need the user's test. The older diagnostic capture notes below
describe the evidence available before this CAK was supplied.

The existing basic and combined one-on-one ZIPs do not add movie slots for other
match types. The new separate experiment adds only these layouts:

| Layout | Wrestler slots per project | Scope |
| --- | --- | --- |
| Normal one-on-one | 2 existing | Node properties retained from the earlier moving file. |
| Normal 2v2 tag | 4 added | New optional experiment. |
| Normal triple threat | 3 added | New optional experiment. |

Each project has nine portrait movie slots total. Fatal four-way, handicaps,
larger tags and other layouts retain their existing structures. This is not
blanket multi-man or all-arena support. Game playback/loading remains unverified.

## Latest trial: selection moves, matchup cards stay static

The user tried the new test and reports moving roster selection but static
matchup portraits, including normal one-on-one. This does not establish a
successful tag/triple runtime test. The basic-pack still-picture report came
before this release, so the seven new layers are not sufficient to explain the
earliest report; they could still affect runtime in the new trial. Preserved
one-on-one node values do not prove identical game behavior with extra movies.

The user reports the DLP restored and enabled 1. The active arena/participant
IDs, generated CAK and current runtime logs still have not been inspected. Keep
the current failing bake unchanged while capturing those details. The data ZIPs
do not contain or alter a DLP, config, executable or GMR screen setting.

A separate source review found that Installed renders -> Show on initially
defaults to Roster selection only in the published app. Applying that choice
writes screens=select to the checked installed GMRs, permitting selection and
excluding match cards. The user checked Shown on and reports Both screens, so
selection-only does not explain the current checked row. No screen-setting
rewrite is prescribed for that row. Actual GMR metadata still has not been read
directly here.

Version 1.7.24 defaults this control to Both screens, retaining the explicit
selection-only option. The helper compiles without warnings/errors and the
existing 36 transaction checks pass. Existing GMRs are not automatically changed.

Since the checked row reports Both screens, capture the same run: with WWE closed, use
Check match-card setup -> Choose GMR to select an actual installed participant,
then Enable playback logging. Restart WWE, repeat the exact match and Save
diagnostics. Retain the dedicated generated CAK with its original filename for
inspection. Do not run Game setup or another bake during this capture. See
[the seven-package regression comparison](MATCHCARD_REGRESSION_AUDIT.json).

The received diagnostic has no selected GMR or runtime log. It checks the main
Discovery folder with 13,433 supported player slots and no missing layers, not
the dedicated two-card input. This does not prove the active bake. Both normal
and batch installers could automatically run full setup in 1.7.23; version
1.7.24 removes those automatic paths while retaining explicit setup. Update
Studio before installing more movies, then restore a fresh limited input or
the saved working input/CAK. Updating the app does not reverse prior bakes.

## Two optional inputs

- `GorillaStudio_Dynamite_Collision_Tag_Triple_Test.zip`: 2 projects and 9 shared
  placeholders, for 11 bake files.
- `GorillaStudio_Dynamite_Collision_Redemption_Tag_Triple_Test.zip`: 3 projects
  and the same 9 placeholders, for 12 bake files.

Only original arena mods/profiles already installed are used. No arena assignment,
Revolution/Dynasty repair, native plugin, stock global UI or app update is supplied.
The Redemption source is the same earlier one-on-one project the user reported
working, with the seven additional player layers applied.

## Verification

The original native patch routine appends only four tag and three triple layers
to each earlier one-on-one file. Checks verify:

- All original node identities and every one-on-one node property remain present.
- Original-prefix changes affect only the seven selected player child pointers.
- Other layouts and original background/foreground properties are preserved.
- Exactly nine GM clips exist, restricted to the three intended layouts.
- Every clip has the native expected placeholder hash, player marker and autoplay.
- Nine placeholder files match the original supplied screen bank, including the
  two byte-identical one-on-one placeholders.

The managed checker independently recognizes 18 existing clips in the two-project
option and 27 in the three-project option. Both readonly passes report zero
failures, unsupported slots or repairs and leave all input bytes unchanged. Their
184/276 omitted full-layout slots and 92 omitted placeholders are intentional.
These checks do not retest one-on-one gameplay or establish new tag/triple gameplay.

## Current basic-pack still pictures

The latest report is a normal two-wrestler match with the DLP restored and enabled 1.
The tested arena and wrestler IDs have not yet been identified. The basic four-file
ZIP is unchanged and patches only Dynamite/Collision; another arena needs its own
project override. The user bake and loaded hook are not observable here. Calling
this a confirmed basic-project regression would be premature without that context.

Keep the current failing bake unchanged for inspection. Verify the arena scope,
then use Enable playback logging, restart WWE, reproduce the exact match and
Save diagnostics if one-on-one remains static in a patched arena. This enables
verbose logging only; do not run full Game setup or bake a new set during that
capture. `_scan_ids.txt` is optional mapping input, not a generated runtime log.

## Optional runtime test

The user requested the multi-man files directly. Keep the current basic bake as
a backup so the new layout experiment can be compared independently; no repair
of the existing still-picture issue is claimed by these files.

Close WWE, back up the working dedicated test CAK and input outside the game/bake
roots, and move only that generated output out before rebuilding. Select one
option's fresh complete BakeMe, both Arena and UI when present. Use WWE 2K26/v9.9
and the same dedicated output filename. Do not merge inputs, replace a main data
or original arena CAK, or keep old/new test CAKs active together. Keep the original
arena mods and unrelated CAKs intact. Do not run full Studio Game setup over this
partial recipe; its repairs would change the scope.

Use the previously working playback-plugin state and fully restart WWE. Confirm
one-on-one still loads, then normal triple threat and normal 2v2 tag. Every wrestler
needs an installed GMR targeting the logical roster ID with Match card enabled.
Judge each test by both moving portraits and reaching gameplay. More players
will not gain motion merely because another participant has a valid GMR.

Restore the saved CAK under its original filename and its saved input with WWE
closed to roll back. Keep the existing one-on-one backup until the added layouts
have actual runtime confirmation. No WWE execution was possible here.
