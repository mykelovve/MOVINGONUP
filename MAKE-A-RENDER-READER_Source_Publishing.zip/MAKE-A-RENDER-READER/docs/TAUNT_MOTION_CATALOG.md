# Finger and mouth source catalog

[Download the searchable catalog and CSV lists](https://github.com/janeg7207-droid/MAKE-A-RENDER-READER/raw/refs/heads/main/downloads/GorillaStudio_Taunt_Finger_Mouth_Catalog.zip).
Open `Taunt_catalog.html` locally to search by taunt name, alias or exact clip.
The page works offline and includes filters and pagination. Separate CSV files
list moving fingers, indexed mouth curves, jaw movement and unresolved sources.

| Result | Entries |
| --- | ---: |
| Known taunt entries examined | 1,586 |
| Verified changing finger rotations | 610 |
| Exact indexed sources with changing mouth-related curves | 884 |
| Changing male jaw driver | 679 |
| Changing female jaw driver | 673 |
| Changing jaw driver in either gender source | 783 |
| No main finger tracks in available body source | 901 |
| Unsupported body records without a bundled decode | 69 |
| Missing body sources | 6 |
| No verified per-taunt facial link | 702 |

The inventory combines 1,584 canonical CAM definitions with two additional
original-library entries, Warming Up 2 and Nathan Frazer 1. All 1,578 available
raw body records, 894 bundled body decodes and 1,768 indexed gender face files
were checked. The raw-only finger count was 607. Bundled Warming Up 2, Nathan
Frazer 1 and Sid Justice 2 supply three additional verified moving-finger clips.
No raw/bundled finger-track count mismatch was found among matching sources.

Finger joints are the 38 exact non-stub names from the supplied model skeleton,
matched by the same case-sensitive FNV-1a-64 IDs. Movement requires a normalized
quaternion change greater than 0.01 degrees, treating equivalent opposite-sign
quaternions equally. The bundled cuts were also measured separately.

The face analysis follows the original renderer's 121-channel name map and
verifies its source-ID order across every file. Mouth-related curves and the
`au027_u` jaw driver are measured separately over the body/cut interval and
indexed face offset. A full-file facial peak outside that interval does not
establish visible movement during the taunt.

Important exact examples:

- Undisputed 2 (`62541a000`) and Stone Cold 1 (`37255a000`) contain no finger
  tracks in their inspected body clips. The separate game hand-pose/event
  associations remain unresolved.
- Jeff Hardy 2 (`62247a001`) contains verified changing finger rotations.
- Roar 2 (`62436a000`) has changing mouth-related curves, but its male jaw
  driver does not vary in the active body interval.
- Roman Reigns 1 (`37435a000`) has changing finger rotations, but no verified
  indexed facial association was found in the supplied data.

These are source findings. A changing curve still needs the correct model
morphs and runtime association to affect a render. Missing main tracks or an
unresolved facial link do not establish that the game lacks a separate authored
source. Unsupported/unprovided banks remain labeled; no guessed gesture or
generated talking loop is supplied. This catalog does not ship an animation,
application or plugin fix.

ZIP CRCs, file checksums, list counts and exact regression examples pass. The
page's script syntax, search, filters and pagination were checked with a DOM
harness; an actual browser render was not executed. `EVIDENCE.json` includes
source hashes and measured ranges. See [the concise audit summary](TAUNT_MOTION_CATALOG_SUMMARY.json).
