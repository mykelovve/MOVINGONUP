# Uploaded UI_2 source inspection

`UI_2.7z.001` is complete as one volume. It contains another archive,
`UI.7z`, whose member CRC passes. The inner archive contains **281 files**:
129 JSFB UI projects and 152 movie placeholders, totalling 112,436,528 bytes.
Every inner file's complete payload matches its archive CRC. Original uploaded
files were not modified. No replacement pack was made.

## Expanded UI scope

All **127 matchup projects** parse with the native screen hierarchy reader,
and each contains **101 `GM_clip` layers** across the full layout recipe. This
is 12,827 matchup movie layers across the source pack, rather than the smaller
14-layer Dynamite/Collision source. No hierarchy parse errors were found in
those 127 projects. That does not establish current-game startup compatibility.

The remaining two projects are the large and small character-selection screens.
Their headers/root tables were checked, and their full SHA-256 hashes match the
unmodified templates supplied with the original Studio bundle. Their complete
large hierarchies were not audited here, and matching the bundle is not a
comparison with the current game's vanilla assets.

| Selection source | Bytes | Matches original Studio bundle |
| --- | ---: | --- |
| `CharacterSelectLargeCards.jsfb` | 9,385,160 | Yes |
| `CharacterSelectSmallCards.jsfb` | 32,083,464 | Yes |

These raw selection sources are nonempty. Their presence does not validate the
compressed copies that failed the local substitute decoder in the earlier
received CAK. No extracted zero-byte failure is used as a source asset.

The 152 movie files have consistent Bink headers. Their complete contents are
identical when only the layout/slot FPS header fields are ignored. The one
distinct video-content group was fully decoded successfully with FFmpeg. This
checks placeholder content, not the game's renderer or original Oodle decoder.

## Four AAA project/background joins now identified

Unlike UIFIXES alone, this upload supplies actual AAA matchup projects. Their
`bg` movie hashes exactly match four CRC-verified movies from UIFIXES:

| Project | Background movie from UIFIXES | Hash |
| --- | --- | --- |
| `AAA_2026.jsfb` | `AAA_2026.bk2` | `04CA83CFEB3244C3` |
| `AAA_NocheDeLosGrandes.jsfb` | `AAA_NocheDeLosGrandes.bk2` | `B14B111F1EC48A69` |
| `AAA_OlaDeCalor.jsfb` | `AAA_OlaDeCalor.bk2` | `67B7B5CEAAB94023` |
| `AAA_ReyDeReyes.jsfb` | `AAA_ReyDeReyes.bk2` | `40EBFC602D3FE9A4` |

The project paths are under `UI/Projects/ShowAssets/matchups/`; their original
movie paths are under `UI/Assets/Movies/matchups/`. The actual AAA background
movies are not inside UI_2: its movie files are the moving-render placeholders.
They are available in the earlier UIFIXES upload, whose movie member CRCs were
checked separately. Source path/hash joins do not assign a show automatically.

The earlier, now-set-aside `discovery_data.cak` has 181 card records. None of
those records points directly to these four AAA project-path hashes. That is a
reference check against that older bake, not the restored running game. Current
show/profile bindings still need establishing before an AAA installation.

## Relation to the current startup investigation

This upload contains **UI source**, with no baked CAK, roster tables or
CreateShow table. It has no Dynamite/Collision, Rev SummerSlam 2026 or NOC26
override at the supplied canonical project paths. All its project paths also
appear in the earlier broad full-data CAK's index; that path inventory does not
prove identical payloads or identify the newest bake.

The launch result after baking this exact folder has been asked for and has
not yet been supplied. The actual newest CAK and its output filename remain
unverified. All rebake trial releases stay held; this audit neither installs
files nor establishes a startup fix.

See [source hashes, CRC coverage, exact placeholder checks and AAA links](UI2_SOURCE_AUDIT.json).
