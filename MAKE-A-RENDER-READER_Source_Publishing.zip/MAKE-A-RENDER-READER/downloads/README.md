# ZIP downloads

App/helper **1.7.24** preserves existing UI when installing normal or completed
batch renders. Both explicit setup controls remain available, and bulk Show on
defaults to Both screens. Updating does not restore existing loose UI/baked CAKs
or rewrite installed GMR metadata. See [the install/setup fix](../docs/INSTALL_UI_SETUP_REGRESSION.md).

The full program ZIP contains the separate experimental v1.0.2 build. It uses Git LFS; use the direct download link in the repository README, or install Git LFS before cloning.

The small update ZIP requires a separate copy of the original GorillaStudio v1.0.2 folder. Keep its engine, data and plugin files. It does not apply to v1.0.

The source ZIP contains the helper, patcher and tests. The checksum file lists SHA-256 values for all three ZIPs.

This is an experimental build. The Windows GUI smoke test and complete game-backed rendering remain unverified; details are in the main README and the ZIP's TEST_RESULTS.json.

The Rev SummerSlam / Titavius AEW compatibility ZIP is withdrawn after a reported
startup crash following installation/baking. The cause is still being investigated.
Do not install or rebake that pack. Restore your previous baked CAK, or quarantine
only a separate CAK created for this pack. Removing loose files alone does not
undo a bake. Keep your GMR files. Older pinned links remain historical artifacts;
the main-branch pack and checksum have been removed. Studio 1.7.23 Game setup can
reimport these projects, so use the previous working UI for recovery.

`GorillaStudio_Dynamite_Collision_1v1_Diagnostic.zip` is a separate experimental
loading test. Its BakeMe folder has exactly four files for Dynamite 800 and
Collision 801 one-on-one cards. Follow its README to create a separate test CAK
without overwriting working archives. It is not a verified game fix. No full app
or updater change is supplied, and the full compatibility pack stays withdrawn.

The user subsequently confirmed the reduced one-on-one diagnostic in both
Dynamite and Collision, including moving portraits and gameplay.

`GorillaStudio_Rev_Titavius_1v1_Expansion_Test.zip` extends that same one-on-one
recipe to the other supplied arena projects. Its BakeMe is the exact four-file
working baseline. Copy one installed arena's Add-ons contents into BakeMe, then
rebake the existing test CAK after backing it up outside the game. Do not bake
the whole ZIP or overwrite unrelated CAKs. Eight optional project additions are
included; the original arena mods/profiles are still required. Additional-arena
gameplay remains unverified, and other match types are unchanged.

## Ready-to-bake optional choices

- `GorillaStudio_Dynamite_Collision_1v1_Addon.zip`: Dynamite and Collision only,
  with the exact four user-confirmed baseline input files.
- `GorillaStudio_Rev_Titavius_All_Arenas_1v1_Addon.zip`: all supplied Rev/Titavius
  projects combined in one BakeMe folder (10 projects and 2 placeholders).
  Includes SummerSlam Day/Evening/Night through its shared project and the
  supplied Alberta variant, which requires an existing profile link.

These repackage the modular expansion's unchanged inputs. Choose ONE option and
use its complete BakeMe as the input for the working test bake entry. Back up
the working test CAK and input outside the game, then rebake that SAME output
filename. Do not stack both options, merge their folders, bake the ZIP root or
run full Studio Game setup over this subset. Original arena mods/profiles are
required. Only one-on-one is patched; tag-team, triple-threat and larger-match
layouts are unchanged. Additional-arena gameplay remains unverified.

Each ZIP includes instructions, canonical project paths, exact input hashes,
verification scope and SHA-256 checksums. The stable application/updater and
native plugins are unchanged.

Latest feedback: Redemption is reported working. Revolution shows moving portraits
but stalls near 3%, including a reported repeat with playback plugins unloaded;
Dynasty falls back to the default card. The combined download is not a confirmed
working setup for those two arenas. Keep the confirmed Dynamite/Collision baseline available.
Triple-threat cards remain static because neither option adds that match layout.
See [the current arena test record](../docs/ARENA_MATCHCARD_TESTS.md) for the
separate runtime findings.

`GorillaStudio_Revolution_Original_Card_Control.zip` is WITHDRAWN after the user
reports that its static card appears and loading crashes. The main-branch ZIP
and checksum are removed; pinned historical copies cannot be revoked. Restore
the known-working dedicated test CAK/input backup and prior plugin state first.
The existing Dynamite/Collision-only add-on is unchanged.

`GorillaStudio_Revolution_1v1_Minimal_Test.zip` repeats the narrow moving recipe
using five inputs: the exact working Dynamite/Collision baseline plus Revolution
alone. Revolution's project bytes match the earlier moving add-on. This tests
reduced bake scope and a fresh dedicated output; it is not a verified fix. Back
up and move the prior GENERATED TEST CAK outside the game, then rebuild this
complete fresh BakeMe to the same dedicated test filename using the previously
working playback-plugin state. Do not merge inputs, run full Studio Game setup
or replace the main data/original arena CAKs. Read the included instructions.
No other match layout or plugin/app update is supplied.

All 30 UIFIXES volumes are now available and 133 selected data files passed
extraction CRC checks. The upload contains one NOC26 matchup project and no
AEW profile or CreateShow matchup-link table. It is not a supplied full AEW
assignment repair. See the [UIFIXES audit](../docs/UIFIXES_AUDIT.json).

## Scoped tag-team / triple-threat test

- `GorillaStudio_Dynamite_Collision_Tag_Triple_Test.zip`: Dynamite and Collision,
  2 projects and 9 shared placeholders, for 11 bake inputs.
- `GorillaStudio_Dynamite_Collision_Redemption_Tag_Triple_Test.zip`: the same
  layouts plus Redemption, 3 projects and 9 placeholders, for 12 bake inputs.

Each project contains normal one-on-one, normal 2v2 tag and normal triple-threat
movie layers only: nine slots total. The existing one-on-one node properties and
background/foreground properties are preserved. The new seven player slots and
placeholders pass native and readonly managed checks; gameplay is unverified.
Other multi-man layouts and other arenas are not patched by these ZIPs.

The latest basic-pack still-picture report is a two-wrestler match with the DLP
and enabled 1 reportedly restored; the tested arena/participants are unknown.
The basic pack patches only Dynamite/Collision. Preserve that failing bake in a
backup before trying these new layouts; the user requested the multi-man test.
These are not a fix for unloaded hooks, missing GMRs or an incorrect active bake.

Choose one optional test ZIP and follow its included README using a fresh complete
BakeMe and backed-up dedicated test CAK. Do not merge options or run full Studio
Game setup over the intentionally limited recipe. Original arena mods/profiles
and card-enabled installed GMRs for each participant are required. The app,
updater and native plugin are unchanged.

Latest trial: the user reports selection moving but matchup cards static,
including one-on-one. These experiments are not confirmed playback fixes. A
seven-package audit preserves the exact basic baseline bytes and identifies the
additional movie layers as a separate runtime change, not proof of equivalence.
The older app's bulk Show on default was Roster selection only; applying it
could produce selection-only installed GMRs. Version 1.7.24 defaults it to
Both screens; existing movies are not automatically changed. The user
reports the checked row already says Both screens, so selection-only does not
explain that row. Collect the current generated CAK/runtime report before
another speculative bake. See [the audit](../docs/MATCHCARD_REGRESSION_AUDIT.json).
