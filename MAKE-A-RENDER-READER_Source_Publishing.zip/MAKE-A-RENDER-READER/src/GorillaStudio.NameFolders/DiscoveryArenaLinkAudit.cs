using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace GorillaStudio.NameFolders
{
    // Read the binary tables that Discovery bakes. JSON exports may be older and
    // must never silently replace a missing or malformed binary record here.
    public static class DiscoveryArenaLinkAudit
    {
        public sealed class ExpectedLink
        {
            public int ArenaId { get; private set; }
            public string Show { get; private set; }
            public string ProjectPath { get; private set; }
            public string ProjectHash { get; private set; }
            public uint MovieId { get; private set; }
            public string MoviePath { get; private set; }
            public string MovieHash { get; private set; }

            internal ExpectedLink(int id, string show, string project, string projectHash, string movieHash)
            {
                ArenaId = id; Show = show; ProjectPath = project; ProjectHash = projectHash;
                MovieId = (uint)(id * 100 + 95); MovieHash = movieHash;
                string folder = new Dictionary<int, string> {
                    { 800, "800_-_AEW_Dynamite_2026" }, { 801, "801_-_AEW_Collision_2026" },
                    { 803, "803_-_AEW_Revolution_2026" }, { 804, "804_-_ROH_Supercard_of_Honor_2026" },
                    { 805, "805_-_AEW_Dynasty_2026" }, { 806, "806_-_Double_or_Nothing_2026" },
                    { 807, "807_-_AEW_Forbidden_Door_2026" }, { 808, "808_-_AEW_Redemption_2026" }
                }[id];
                MoviePath = "Arena/Titavius/" + folder + "/Movie/Transition.bk2";
                if (HashPath(ProjectPath) != ProjectHash || HashPath(MoviePath) != MovieHash)
                    throw new InvalidDataException("The supplied-profile reference does not match its exact virtual path.");
            }
        }

        public sealed class Row
        {
            public int ArenaId { get; set; }
            public string Show { get; set; }
            public string CardLink { get; set; }
            public string ArenaTransitionLink { get; set; }
            public string MovieLink { get; set; }
            public string ActualProjectHashes { get; set; }
            public string ActualTransitionIds { get; set; }
            public string ActualMovieHashes { get; set; }
            public string ExpectedProjectHash { get; set; }
            public uint ExpectedTransitionId { get; set; }
            public string ExpectedMovieHash { get; set; }
            public string ProjectPath { get; set; }
            public string TransitionPath { get; set; }
            public string LooseProject { get; set; }
            public string LooseTransition { get; set; }
            public string PathWarning { get; set; }
            public bool BinaryLinksMatchSuppliedProfile { get; set; }
        }

        public sealed class Report
        {
            public string CheckedRoot { get; set; }
            public string CheckedUtc { get; set; }
            public List<Row> Arenas { get; } = new List<Row>();
            public List<string> Tables { get; } = new List<string>();
            public List<string> Warnings { get; } = new List<string>();
            public string Limit { get; } = "Loose binary references and file headers only. Original-source profiles are the comparison baseline, not proof that an edited reference is wrong. Files may remain in CAKs. Winning baked archives, transitions, movie decoding and in-game playback are unverified.";
        }

        public static IReadOnlyList<ExpectedLink> SuppliedLinks { get; } = new[] {
            new ExpectedLink(800, "Dynamite", "UI/Projects/ShowAssets/matchup/AEW_Dynamite_2026.jsfb", "2380C945533596CA", "45C408A0D1E4A474"),
            new ExpectedLink(801, "Collision", "UI/Projects/ShowAssets/matchup/AEW_Collision_2026.jsfb", "B9684E1CC73CF513", "26E16AAF8E35F598"),
            new ExpectedLink(803, "Revolution", "Arena/Titavius/803_-_AEW_Revolution_2026/Interface/Matchup/matchup_aewrevolution_26.jsfb", "FBD326AF3588DB9E", "CBA7EA1C2DD89ACB"),
            new ExpectedLink(804, "ROH Supercard of Honor", "Arena/Titavius/804_-_ROH_Supercard_of_Honor_2026/Interface/Matchup/matchup_rohsupercardofhonor_26.jsfb", "B2ECCCAA25103919", "7AE3E59C8BCB3261"),
            new ExpectedLink(805, "Dynasty", "Arena/Titavius/805_-_AEW_Dynasty_2026/Interface/Matchup/matchup_aewdynasty_26.jsfb", "5F49C7CFCD20A530", "327AA2DCF3E957EC"),
            new ExpectedLink(806, "Double or Nothing", "Arena/Titavius/806_-_Double_or_Nothing_2026/Interface/Matchup/matchup_doubleornothing_26.jsfb", "342FF29B4876B646", "5C769FEDCB0F0D54"),
            new ExpectedLink(807, "Forbidden Door", "Arena/Titavius/807_-_AEW_Forbidden_Door_2026/Interface/Matchup/matchup_aewforbiddendoor_26.jsfb", "325DFF3E0E980AE3", "85F2AAEB81A8590E"),
            new ExpectedLink(808, "Redemption", "Arena/Titavius/808_-_AEW_Redemption_2026/Interface/Matchup/matchup_redemption_26.jsfb", "CEA7666BC0CAA4CA", "C0312544DB333782")
        };

        public static Report Read(string root)
        {
            if (string.IsNullOrWhiteSpace(root) || !Directory.Exists(root)) throw new DirectoryNotFoundException("Select the full Discovery data folder containing Arena, CreateShow and Movies.");
            root = Path.GetFullPath(root);
            var report = new Report { CheckedRoot = root, CheckedUtc = DateTime.UtcNow.ToString("o", CultureInfo.InvariantCulture) };
            var cards = ReadValues(root, "CreateShow/MatchUpScreenAsset.jsfb", "StCr", false, 1, 0, 4, 4, 8, report);
            var arenas = ReadValues(root, "Arena/ArenaData.jsfb", "Aren", false, 0, 2, 2, 3, 4, report);
            var movies = ReadValues(root, "Movies/MovieDataTable.jsfb", "Movi", true, 0, 0, 4, 4, 8, report);
            foreach (ExpectedLink expected in SuppliedLinks)
            {
                List<ulong> card = null, arena = null, movie = null;
                bool hasCard = cards != null && cards.TryGetValue((uint)expected.ArenaId, out card);
                bool hasArena = arenas != null && arenas.TryGetValue((uint)expected.ArenaId, out arena);
                // If the arena row is absent, still show whether its expected movie
                // exists, explicitly without calling the complete chain linked.
                uint movieId = hasArena && arena.Count == 1 ? checked((uint)arena[0]) : expected.MovieId;
                bool hasMovie = movies != null && movies.TryGetValue(movieId, out movie);
                var row = new Row {
                    ArenaId = expected.ArenaId, Show = expected.Show,
                    ExpectedProjectHash = expected.ProjectHash, ExpectedTransitionId = expected.MovieId,
                    ExpectedMovieHash = expected.MovieHash, ProjectPath = expected.ProjectPath,
                    TransitionPath = expected.MoviePath,
                    ActualProjectHashes = Format(card, true), ActualTransitionIds = Format(arena, false), ActualMovieHashes = Format(movie, true),
                    CardLink = Status(cards, card, ulong.Parse(expected.ProjectHash, NumberStyles.HexNumber, CultureInfo.InvariantCulture)),
                    ArenaTransitionLink = Status(arenas, arena, expected.MovieId),
                    MovieLink = Status(movies, movie, ulong.Parse(expected.MovieHash, NumberStyles.HexNumber, CultureInfo.InvariantCulture))
                        + (hasArena && arena.Count == 1 ? " (arena's current movie ID " + movieId + ")" : " (expected movie ID; arena chain unresolved)"),
                    LooseProject = CheckLoose(root, expected.ProjectPath, false),
                    LooseTransition = CheckLoose(root, expected.MoviePath, true),
                    PathWarning = Misrooted(root, expected.ProjectPath) + Misrooted(root, expected.MoviePath)
                };
                row.BinaryLinksMatchSuppliedProfile = hasCard && card.Count == 1 && row.ActualProjectHashes == expected.ProjectHash
                    && hasArena && arena.Count == 1 && arena[0] == expected.MovieId && hasMovie && movie.Count == 1 && row.ActualMovieHashes == expected.MovieHash;
                report.Arenas.Add(row);
            }
            return report;
        }

        // A null map means the table could not be read, while an empty map is a
        // readable table with no rows. Neither is reported as ready.
        private static Dictionary<uint, List<ulong>> ReadValues(string root, string path, string identifier, bool nested,
            int vector, int idField, int idWidth, int valueField, int valueWidth, Report report)
        {
            try
            {
                string found = Locate(root, path);
                if (found == null) throw new FileNotFoundException("Binary table not found. JSON exports are not substituted.");
                if (new FileInfo(found).Length > 128 * 1024 * 1024) throw new InvalidDataException("Table exceeds the 128 MiB limit.");
                byte[] bytes = File.ReadAllBytes(found); var file = new FlatBufferFile(bytes, identifier);
                int table = file.Root;
                if (nested)
                {
                    int field = Sized(file, table, 0, 4);
                    if (field == 0) throw new InvalidDataException("Movie definitions table is absent.");
                    uint offset = file.U32(field);
                    if (offset < 4 || offset > int.MaxValue - field) throw new InvalidDataException("Invalid movie definitions offset.");
                    table = checked(field + (int)offset);
                }
                var result = new Dictionary<uint, List<ulong>>(); int rows = 0;
                foreach (int row in file.Tables(table, vector))
                {
                    rows++;
                    int idAt = Sized(file, row, idField, idWidth), valueAt = Sized(file, row, valueField, valueWidth);
                    uint id = idAt == 0 ? 0 : idWidth == 2 ? file.U16(idAt) : file.U32(idAt);
                    if (id == 0) continue;
                    ulong value = valueAt == 0 ? 0 : valueWidth == 8 ? file.U64(valueAt) : file.U32(valueAt);
                    List<ulong> values; if (!result.TryGetValue(id, out values)) result.Add(id, values = new List<ulong>());
                    values.Add(value);
                }
                using (var hash = SHA256.Create()) report.Tables.Add(path + ": " + rows + " rows; SHA256 " + BitConverter.ToString(hash.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant());
                return result;
            }
            catch (Exception error) when (error is IOException || error is InvalidDataException || error is UnauthorizedAccessException || error is ArgumentException || error is InvalidOperationException || error is OverflowException)
            { report.Warnings.Add(path + ": " + error.Message); return null; }
        }

        private static string Status(Dictionary<uint, List<ulong>> map, List<ulong> values, ulong expected)
        {
            if (map == null) return "Table unavailable";
            if (values == null) return "Record absent";
            if (values.Count != 1) return "Duplicate records - ambiguous";
            if (values[0] == 0) return "No link (zero)";
            return values[0] == expected ? "Matches supplied profile" : "Different from supplied profile";
        }

        private static string Format(List<ulong> values, bool hex)
        { return values == null ? "" : string.Join(", ", values.Select(value => value.ToString(hex ? "X16" : "D", CultureInfo.InvariantCulture))); }

        private static int Sized(FlatBufferFile file, int table, int index, int width)
        {
            int field = file.Field(table, index); if (field == 0) return 0;
            int vt = checked(table - file.I32(table));
            if ((long)field + width > (long)table + file.U16(vt + 2)) throw new InvalidDataException("Field extends beyond its table.");
            return field;
        }

        private static string Locate(string root, string relative)
        {
            string current = root; string[] parts = relative.Split('/');
            for (int i = 0; i < parts.Length; i++)
            {
                if (!Directory.Exists(current)) return null;
                current = (i == parts.Length - 1 ? Directory.GetFiles(current) : Directory.GetDirectories(current))
                    .FirstOrDefault(path => Path.GetFileName(path).Equals(parts[i], StringComparison.OrdinalIgnoreCase));
                if (current == null) return null;
            }
            return current;
        }

        private static string CheckLoose(string root, string relative, bool movie)
        {
            try
            {
                string path = Locate(root, relative);
                if (path == null) return "Not loose here; may be stored in a CAK";
                using (var stream = File.OpenRead(path))
                {
                    byte[] bytes = new byte[44]; int count = 0;
                    while (count < bytes.Length) { int got = stream.Read(bytes, count, bytes.Length - count); if (got == 0) break; count += got; }
                    if (!movie) return count >= 8 && Encoding.ASCII.GetString(bytes, 4, 4) == "Scre" ? "Scre header present; content/playback unverified" : "Unexpected or truncated project header";
                    if (count < 44) return "Truncated movie header";
                    string magic = Encoding.ASCII.GetString(bytes, 0, 4);
                    if ((!magic.StartsWith("BIK", StringComparison.Ordinal) && !magic.StartsWith("KB2", StringComparison.Ordinal))
                        || (long)BitConverter.ToUInt32(bytes, 4) + 8 != stream.Length
                        || BitConverter.ToUInt32(bytes, 8) == 0 || BitConverter.ToUInt32(bytes, 20) == 0 || BitConverter.ToUInt32(bytes, 24) == 0
                        || BitConverter.ToUInt32(bytes, 28) == 0 || BitConverter.ToUInt32(bytes, 32) == 0) return "Inconsistent movie signature/length/frame/rate header";
                    return magic + " header consistent; decoding/playback unverified";
                }
            }
            catch (Exception error) when (error is IOException || error is UnauthorizedAccessException) { return "Could not read: " + error.Message; }
        }

        private static string Misrooted(string root, string relative)
        {
            if (Locate(root, relative) != null) return "";
            string alternative = relative.StartsWith("UI/", StringComparison.Ordinal) ? relative.Substring(3) : "UI/" + relative;
            return Locate(root, alternative) == null ? "" : "Found at " + alternative + "; its virtual hash differs from the expected path. ";
        }

        public static string HashPath(string path)
        {
            ulong value = 14695981039346656037UL;
            unchecked { foreach (byte item in Encoding.UTF8.GetBytes(path.Replace('\\', '/').ToLowerInvariant())) { value ^= item; value *= 1099511628211UL; } }
            return value.ToString("X16", CultureInfo.InvariantCulture);
        }
    }
}
