using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace GorillaStudio.NameFolders
{
    // Exports an optional repair beside an untouched backup; never edits the
    // selected Discovery root. Only absent cards with verified arena/movie
    // bindings are eligible. Existing or conflicting cards remain unchanged.
    public static class DiscoveryCardLinkRepair
    {
        public sealed class ExportResult
        {
            public string Directory { get; internal set; }
            public string RepairedTable { get; internal set; }
            public string OriginalTable { get; internal set; }
            public int OriginalRows { get; internal set; }
            public int ResultRows { get; internal set; }
            public int[] AddedArenaIds { get; internal set; }
            public string OriginalSha256 { get; internal set; }
            public string RepairedSha256 { get; internal set; }
        }

        private static readonly string[] SourceTables = { "CreateShow/MatchUpScreenAsset.jsfb", "Arena/ArenaData.jsfb", "Movies/MovieDataTable.jsfb" };

        public static int[] Eligible(DiscoveryArenaLinkAudit.Report report)
        {
            if (report == null || report.Warnings.Count != 0) return new int[0];
            return report.Arenas.Where(row => row.CardLink == "Record absent"
                && row.ArenaTransitionLink == "Matches supplied profile"
                && row.MovieLink.StartsWith("Matches supplied profile (arena's current movie ID ", StringComparison.Ordinal)
                && row.ActualMovieHashes == row.ExpectedMovieHash)
                .Select(row => row.ArenaId).OrderBy(id => id).ToArray();
        }

        public static ExportResult Export(string root, string output)
        {
            root = Path.GetFullPath(root); output = Path.GetFullPath(output);
            if (Inside(root, output)) throw new IOException("Export the repair outside the checked Discovery data root.");
            if (System.IO.Directory.Exists(output) || File.Exists(output)) throw new IOException("Choose a new export folder to preserve existing files.");
            string[] paths = SourceTables.Select(relative => Find(root, relative)).ToArray();
            byte[][] snapshots = paths.Select(ReadBounded).ToArray();
            var report = DiscoveryArenaLinkAudit.Read(root);
            int[] ids = Eligible(report);
            if (ids.Length == 0) throw new InvalidDataException("No absent card records have verified matching arena/transition references. No files were changed.");
            foreach (int id in ids)
            {
                var row = report.Arenas.Single(item => item.ArenaId == id);
                if (row.ProjectPath != DiscoveryArenaLinkAudit.SuppliedLinks.Single(item => item.ArenaId == id).ProjectPath)
                    throw new InvalidDataException("Unexpected profile path; repair stopped.");
            }
            byte[] repaired = AppendMissing(snapshots[0], ids);
            for (int i = 0; i < paths.Length; i++)
                if (!ReadBounded(paths[i]).SequenceEqual(snapshots[i])) throw new IOException("Discovery data changed during the check. Save your Discovery edits and export again.");
            int before = Rows(snapshots[0]).Length, after = Rows(repaired).Length;
            System.IO.Directory.CreateDirectory(output);
            string originalPath = Path.Combine(output, "Original", "CreateShow", "MatchUpScreenAsset.jsfb");
            string repairedPath = Path.Combine(output, "BakeMe", "CreateShow", "MatchUpScreenAsset.jsfb");
            System.IO.Directory.CreateDirectory(Path.GetDirectoryName(originalPath));
            System.IO.Directory.CreateDirectory(Path.GetDirectoryName(repairedPath));
            File.WriteAllBytes(originalPath, snapshots[0]); File.WriteAllBytes(repairedPath, repaired);
            var result = new ExportResult { Directory = output, OriginalTable = originalPath, RepairedTable = repairedPath,
                OriginalRows = before, ResultRows = after, AddedArenaIds = ids,
                OriginalSha256 = Digest(snapshots[0]), RepairedSha256 = Digest(repaired) };
            var note = new StringBuilder("MISSING MATCHUP-CARD LINKS - EXPORTED REPAIR\r\n\r\n");
            note.AppendLine("Source: " + root);
            note.AppendLine("Added absent card IDs: " + string.Join(", ", ids));
            note.AppendLine("Rows: " + before + " -> " + after);
            note.AppendLine("Original SHA256: " + result.OriginalSha256);
            note.AppendLine("Repaired SHA256: " + result.RepairedSha256);
            note.AppendLine("The selected Discovery data is unchanged. Original/ contains the byte-identical original table.");
            note.AppendLine("Every existing card row, other root field and referenced payload is preserved. No transition, arena, profile, plugin, GMR or UI project is replaced.");
            note.AppendLine();
            note.AppendLine("INSTALL THROUGH THE WORKING DISCOVERY ENTRY");
            note.AppendLine("1. Close WWE and finish saving Discovery edits. Back up the currently working dedicated matchup CAK AND its input outside game/bake folders, retaining the exact CAK filename.");
            note.AppendLine("2. Copy ONLY BakeMe/CreateShow from this export into your working dedicated BakeMe input BESIDE its UI folder. Preserve UI and any Arena folder. Do not copy Original or this report into the bake.");
            note.AppendLine("3. If the full Discovery data root is where you maintain these records, first back up its current table outside that data root, then copy the same repaired CreateShow/MatchUpScreenAsset.jsfb there too. Do not overwrite later edits: this export describes the source hashes above.");
            note.AppendLine("4. Bake the SAME working Discovery entry/output filename once, with one dedicated matchup patch active, then fully restart WWE. Do not run full Studio Game setup on the isolated input. Keep the original Titavius arena CAK and imported arena/movie data installed.");
            note.AppendLine("5. Test the affected branded cards individually. This export repairs missing links only: it does not add movie layers or establish moving-portrait playback or a fix for loading failures.");
            note.AppendLine("If a card still falls back, provide the actual baked CAK so its paths and winning references can be checked.");
            note.AppendLine("Rollback: close WWE and restore the saved working CAK under its exact original filename and its saved input. Restore the original loose table as well if you copied the repair into the full data root. Removing loose files alone does not undo a bake.");
            note.AppendLine();
            note.AppendLine("SOURCE SNAPSHOTS");
            for (int i = 0; i < paths.Length; i++) note.AppendLine(SourceTables[i] + " SHA256 " + Digest(snapshots[i]));
            File.WriteAllText(Path.Combine(output, "README.txt"), note.ToString(), new UTF8Encoding(true));
            File.WriteAllText(Path.Combine(output, "SHA256SUMS.txt"), result.OriginalSha256 + "  Original/CreateShow/MatchUpScreenAsset.jsfb\n" + result.RepairedSha256 + "  BakeMe/CreateShow/MatchUpScreenAsset.jsfb\n", new UTF8Encoding(false));
            return result;
        }

        internal static byte[] AppendMissing(byte[] source, IEnumerable<int> arenaIds)
        {
            var file = new FlatBufferFile(source, "StCr");
            int[] oldRows = file.Tables(file.Root, 1).ToArray();
            int[] ids = arenaIds.OrderBy(id => id).ToArray();
            if (ids.Length == 0 || ids.Distinct().Count() != ids.Length) throw new InvalidDataException("A unique nonempty set of absent card IDs is required.");
            foreach (int id in ids)
            {
                if (!DiscoveryArenaLinkAudit.SuppliedLinks.Any(link => link.ArenaId == id)) throw new InvalidDataException("No verified source card profile for ID " + id);
                if (oldRows.Any(row => Id(file, row) == (uint)id)) throw new InvalidDataException("Card ID " + id + " already exists; existing links are never overwritten.");
            }
            int rootField = file.Field(file.Root, 1);
            if (rootField == 0) throw new InvalidDataException("The card vector field is absent; unknown root schemas are not repaired.");
            int rootVtable = checked(file.Root - file.I32(file.Root));
            if ((long)rootField + 4 > (long)file.Root + file.U16(rootVtable + 2)) throw new InvalidDataException("The root card-vector field extends beyond its table.");
            var bytes = new List<byte>(source); Align(bytes, 4);
            int vector = Reserve(bytes, checked(4 + 4 * (oldRows.Length + ids.Length)));
            Put32(bytes, vector, (uint)(oldRows.Length + ids.Length));
            Align(bytes, 8);
            int copy = bytes.Count; bytes.AddRange(source);
            for (int i = 0; i < oldRows.Length; i++) Point(bytes, vector + 4 + 4 * i, checked(copy + oldRows[i]));
            for (int i = 0; i < ids.Length; i++) Point(bytes, vector + 4 + 4 * (oldRows.Length + i), AppendSourceCard(bytes, ids[i]));
            Point(bytes, rootField, vector);
            byte[] result = bytes.ToArray();
            // Existing root references stay in the untouched original prefix.
            // Existing rows point into a byte-identical full source copy, so all
            // unknown row fields, strings, child vectors and vtables survive.
            for (int i = 0; i < source.Length; i++)
                if ((i < rootField || i >= rootField + 4) && source[i] != result[i]) throw new InvalidDataException("An unrelated original byte changed.");
            if (!result.Skip(copy).Take(source.Length).SequenceEqual(source)) throw new InvalidDataException("The original card payload copy changed.");
            var check = new FlatBufferFile(result, "StCr"); int[] newRows = check.Tables(check.Root, 1).ToArray();
            if (newRows.Length != oldRows.Length + ids.Length || newRows.Take(oldRows.Length).Where((row, i) => row != copy + oldRows[i]).Any())
                throw new InvalidDataException("Existing card order or references changed.");
            foreach (int id in ids)
            {
                int row = newRows.Single(item => Id(check, item) == (uint)id);
                var link = DiscoveryArenaLinkAudit.SuppliedLinks.Single(item => item.ArenaId == id);
                if (check.U64(check.Field(row, 4)).ToString("X16", CultureInfo.InvariantCulture) != link.ProjectHash
                    || check.U64(check.Field(row, 5)) != 7425612832715352533UL || check.U32(check.Field(row, 1)) != id)
                    throw new InvalidDataException("The added source card did not validate.");
            }
            return result;
        }

        private static int AppendSourceCard(List<byte> bytes, int id)
        {
            var link = DiscoveryArenaLinkAudit.SuppliedLinks.Single(item => item.ArenaId == id);
            Align(bytes, 8); int vt = Reserve(bytes, 24); Put16(bytes, vt, 22); Put16(bytes, vt + 2, 56);
            int[] fields = { 4, 8, 12, 16, 24, 32, 40, 44, 48 };
            for (int i = 0; i < fields.Length; i++) Put16(bytes, vt + 4 + 2 * i, fields[i]);
            int row = Reserve(bytes, 56); Put32(bytes, row, (uint)(row - vt)); Put32(bytes, row + 4, (uint)id); Put32(bytes, row + 8, (uint)id);
            Put64(bytes, row + 24, ulong.Parse(link.ProjectHash, NumberStyles.HexNumber, CultureInfo.InvariantCulture));
            Put64(bytes, row + 32, 7425612832715352533UL);
            string label = id == 806 ? "AEW_Double_or_Nothing_26" : "";
            byte[] text = Encoding.UTF8.GetBytes(label); Align(bytes, 4); int at = Reserve(bytes, text.Length + 5); Put32(bytes, at, (uint)text.Length);
            for (int i = 0; i < text.Length; i++) bytes[at + 4 + i] = text[i];
            Point(bytes, row + 12, at); Point(bytes, row + 16, at);
            Align(bytes, 4); int empty = Reserve(bytes, 4); Point(bytes, row + 40, empty); Point(bytes, row + 44, empty);
            return row;
        }

        private static int[] Rows(byte[] bytes) { var file = new FlatBufferFile(bytes, "StCr"); return file.Tables(file.Root, 1).ToArray(); }
        private static uint Id(FlatBufferFile file, int row) { int at = file.Field(row, 0); return at == 0 ? 0 : file.U32(at); }
        private static void Align(List<byte> bytes, int size) { while (bytes.Count % size != 0) bytes.Add(0); }
        private static int Reserve(List<byte> bytes, int size) { int at = bytes.Count; bytes.AddRange(new byte[size]); return at; }
        private static void Point(List<byte> bytes, int from, int to) { if (to <= from) throw new InvalidDataException("Invalid forward reference."); Put32(bytes, from, checked((uint)(to - from))); }
        private static void Put16(List<byte> bytes, int at, int value) { bytes[at] = (byte)value; bytes[at + 1] = (byte)(value >> 8); }
        private static void Put32(List<byte> bytes, int at, uint value) { for (int i = 0; i < 4; i++) bytes[at + i] = (byte)(value >> (8 * i)); }
        private static void Put64(List<byte> bytes, int at, ulong value) { for (int i = 0; i < 8; i++) bytes[at + i] = (byte)(value >> (8 * i)); }
        private static bool Inside(string root, string path) { root = root.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar); return path.Equals(root, StringComparison.OrdinalIgnoreCase) || path.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase); }
        private static byte[] ReadBounded(string path) { if (new FileInfo(path).Length > 128 * 1024 * 1024) throw new InvalidDataException("Table exceeds the 128 MiB limit."); return File.ReadAllBytes(path); }
        private static string Digest(byte[] bytes) { using (var hash = SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
        private static string Find(string root, string relative)
        {
            string[] parts = relative.Split('/');
            string directory = System.IO.Directory.GetDirectories(root).SingleOrDefault(path => Path.GetFileName(path).Equals(parts[0], StringComparison.OrdinalIgnoreCase));
            string file = directory == null ? null : System.IO.Directory.GetFiles(directory).SingleOrDefault(path => Path.GetFileName(path).Equals(parts[1], StringComparison.OrdinalIgnoreCase));
            if (file == null) throw new FileNotFoundException("Required binary table missing: " + relative);
            return file;
        }
    }
}
