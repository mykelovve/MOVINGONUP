using System;
using System.Collections.Generic;
using System.Linq;

namespace GorillaStudio.NameFolders
{
    public static class DiscoveryMatchupCardStatus
    {
        public static string Describe(DiscoveryMatchupSetupReport report, IEnumerable<ulong> references)
        {
            var hashes = references.ToList();
            if (hashes.Count == 0) return "No matchup file linked in data";
            if (hashes.Any(hash => report.Resolution.Conflicts.Contains(hash))) return "Conflicting project sources";
            if (hashes.Any(hash => !report.Resolution.Assets.ContainsKey(hash))) return "Linked project not located";
            if (hashes.Any(hash => !report.PreparedPaths.ContainsKey(hash))) return "Project found · run game setup";
            var projects = hashes.Select(hash => report.Layouts.Projects.FirstOrDefault(project =>
                string.Equals(project.Path, report.PreparedPaths[hash], StringComparison.OrdinalIgnoreCase))).ToList();
            if (projects.Any(project => project == null || project.CheckedSlots == 0)) return "Project found · layout unverified";
            if (projects.Any(project => project.Issues.Count > 0)) return "Project found · layout issue";
            if (projects.Any(project => !project.LayoutReady)) return "Project found · movie layers need repair";
            if (report.Layouts.AddedMovies > 0 || report.Layouts.Failed.Count > 0 || report.Layouts.Unsupported.Count > 0)
                return "Layout ready · check shared movies/issues";
            return "Files ready · bake/playback unverified";
        }
    }
}
