using System;
using System.IO;

namespace GorillaStudio.NameFolders
{
    public sealed class DiscoverySetupRootChoice
    {
        public string Path { get; internal set; }
        public string Source { get; internal set; }
        public string Error { get; internal set; }
        public bool Exists { get; internal set; }
    }

    /// <summary>Screen setup follows the user's data choice, independently of a previously loaded model.</summary>
    public static class DiscoverySetupRoot
    {
        public static DiscoverySetupRootChoice Resolve(string currentData, string configuredSetup,
            string savedData, string modelData, string selectedUi = null)
        {
            string[] paths = { selectedUi, currentData, configuredSetup, savedData, modelData };
            string[] sources = { "selected UI bake folder", "current Discovery data choice", "configured game-setup folder",
                "saved Discovery data choice", "loaded model's roster folder" };
            for (int index = 0; index < paths.Length; index++)
            {
                if (string.IsNullOrWhiteSpace(paths[index])) continue;
                var choice = new DiscoverySetupRootChoice { Source = sources[index] };
                try
                {
                    choice.Path = System.IO.Path.GetFullPath(paths[index].Trim());
                    choice.Exists = Directory.Exists(choice.Path);
                    if (!choice.Exists) choice.Error = "The " + choice.Source + " is unavailable: " + choice.Path
                        + ". Select the current Discovery data folder again.";
                }
                catch (Exception error) when (error is ArgumentException || error is IOException
                    || error is NotSupportedException || error is System.Security.SecurityException)
                { choice.Error = "The " + choice.Source + " is invalid: " + error.Message; }
                // An unavailable explicit choice must never silently redirect a write
                // to an older roster or model folder.
                return choice;
            }
            return new DiscoverySetupRootChoice { Source = "not selected",
                Error = "Choose the Discovery data folder used by the game's bake entry." };
        }
    }
}
