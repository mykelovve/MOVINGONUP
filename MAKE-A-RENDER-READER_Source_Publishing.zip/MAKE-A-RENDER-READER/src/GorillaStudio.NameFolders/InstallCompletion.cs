using System.Threading.Tasks;

namespace GorillaStudio.NameFolders
{
    public static partial class FolderBridge
    {
        // The native installer awaits GameSetup(false) after copying its GMR.
        // Redirect only that automatic call; explicit Game setup remains available.
        // Installing a movie must not overwrite or expand the selected UI recipe.
        public static Task FinishRenderInstall(object owner, bool ask)
        {
            return Task.CompletedTask;
        }
    }
}
