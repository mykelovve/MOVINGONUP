using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Threading;

namespace GorillaStudio.NameFolders
{
    public sealed class MatchCardDiagnosticBundleResult
    {
        public int LogsCopied { get; internal set; }
        public int InputFilesCopied { get; internal set; }
        public List<string> Notes { get; } = new List<string>();
    }

    /// <summary>Copies runtime logs to a user-chosen ZIP; never changes the game or uploads anything.</summary>
    public static class MatchCardDiagnosticBundle
    {
        public static MatchCardDiagnosticBundleResult Save(string gameRoot, string report, string destination, CancellationToken cancellation)
        {
            var result = new MatchCardDiagnosticBundleResult();
            string target = Path.GetFullPath(destination), game = Path.GetFullPath(gameRoot);
            string prefix = game.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            if (!string.Equals(Path.GetExtension(target), ".zip", StringComparison.OrdinalIgnoreCase)
                || target.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || string.Equals(target, game, StringComparison.OrdinalIgnoreCase))
                throw new IOException("Save the diagnostic ZIP outside the WWE game folder.");
            string temporary = target + ".partial-" + Guid.NewGuid().ToString("N");
            bool owned = false;
            try
            {
                cancellation.ThrowIfCancellationRequested(); Safe(target);
                using (var file = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    owned = true;
                    using (var zip = new ZipArchive(file, ZipArchiveMode.Create, true))
                    {
                        Write(zip, "setup-report.txt", report ?? "No setup report was available.");
                        Write(zip, "logging-status.txt", MovingRenderDiagnostics.SettingsSnapshot(game));
                        string[] names = { "WWE2K26_MovingRenders.log", "WWE2K26_SelectionLoop.log", "GorillaRenders/_scan_ids.txt" };
                        foreach (string name in names)
                        {
                            cancellation.ThrowIfCancellationRequested();
                            string source = Path.Combine(game, "Plugins", name.Replace('/', Path.DirectorySeparatorChar));
                            try
                            {
                                Safe(source);
                                if (!File.Exists(source)) { result.Notes.Add((name.EndsWith(".log", StringComparison.Ordinal) ? "Missing runtime log: Plugins/" : "Optional input absent: Plugins/") + name); continue; }
                                using (var input = new FileStream(source, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                                {
                                    long limit = name.EndsWith(".log", StringComparison.Ordinal) ? 8L * 1024 * 1024 : 1024 * 1024;
                                    long length = input.Length, remaining = Math.Min(length, limit);
                                    input.Position = length - remaining;
                                    using (var output = zip.CreateEntry((name.EndsWith(".log", StringComparison.Ordinal) ? "runtime/" : "inputs/") + name, CompressionLevel.Optimal).Open())
                                    {
                                        byte[] buffer = new byte[81920];
                                        while (remaining > 0)
                                        {
                                            cancellation.ThrowIfCancellationRequested();
                                            int read = input.Read(buffer, 0, (int)Math.Min(buffer.Length, remaining));
                                            if (read == 0) break;
                                            output.Write(buffer, 0, read); remaining -= read;
                                        }
                                    }
                                    if (name.EndsWith(".log", StringComparison.Ordinal)) result.LogsCopied++; else result.InputFilesCopied++;
                                    result.Notes.Add("Copied: Plugins/" + name + (length > limit ? " (latest " + limit + " bytes only)" : "")
                                        + (remaining > 0 ? " (source changed during reading)" : ""));
                                }
                            }
                            catch (Exception error) when (error is IOException || error is UnauthorizedAccessException || error is System.Security.SecurityException)
                            { result.Notes.Add("Could not read Plugins/" + name + ": " + error.Message); }
                        }
                        Write(zip, "included-files.txt", "Saved UTC: " + DateTime.UtcNow.ToString("O")
                            + "\nRuntime log copies: " + result.LogsCopied + "\nOptional input copies: " + result.InputFilesCopied + "\n" + string.Join("\n", result.Notes)
                            + (result.LogsCopied == 0 ? "\nNo runtime logs were found. Enable playback logging, fully restart WWE, reproduce the failed match and collect again. This does not establish whether the plugin loaded." : "")
                            + "\nThis bundle does not establish game playback or change any game files.\n");
                    }
                    file.Flush(true);
                }
                cancellation.ThrowIfCancellationRequested(); Safe(target);
                if (File.Exists(target)) File.Replace(temporary, target, null); else File.Move(temporary, target);
                owned = false; return result;
            }
            finally { if (owned) try { File.Delete(temporary); } catch (IOException) { } catch (UnauthorizedAccessException) { } }
        }
        private static void Write(ZipArchive zip, string name, string text)
        { using (var writer = new StreamWriter(zip.CreateEntry(name, CompressionLevel.Optimal).Open(), new UTF8Encoding(false))) writer.Write(text); }
        private static void Safe(string path)
        {
            for (string current = Path.GetFullPath(path); !string.IsNullOrEmpty(current); current = Path.GetDirectoryName(current))
                if ((File.Exists(current) || Directory.Exists(current)) && (File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                    throw new IOException("Linked paths were not followed: " + current);
        }
    }
}
