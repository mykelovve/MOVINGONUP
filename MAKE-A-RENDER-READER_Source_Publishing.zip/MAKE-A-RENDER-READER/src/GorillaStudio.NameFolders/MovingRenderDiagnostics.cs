using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace GorillaStudio.NameFolders
{
    public sealed class MovingRenderLoggingResult
    {
        public bool Enabled { get; internal set; }
        public bool Changed { get; internal set; }
        public string BackupPath { get; internal set; }
        public string Message { get; internal set; }
    }

    /// <summary>Known native diagnostic flags; never enables memory scans or changes movie/UI files.</summary>
    public static class MovingRenderDiagnostics
    {
        private static readonly UTF8Encoding Utf8 = new UTF8Encoding(false, true);
        private static readonly string[] Flags = { "enabled", "verbose", "diag", "scan_ids", "matchup_unused_fail", "mu_scale_test" };
        private const int MaximumConfigBytes = 1024 * 1024;
        private const string OriginalSha256 = "b752da3c9a9dc48dc377972a7183db0194c2b3b551074f7d0f0c9766432bf75c";

        public static string SettingsSnapshot(string gameRoot)
        {
            try
            {
                string path = Path.Combine(Path.GetFullPath(gameRoot), "Plugins", "WWE2K26_MovingRenders.cfg");
                byte[] bytes = ReadConfig(path);
                bool bom = HasBom(bytes);
                string text = Utf8.GetString(bytes, bom ? 3 : 0, bytes.Length - (bom ? 3 : 0));
                var values = new Dictionary<string, string>(StringComparer.Ordinal);
                foreach (string flag in Flags) values[flag] = "unset";
                foreach (string line in text.Split('\n'))
                {
                    var match = Regex.Match(line, @"^[ \t]*([A-Za-z_]+)[ \t]+([^\s#;]+)", RegexOptions.CultureInvariant);
                    if (!match.Success || !values.ContainsKey(match.Groups[1].Value)) continue;
                    int number;
                    values[match.Groups[1].Value] = int.TryParse(match.Groups[2].Value, NumberStyles.Integer,
                        CultureInfo.InvariantCulture, out number) ? number.ToString(CultureInfo.InvariantCulture) : "unrecognized value";
                }
                return "Known native settings (other configuration content excluded):\n"
                    + string.Join("\n", Flags.Select(flag => flag + " " + values[flag]))
                    + "\nMissing runtime logs do not establish whether the plugin loaded."
                    + "\n_scan_ids.txt is an optional mapping input; it is not a generated runtime log.\n";
            }
            catch (Exception error) when (Expected(error))
            { return "Diagnostic settings could not be read: " + error.Message + "\nMissing runtime logs do not establish whether the plugin loaded.\n"; }
        }

        public static MovingRenderLoggingResult EnableLogging(string gameRoot)
        { return EnableLogging(gameRoot, () => Process.GetProcessesByName("WWE2K26_x64").Length == 0); }

        internal static MovingRenderLoggingResult EnableLogging(string gameRoot, Func<bool> gameClosed)
        {
            var result = new MovingRenderLoggingResult();
            string temporary = null; bool owned = false;
            try
            {
                RequireClosed(gameClosed);
                string plugins = Path.Combine(Path.GetFullPath(gameRoot), "Plugins");
                string plugin = Path.Combine(plugins, "WWE2K26_MovingRenders.dlp");
                Safe(plugin);
                if (!File.Exists(plugin) || new FileInfo(plugin).Length != 69632) throw new IOException("Logging setup requires the verified original MovingRenders 4.21 plugin.");
                using (var input = File.OpenRead(plugin)) using (var sha = SHA256.Create())
                    if (!string.Equals(BitConverter.ToString(sha.ComputeHash(input)).Replace("-", ""), OriginalSha256, StringComparison.OrdinalIgnoreCase))
                        throw new IOException("Logging setup requires the verified original MovingRenders 4.21 plugin.");
                string config = Path.Combine(plugins, "WWE2K26_MovingRenders.cfg");
                byte[] before = ReadConfig(config); bool bom = HasBom(before);
                string original = Utf8.GetString(before, bom ? 3 : 0, before.Length - (bom ? 3 : 0));
                bool found = false;
                string changed = Regex.Replace(original, @"^([ \t]*)verbose([ \t]+)([^\s#;]+)", match => {
                    found = true; return match.Groups[1].Value + "verbose" + match.Groups[2].Value + "1";
                }, RegexOptions.Multiline | RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
                if (!found)
                {
                    string newline = original.Contains("\r\n") ? "\r\n" : "\n";
                    changed += (original.Length == 0 || original.EndsWith("\n", StringComparison.Ordinal) ? "" : newline) + "verbose 1" + newline;
                }
                if (changed == original) { result.Enabled = true; result.Message = "Playback logging is already enabled. Fully restart WWE, reproduce the failed match, then save diagnostics."; return result; }
                byte[] body = Utf8.GetBytes(changed), after = bom ? new UTF8Encoding(true).GetPreamble().Concat(body).ToArray() : body;
                string backup = config + ".before-logging.bak";
                Safe(backup); RequireClosed(gameClosed);
                if (!File.ReadAllBytes(config).SequenceEqual(before)) throw new IOException("The configuration changed. Check again before enabling logging.");
                if (!File.Exists(backup)) using (var output = new FileStream(backup, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                { output.Write(before, 0, before.Length); output.Flush(true); }
                temporary = config + ".logging-" + Guid.NewGuid().ToString("N") + ".tmp";
                using (var output = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                { owned = true; output.Write(after, 0, after.Length); output.Flush(true); }
                RequireClosed(gameClosed); Safe(config);
                if (!File.ReadAllBytes(config).SequenceEqual(before)) throw new IOException("The configuration changed. Logging was not applied.");
                File.Replace(temporary, config, null); owned = false;
                result.Enabled = result.Changed = true; result.BackupPath = backup;
                result.Message = "Playback logging enabled. Fully restart WWE, reproduce the failed match, then Save diagnostics. No bake or new MAKE is needed.";
            }
            catch (Exception error) when (Expected(error)) { result.Message = "Could not enable playback logging: " + error.Message; }
            finally { if (owned) try { File.Delete(temporary); } catch (IOException) { } catch (UnauthorizedAccessException) { } }
            return result;
        }
        private static bool HasBom(byte[] bytes) { return bytes.Length >= 3 && bytes[0] == 0xef && bytes[1] == 0xbb && bytes[2] == 0xbf; }
        private static byte[] ReadConfig(string path)
        {
            Safe(path);
            if (!File.Exists(path) || new FileInfo(path).Length > MaximumConfigBytes) throw new IOException("The plugin configuration is missing or exceeds the 1 MiB limit.");
            return File.ReadAllBytes(path);
        }
        private static void RequireClosed(Func<bool> closed) { if (closed == null || !closed()) throw new IOException("Close WWE before changing playback logging."); }
        private static void Safe(string path)
        {
            for (string current = Path.GetFullPath(path); !string.IsNullOrEmpty(current); current = Path.GetDirectoryName(current))
                if ((File.Exists(current) || Directory.Exists(current)) && (File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                    throw new IOException("Linked paths were not followed: " + current);
        }
        private static bool Expected(Exception error)
        { return error is IOException || error is UnauthorizedAccessException || error is ArgumentException || error is NotSupportedException || error is System.Security.SecurityException; }
    }
}
