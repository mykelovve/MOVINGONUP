using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;

namespace GorillaStudio.NameFolders
{
    public static partial class FolderBridge
    {
        private static void AttachStandaloneInterface(Window window)
        {
            foreach (string name in new[] { "DiscordPill", "DiscordSignInButton", "DiscordSignOutButton", "LockOverlay" })
            {
                var control = window.GetType().GetField(name, InstanceMembers)?.GetValue(window) as UIElement;
                if (control != null) { control.Visibility = Visibility.Collapsed; control.IsEnabled = false; }
            }
            var objects = new List<DependencyObject>();
            var pending = new Stack<DependencyObject>(); pending.Push(window);
            var seen = new HashSet<DependencyObject>();
            while (pending.Count > 0)
            {
                var item = pending.Pop();
                if (!seen.Add(item)) continue;
                objects.Add(item);
                foreach (object child in LogicalTreeHelper.GetChildren(item))
                    if (child is DependencyObject dependency) pending.Push(dependency);
            }
            foreach (TextBlock text in objects.OfType<TextBlock>())
            {
                foreach (Hyperlink link in text.Inlines.OfType<Hyperlink>().ToArray())
                    if (PatreonLink(link.NavigateUri))
                    {
                        var separator = link.PreviousInline as Run;
                        if (separator != null && separator.Text.Trim().All(character => "·•|-".IndexOf(character) >= 0))
                            text.Inlines.Remove(separator);
                        text.Inlines.Remove(link);
                    }
                if (text.Text.IndexOf("Patreon", StringComparison.OrdinalIgnoreCase) >= 0)
                    text.Text = "Gorilla Studio";
            }
        }

        private static bool PatreonLink(Uri uri)
        {
            return uri != null && uri.IsAbsoluteUri && (uri.Host.Equals("patreon.com", StringComparison.OrdinalIgnoreCase)
                || uri.Host.EndsWith(".patreon.com", StringComparison.OrdinalIgnoreCase));
        }
    }
}
