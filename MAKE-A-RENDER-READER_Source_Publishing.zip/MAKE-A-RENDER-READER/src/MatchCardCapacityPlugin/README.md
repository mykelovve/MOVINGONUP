# Match-card capacity companion — experimental

**Post-activation user result:** the supplied log reports ACTIVE, with sampled
counts of 4 and 15. Green/pink five-person corruption remains and a later 3%
loading stall is reported. Activation is therefore confirmed by the user's log,
but this change has not resolved their rendering/loading problem. CM Punk ROH's
actual GMR passes all 112 independent FFmpeg frame/alpha decodes. The game's
decoder/GPU path, exact-match playback-disabled control and two unnamed pending
CakeHook archives remain under investigation. See
[the post-activation audit](../../docs/CM_PUNK_ROH_POST_ACTIVATION_AUDIT.json).

This separate Windows x64 companion expands the original MovingRenders 4.21
match-card context table from 16 to 120 entries. The original registration
instructions demonstrably overwrite the first live context when a seventeenth
distinct movie opens. Six inline readers and the public context lookup only
search 16 entries. Expanding just the writer would also overwrite neighboring
selection data, so this companion allocates a separate zeroed table and changes
the seven live table bases, all readers and both relevant loop bounds together.

The user has confirmed corruption with the combined 101-layer Dynamite project.
This does **not** measure how many movie handles that game opened or establish
that capacity is its sole failure. The capacity defect is reproduced and its
correction is tested; the user's match playback remains unverified.

Production activation requires the exact unchanged original file SHA-256
`b752da3c9a9dc48dc377972a7183db0194c2b3b551074f7d0f0c9766432bf75c`,
the measured image and already-installed original Bink hook. The companion
does not initialize or authorize the original, call its authorization functions,
or replace its Bink caller-routing detour. Source file checks, layout/player
decoding, GMR parsing, game offsets and the original full-table policy remain
unchanged. Existing selection-loop companion guards remain compatible: their
on-disk original hash, image size, hook and selection consumer bytes are intact.

Only a completely empty original match-card table may be moved. The worker
prepares all 16 byte-guarded changes before stopping other threads, refuses to
publish while any sampled thread is inside native plugin code, checks the
original hook/empty table/bytes again, then publishes the complete plan and
restores executable page protection. All thread suspension increments are
balanced on refusal. The zeroed pool is read/write data, never executable.
An attempted transaction retains its small backing allocation until process
exit to prevent a dangling pointer on an OS rollback/protection failure.

The lookup keeps its original RBP prologue/unwind frame; its temporary RDX
save is below that frame. Inline callers preserve RCX/RDX and non-result
nonvolatile registers and reserve Win64 shadow space with aligned calls.
Original lock-release and other continuations are retained. The visibility
scan uses the same expanded bound as registration. Successful activation pins
the original and companion for the process lifetime. A worker samples active
records under the original context lock without blocking game callbacks and
logs new sampled peaks after releasing that lock.

Build with Zig 0.13.0:

```sh
python3 tools/build_matchcard_capacity.py --zig /path/to/zig --original /path/to/WWE2K26_MovingRenders.dlp --output /path/to/build
python3 tests/validate_matchcard_capacity.py --original /path/to/WWE2K26_MovingRenders.dlp --report /path/to/native-checks.json
```

The standalone Windows host maps the exact original with
`DONT_RESOLVE_DLL_REFERENCES` and never executes its entry point. Its test-only
compile omits the production authorization-ready requirement, exercises the
actual allocation/transaction/lookup code, and confirms the production gate
rejects the uninitialized image. This test-only host is excluded from the
download. It also tests thread-IP refusal/resume, live-context refusal, all 120
lookups, restored RX protection, unchanged original file and ordinary loading
of the production companion with a disabled configuration. Tests passed under
Wine; actual CakeHook activation, Bink decoding and WWE playback are pending.

See [installation and rollback](../../docs/MATCHCARD_CAPACITY_TEST.md).
