#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <tlhelp32.h>
#include <bcrypt.h>
#include <stdint.h>
#include <string.h>
#include <wchar.h>
#include "patch_plan.h"

namespace {
HMODULE self_module = nullptr;
wchar_t log_path[MAX_PATH]{};
constexpr uintptr_t kImageSize = 0xf4f000;
constexpr uintptr_t kTextStart = 0x1000, kTextSize = 0xd000;
constexpr wchar_t kConfig[] = L"WWE2K26_MatchCardCapacity.cfg";
constexpr wchar_t kLog[] = L"WWE2K26_MatchCardCapacity.log";
struct Edit { uintptr_t address; size_t length; unsigned char before[64], after[64]; };
Edit edits[kPatchCount]{};
struct Thread { HANDLE handle; bool suspended; };
Thread threads[1024]{};
size_t thread_count = 0;
uintptr_t verified_bink = 0, verified_next = 0;

bool Read(uintptr_t address, void* value, size_t size) {
    SIZE_T got=0;
    return ReadProcessMemory(GetCurrentProcess(),reinterpret_cast<void*>(address),value,size,&got) && got==size;
}
template<class T> bool Value(uintptr_t address,T* value) { return Read(address,value,sizeof(T)); }
bool Join(wchar_t* output,const wchar_t* root,const wchar_t* name) {
    size_t a=wcslen(root),b=wcslen(name);
    if(a+b+2>MAX_PATH) return false;
    memcpy(output,root,a*sizeof(wchar_t)); output[a++]=L'\\';
    memcpy(output+a,name,(b+1)*sizeof(wchar_t)); return true;
}
[[maybe_unused]] void Log(const char* message,DWORD detail=0) {
    if(!*log_path) return;
    HANDLE file=CreateFileW(log_path,FILE_APPEND_DATA,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(file==INVALID_HANDLE_VALUE) return;
    LARGE_INTEGER length{};
    if(GetFileSizeEx(file,&length) && length.QuadPart<1024*1024) {
        char text[512]; SYSTEMTIME now{}; GetSystemTime(&now);
        int size=wsprintfA(text,"%04u-%02u-%02u %02u:%02u:%02u UTC %s (%lu)\r\n",now.wYear,now.wMonth,now.wDay,now.wHour,now.wMinute,now.wSecond,message,detail);
        DWORD written=0; if(size>0) WriteFile(file,text,static_cast<DWORD>(size),&written,nullptr);
    }
    CloseHandle(file);
}
[[maybe_unused]] bool Enabled(const wchar_t* root) {
    wchar_t path[MAX_PATH]{}; if(!Join(path,root,kConfig)) return false;
    HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(f==INVALID_HANDLE_VALUE) return false;
    char text[64]{}; DWORD got=0; LARGE_INTEGER length{};
    bool ok=GetFileSizeEx(f,&length) && length.QuadPart>0 && length.QuadPart<64
        && ReadFile(f,text,static_cast<DWORD>(length.QuadPart),&got,nullptr) && got==length.QuadPart;
    CloseHandle(f); if(!ok) return false;
    while(got && (text[got-1]=='\r'||text[got-1]=='\n'||text[got-1]==' '||text[got-1]=='\t')) text[--got]=0;
    return !strcmp(text,"enabled 1");
}
bool OriginalFile(HMODULE module) {
    wchar_t path[MAX_PATH]{}; DWORD size=GetModuleFileNameW(module,path,MAX_PATH);
    if(!size||size>=MAX_PATH) return false;
    HANDLE file=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(file==INVALID_HANDLE_VALUE) return false;
    unsigned char bytes[69632],digest[32],object[1024]; DWORD got=0,object_size=0,returned=0;
    LARGE_INTEGER length{};
    bool ok=GetFileSizeEx(file,&length)&&length.QuadPart==sizeof(bytes)
        && ReadFile(file,bytes,sizeof(bytes),&got,nullptr)&&got==sizeof(bytes);
    CloseHandle(file);
    BCRYPT_ALG_HANDLE algorithm=nullptr; BCRYPT_HASH_HANDLE hash=nullptr;
    ok=ok && BCryptOpenAlgorithmProvider(&algorithm,BCRYPT_SHA256_ALGORITHM,nullptr,0)>=0
        && BCryptGetProperty(algorithm,BCRYPT_OBJECT_LENGTH,reinterpret_cast<PUCHAR>(&object_size),sizeof(object_size),&returned,0)>=0
        && object_size<=sizeof(object)
        && BCryptCreateHash(algorithm,&hash,object,object_size,nullptr,0,0)>=0
        && BCryptHashData(hash,bytes,sizeof(bytes),0)>=0
        && BCryptFinishHash(hash,digest,sizeof(digest),0)>=0;
    if(hash) BCryptDestroyHash(hash); if(algorithm) BCryptCloseAlgorithmProvider(algorithm,0);
    if(!ok) return false;
    const char hex[]="0123456789abcdef"; char actual[65]{};
    for(size_t i=0;i<32;++i) { actual[2*i]=hex[digest[i]>>4]; actual[2*i+1]=hex[digest[i]&15]; }
    return !strcmp(actual,kOriginalSha);
}
bool NativeImage(uintptr_t base) {
    IMAGE_DOS_HEADER dos{}; IMAGE_NT_HEADERS64 pe{}; char marker[19]{};
    return Value(base,&dos)&&dos.e_magic==IMAGE_DOS_SIGNATURE&&dos.e_lfanew>0&&dos.e_lfanew<0x1000
        &&Value(base+dos.e_lfanew,&pe)&&pe.Signature==IMAGE_NT_SIGNATURE
        &&pe.FileHeader.Machine==IMAGE_FILE_MACHINE_AMD64&&pe.OptionalHeader.Magic==IMAGE_NT_OPTIONAL_HDR64_MAGIC
        &&pe.OptionalHeader.SizeOfImage==kImageSize&&Read(base+0xe0e0,marker,sizeof(marker))
        &&!memcmp(marker,"MOVINGRENDERS-4.21",18);
}
bool Executable(uintptr_t address,size_t length) {
    MEMORY_BASIC_INFORMATION r{};
    if(!VirtualQuery(reinterpret_cast<void*>(address),&r,sizeof(r))||r.State!=MEM_COMMIT
       ||(r.Protect&(PAGE_GUARD|PAGE_NOACCESS))) return false;
    DWORD p=r.Protect&255; uintptr_t start=reinterpret_cast<uintptr_t>(r.BaseAddress);
    return (p==PAGE_EXECUTE||p==PAGE_EXECUTE_READ||p==PAGE_EXECUTE_READWRITE||p==PAGE_EXECUTE_WRITECOPY)
        &&address>=start&&length<=r.RegionSize&&address-start<=r.RegionSize-length;
}
bool ReadyMemory(uintptr_t base,uintptr_t expected_bink,uintptr_t next) {
    LONG flag=0; uintptr_t recorded=0,trampoline=0;
    if(!NativeImage(base)||!expected_bink||!next||!Value(base+0x33c460,&flag)||flag!=1
        ||!Value(base+0x13058,&recorded)||recorded!=expected_bink
        ||!Value(base+0x137d0,&trampoline)||!Executable(trampoline,19)) return false;
    unsigned char detour[14]{},saved[19]{};
    const unsigned char prefix[]={0x48,0x89,0x5c,0x24,0x10,0xff,0x25,0,0,0,0};
    uintptr_t destination=0,resume=0;
    if(!next||!Read(next,detour,sizeof(detour))||!Read(trampoline,saved,sizeof(saved))) return false;
    memcpy(&destination,detour+6,8); memcpy(&resume,saved+11,8);
    return !memcmp(detour,"\xff\x25\0\0\0\0",6)&&destination==base+0x1000
        &&!memcmp(saved,prefix,sizeof(prefix))&&resume==next+14;
}
bool AuthorizedReady(uintptr_t base) {
    // Resolve loader/export state only while other threads are running. The
    // frozen transaction uses ReadyMemory and must never take the loader lock.
    HMODULE bink=GetModuleHandleW(L"bink2w64.dll");
    uintptr_t next=bink?reinterpret_cast<uintptr_t>(GetProcAddress(bink,"BinkNextFrame")):0;
    if(!ReadyMemory(base,reinterpret_cast<uintptr_t>(bink),next)) return false;
    verified_bink=reinterpret_cast<uintptr_t>(bink); verified_next=next; return true;
}
bool EmptyOriginalPool(uintptr_t base) {
    for(unsigned i=0;i<16;++i) { uintptr_t handle=0; if(!Value(base+kOldPool+i*kStride,&handle)||handle) return false; }
    return true;
}
void* AllocateNear(uintptr_t base) {
    SYSTEM_INFO info{}; GetSystemInfo(&info);
    uintptr_t step=info.dwAllocationGranularity;
    uintptr_t start=(base+kImageSize+step-1)&~(step-1);
    for(uintptr_t i=0;i<2048;++i) {
        uintptr_t at=start+i*step;
        void* memory=VirtualAlloc(reinterpret_cast<void*>(at),kCapacity*kStride,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
        if(memory) return memory;
    }
    return nullptr;
}
bool Prepare(uintptr_t base,uintptr_t pool) {
    if(!NativeImage(base)) return false;
    for(size_t i=0;i<kPatchCount;++i) {
        const PatchSpec& spec=kPatches[i]; Edit& edit=edits[i];
        if(spec.length>64||spec.rva<kTextStart||spec.rva+spec.length>kTextStart+kTextSize) return false;
        edit.address=base+spec.rva; edit.length=spec.length;
        memcpy(edit.before,spec.before,spec.length); memcpy(edit.after,spec.after,spec.length);
        if(spec.pool_offset>=0) {
            if(spec.pool_offset+4>spec.length) return false;
            int64_t relative=static_cast<int64_t>(pool)-static_cast<int64_t>(edit.address+spec.pool_offset+4);
            if(relative<INT32_MIN||relative>INT32_MAX) return false;
            int32_t displacement=static_cast<int32_t>(relative); memcpy(edit.after+spec.pool_offset,&displacement,4);
        }
        unsigned char actual[64];
        if(!Read(edit.address,actual,edit.length)||memcmp(actual,edit.before,edit.length)) return false;
    }
    return true;
}
void Resume() {
    for(size_t i=0;i<thread_count;++i) if(threads[i].suspended) { ResumeThread(threads[i].handle); threads[i].suspended=false; }
    for(size_t i=0;i<thread_count;++i) CloseHandle(threads[i].handle);
    thread_count=0;
}
bool Freeze(uintptr_t base) {
    HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD,0);
    if(snapshot==INVALID_HANDLE_VALUE) return false;
    THREADENTRY32 row{}; row.dwSize=sizeof(row); bool ok=Thread32First(snapshot,&row)!=FALSE;
    DWORD process=GetCurrentProcessId(),self=GetCurrentThreadId();
    if(ok) do {
        if(row.th32OwnerProcessID!=process||row.th32ThreadID==self) continue;
        if(thread_count==1024) { ok=false; break; }
        HANDLE thread=OpenThread(THREAD_SUSPEND_RESUME|THREAD_GET_CONTEXT|THREAD_QUERY_INFORMATION,FALSE,row.th32ThreadID);
        if(!thread) { if(GetLastError()==ERROR_INVALID_PARAMETER) continue; ok=false; break; }
        threads[thread_count++]={thread,false};
    } while(Thread32Next(snapshot,&row));
    CloseHandle(snapshot);
    if(!ok) { Resume(); return false; }
    for(size_t i=0;i<thread_count;++i) {
        if(SuspendThread(threads[i].handle)==static_cast<DWORD>(-1)) { Resume(); return false; }
        threads[i].suspended=true;
        CONTEXT context{}; context.ContextFlags=CONTEXT_CONTROL;
        if(!GetThreadContext(threads[i].handle,&context)
            ||(context.Rip>=base+kTextStart&&context.Rip<base+kTextStart+kTextSize)) { Resume(); return false; }
    }
    return true;
}
enum class Applied { Success, Busy, Mismatch, Protection, RetainedFailure };
Applied Commit(uintptr_t base) {
    if(!Freeze(base)) return Applied::Busy;
    bool ok=EmptyOriginalPool(base);
#ifndef CAPACITY_TEST_HOST
    ok=ok&&ReadyMemory(base,verified_bink,verified_next);
#endif
    for(size_t i=0;ok&&i<kPatchCount;++i) {
        unsigned char actual[64]; ok=Read(edits[i].address,actual,edits[i].length)&&!memcmp(actual,edits[i].before,edits[i].length);
    }
    if(!ok) { Resume(); return Applied::Mismatch; }
    DWORD previous=0;
    if(!VirtualProtect(reinterpret_cast<void*>(base+kTextStart),kTextSize,PAGE_EXECUTE_READWRITE,&previous)) { Resume(); return Applied::Protection; }
    for(size_t i=0;i<kPatchCount;++i) memcpy(reinterpret_cast<void*>(edits[i].address),edits[i].after,edits[i].length);
    ok=FlushInstructionCache(GetCurrentProcess(),reinterpret_cast<void*>(base+kTextStart),kTextSize)!=FALSE;
    DWORD ignored=0;
    if(!ok||!VirtualProtect(reinterpret_cast<void*>(base+kTextStart),kTextSize,previous,&ignored)) {
        DWORD writable=0;
        if(!VirtualProtect(reinterpret_cast<void*>(base+kTextStart),kTextSize,PAGE_EXECUTE_READWRITE,&writable)) {
            // The full plan has been written, but restoration could not be
            // guaranteed. Keep its backing pool alive; never free live targets.
            Resume(); return Applied::RetainedFailure;
        }
        // Roll back while threads are still stopped. The first protection change
        // succeeded, so no partial code plan is published to executing threads.
        for(size_t i=0;i<kPatchCount;++i) memcpy(reinterpret_cast<void*>(edits[i].address),edits[i].before,edits[i].length);
        FlushInstructionCache(GetCurrentProcess(),reinterpret_cast<void*>(base+kTextStart),kTextSize);
        VirtualProtect(reinterpret_cast<void*>(base+kTextStart),kTextSize,previous,&ignored);
        Resume(); return Applied::Protection;
    }
    Resume(); return Applied::Success;
}
#ifndef CAPACITY_TEST_HOST
DWORD WINAPI Worker(void*) {
    wchar_t directory[MAX_PATH]{}; DWORD length=GetModuleFileNameW(self_module,directory,MAX_PATH);
    if(!length||length>=MAX_PATH) return 0;
    wchar_t* last=nullptr; for(wchar_t* p=directory;*p;++p) if(*p==L'\\') last=p;
    if(!last) return 0; *last=0;
    if(!Join(log_path,directory,kLog)) return 0;
    if(!Enabled(directory)) { Log("Disabled: enabled 1 configuration absent"); return 0; }
    Log("Loaded: waiting for the original initialized MovingRenders 4.21 hook");
    HMODULE pinned=nullptr;
    if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,reinterpret_cast<LPCWSTR>(&Worker),&pinned)) return 0;
    HMODULE original=nullptr; bool verified=false;
    for(unsigned attempt=0;attempt<480;++attempt) {
        HMODULE found=GetModuleHandleW(L"WWE2K26_MovingRenders.dlp");
        if(!found) found=GetModuleHandleW(L"WWE2K26_MovingRenders.dll");
        if(found&&!verified) {
            if(!NativeImage(reinterpret_cast<uintptr_t>(found))||!OriginalFile(found)) { Log("Disabled: unsupported original file or image"); return 0; }
            original=found; verified=true;
        }
        if(verified&&found==original&&AuthorizedReady(reinterpret_cast<uintptr_t>(found))) break;
        if(attempt==479) { Log("Disabled: original authorized Bink hook not ready"); return 0; }
        Sleep(250);
    }
    uintptr_t base=reinterpret_cast<uintptr_t>(original);
    HMODULE pinned_original=nullptr;
    if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,reinterpret_cast<LPCWSTR>(base),&pinned_original)
        ||pinned_original!=original) { Log("Disabled: could not retain original"); return 0; }
    if(!EmptyOriginalPool(base)) { Log("Disabled: match-card movies already active; fully restart WWE"); return 0; }
    void* pool=AllocateNear(base);
    if(!pool) { Log("Disabled: no nearby context memory available",GetLastError()); return 0; }
    if(!Prepare(base,reinterpret_cast<uintptr_t>(pool))) { VirtualFree(pool,0,MEM_RELEASE); Log("Disabled: instruction guard mismatch"); return 0; }
    Applied result=Applied::Busy;
    for(unsigned attempt=0;attempt<40&&result==Applied::Busy;++attempt) {
        result=Commit(base); if(result==Applied::Busy) Sleep(50);
    }
    if(result!=Applied::Success) {
        // A transaction attempt retains this small allocation until process
        // exit, including on rollback/protection failure. No code can retain a
        // pointer into freed storage if an OS protection operation fails.
        Log("Capacity transaction did not confirm activation; restart to restore native state",static_cast<DWORD>(result)); return 0;
    }
    // The module and original are pinned. This pool must outlive all native
    // callbacks. Removal is by closing WWE, removing this companion and restarting.
    Log("ACTIVE: match-card contexts expanded from 16 to 120; original file and UI unchanged");
    unsigned peak=0;
    for(;;) {
        // Use the original context-table lock, only after its initialization and
        // our publication have been verified. Never block a game callback for
        // telemetry and perform file I/O only after releasing the lock.
        unsigned count=0;
        auto* lock=reinterpret_cast<CRITICAL_SECTION*>(base+0x13068);
        if(TryEnterCriticalSection(lock)) {
            for(unsigned i=0;i<kCapacity;++i)
                if(*reinterpret_cast<volatile uintptr_t*>(reinterpret_cast<uintptr_t>(pool)+i*kStride)) ++count;
            LeaveCriticalSection(lock);
            if(count>peak) { peak=count; Log("Sampled peak active match-card movie contexts",peak); }
        }
        Sleep(1000);
    }
}
#endif
}

#ifndef CAPACITY_TEST_HOST
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID) {
    if(reason==DLL_PROCESS_ATTACH) {
        self_module=module; DisableThreadLibraryCalls(module);
        HANDLE worker=CreateThread(nullptr,0,Worker,nullptr,0,nullptr);
        if(worker) CloseHandle(worker);
    }
    return TRUE;
}
#endif
