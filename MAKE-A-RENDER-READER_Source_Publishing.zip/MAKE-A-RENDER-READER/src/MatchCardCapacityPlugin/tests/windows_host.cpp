// Exercises the actual Win32 allocation/transaction/lookup implementation in a
// standalone host. DONT_RESOLVE_DLL_REFERENCES never runs the original DllMain.
// This compile-time host omits the production authorization gate; it is not part
// of the companion DLL or its package.
#define CAPACITY_TEST_HOST
#include "../plugin.cpp"
#include <stdio.h>

int wmain(int count,wchar_t** args) {
    if(count!=2&&count!=3) return 2;
    HMODULE module=LoadLibraryExW(args[1],nullptr,DONT_RESOLVE_DLL_REFERENCES);
    if(!module) { printf("load failed %lu\n",GetLastError()); return 3; }
    uintptr_t base=reinterpret_cast<uintptr_t>(module);
    if(!NativeImage(base)||!OriginalFile(module)||!EmptyOriginalPool(base)||AuthorizedReady(base)) return 4;
    void* pool=AllocateNear(base); if(!pool) return 5;
    if(!Prepare(base,reinterpret_cast<uintptr_t>(pool))) return 6;
    // A thread inside native code must prevent publication, and must be resumed
    // on that refusal. Use unused mapped-image padding, not an original entry.
    unsigned char saved[15]; memcpy(saved,reinterpret_cast<void*>(base+0xd780),sizeof(saved));
    const unsigned char spin[]={0xc7,0x41,0x04,0x01,0,0,0,0x83,0x39,0,0x74,0xfb,0x31,0xc0,0xc3};
    DWORD old=0,ignored=0;
    if(!VirtualProtect(reinterpret_cast<void*>(base+0xd780),sizeof(spin),PAGE_EXECUTE_READWRITE,&old)) return 14;
    memcpy(reinterpret_cast<void*>(base+0xd780),spin,sizeof(spin));
    FlushInstructionCache(GetCurrentProcess(),reinterpret_cast<void*>(base+0xd780),sizeof(spin));
    VirtualProtect(reinterpret_cast<void*>(base+0xd780),sizeof(spin),old,&ignored);
    struct Flags { volatile LONG stop,started; } flags{};
    HANDLE busy=CreateThread(nullptr,0,reinterpret_cast<LPTHREAD_START_ROUTINE>(base+0xd780),&flags,0,nullptr);
    if(!busy) return 15;
    for(unsigned i=0;i<1000&&!flags.started;++i) Sleep(1);
    bool refused=flags.started&&Commit(base)==Applied::Busy;
    InterlockedExchange(&flags.stop,1);
    bool resumed=WaitForSingleObject(busy,5000)==WAIT_OBJECT_0; CloseHandle(busy);
    if(!refused||!resumed) return 16;
    if(!VirtualProtect(reinterpret_cast<void*>(base+0xd780),sizeof(spin),PAGE_EXECUTE_READWRITE,&old)) return 17;
    memcpy(reinterpret_cast<void*>(base+0xd780),saved,sizeof(saved));
    FlushInstructionCache(GetCurrentProcess(),reinterpret_cast<void*>(base+0xd780),sizeof(spin));
    VirtualProtect(reinterpret_cast<void*>(base+0xd780),sizeof(spin),old,&ignored);
    // Live records must prevent publication; no original bytes may change.
    *reinterpret_cast<uintptr_t*>(base+kOldPool)=123;
    if(Commit(base)!=Applied::Mismatch) return 7;
    for(size_t i=0;i<kPatchCount;++i) if(memcmp(reinterpret_cast<void*>(edits[i].address),edits[i].before,edits[i].length)) return 8;
    *reinterpret_cast<uintptr_t*>(base+kOldPool)=0;
    if(Commit(base)!=Applied::Success) return 9;
    using Lookup=int(*)(uintptr_t);
    Lookup lookup=reinterpret_cast<Lookup>(base+0x1b30);
    for(unsigned i=0;i<kCapacity;++i) *reinterpret_cast<uintptr_t*>(reinterpret_cast<uintptr_t>(pool)+i*kStride)=0x100000+i;
    for(unsigned i=0;i<kCapacity;++i) if(lookup(0x100000+i)!=static_cast<int>(i)) return 10;
    if(lookup(0x99999999)!=-1||Prepare(base,reinterpret_cast<uintptr_t>(pool))) return 11;
    MEMORY_BASIC_INFORMATION r{};
    if(!VirtualQuery(reinterpret_cast<void*>(base+0x1000),&r,sizeof(r))||r.Protect!=PAGE_EXECUTE_READ) return 12;
    if(!OriginalFile(module)) return 13;
    printf("PASS mapped PE allocation, thread-IP refusal/resume, guarded transaction, live-record refusal, 120 native lookups, RX restoration and original file integrity\n");
    if(count==3) {
        wchar_t folder[MAX_PATH]{}; size_t length=wcslen(args[2]);
        if(length>=MAX_PATH) return 18;
        memcpy(folder,args[2],(length+1)*sizeof(wchar_t)); wchar_t* slash=nullptr;
        for(wchar_t* p=folder;*p;++p) if(*p==L'\\') slash=p;
        if(!slash) return 19; *slash=0;
        if(Enabled(folder)||!Join(log_path,folder,kLog)) return 20;
        if(!LoadLibraryW(args[2])) { printf("companion load failed %lu\n",GetLastError()); return 21; }
        bool logged=false;
        for(unsigned attempt=0;attempt<1000&&!logged;++attempt) {
            HANDLE file=CreateFileW(log_path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
            if(file!=INVALID_HANDLE_VALUE) {
                char text[1024]{}; DWORD got=0;
                if(ReadFile(file,text,sizeof(text)-1,&got,nullptr)) logged=strstr(text,"Disabled: enabled 1 configuration absent")!=nullptr;
                CloseHandle(file);
            }
            if(!logged) Sleep(1);
        }
        if(!logged) return 22;
        printf("PASS production companion LoadLibrary/DllMain, imports and disabled-config startup log\n");
    }
    return 0;
}
