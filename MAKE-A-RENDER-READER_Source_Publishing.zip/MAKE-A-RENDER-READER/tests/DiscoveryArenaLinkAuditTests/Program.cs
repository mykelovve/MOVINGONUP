using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using GorillaStudio.NameFolders;

internal static class Program
{
    private static int checks;
    private static string temp;
    private static int Main(string[] args)
    {
        if (args.Length == 0) { Console.Error.WriteLine("Usage: DiscoveryArenaLinkAuditTests supplied-discovery-root [result-json]"); return 2; }
        temp = Path.Combine(Path.GetTempPath(), "gorilla-arena-links-" + Guid.NewGuid().ToString("N"));
        string[] paths = { "Arena/ArenaData.jsfb", "CreateShow/MatchUpScreenAsset.jsfb", "Movies/MovieDataTable.jsfb" };
        try
        {
            var hashes = paths.ToDictionary(p => p, p => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(args[0], p)))));
            foreach (string path in paths) Copy(Path.Combine(args[0], path), Path.Combine(temp, path));
            var actual = DiscoveryArenaLinkAudit.Read(temp);
            Check(actual.Tables.Count == 3 && actual.Warnings.Count == 0 && actual.Arenas.Count == 8, "All three supplied binary tables read; eight exact source shows are compared");
            Check(actual.Arenas.All(r => r.CardLink == "Matches supplied profile"), "All eight current card hashes match exact original profile paths");
            Check(actual.Arenas.Where(r => r.BinaryLinksMatchSuppliedProfile).Select(r => r.ArenaId).SequenceEqual(new[] { 800, 801, 803, 808 }), "Earlier supplied binary arena data resolves four full link chains");
            Check(actual.Arenas.Where(r => r.ArenaTransitionLink == "Record absent").Select(r => r.ArenaId).SequenceEqual(new[] { 804, 805, 806, 807 }), "Four absent binary arena records are distinguished from their present card references");
            Check(actual.Arenas.All(r => r.MovieLink.StartsWith("Matches supplied profile")), "Expected transition movie records exist even for the four absent arena rows");
            Check(actual.Arenas.All(r => r.LooseProject.Contains("may be stored in a CAK") && r.LooseTransition.Contains("may be stored in a CAK")), "Unextracted assets are not incorrectly reported missing from the installed game");
            Copy(Path.Combine(args[0], "Arena/ArenaData.json"), Path.Combine(temp, "Arena/ArenaData.json"));
            Check(DiscoveryArenaLinkAudit.Read(temp).Arenas.Count(r => r.BinaryLinksMatchSuppliedProfile) == 4, "A richer JSON export cannot silently fill binary-table omissions");

            string arenaPath = Path.Combine(temp, paths[0]); byte[] sourceArena = File.ReadAllBytes(arenaPath);
            var arena = new FlatBufferFile(sourceArena, "Aren"); int rev = arena.Tables(arena.Root, 0).Single(t => arena.U16(arena.Field(t, 2)) == 803);
            byte[] changed = (byte[])sourceArena.Clone(); Put32(changed, arena.Field(rev, 3), 80095); File.WriteAllBytes(arenaPath, changed);
            var redirected = DiscoveryArenaLinkAudit.Read(temp).Arenas.Single(r => r.ArenaId == 803);
            Check(redirected.ActualTransitionIds == "80095" && redirected.ActualMovieHashes == "45C408A0D1E4A474" && !redirected.BinaryLinksMatchSuppliedProfile, "An edited arena transition follows its actual movie ID instead of the expected source ID");
            File.WriteAllBytes(arenaPath, sourceArena);
            File.WriteAllBytes(arenaPath, DuplicateRow(sourceArena, "Aren", 0, rev));
            Check(DiscoveryArenaLinkAudit.Read(temp).Arenas.Single(r => r.ArenaId == 803).ArenaTransitionLink.StartsWith("Duplicate"), "Duplicate arena records cannot produce a successful chain");
            File.WriteAllBytes(arenaPath, sourceArena);

            string cardPath = Path.Combine(temp, paths[1]); byte[] sourceCard = File.ReadAllBytes(cardPath);
            var card = new FlatBufferFile(sourceCard, "StCr"); int cr = card.Tables(card.Root, 1).Single(t => card.U32(card.Field(t, 0)) == 803);
            changed = (byte[])sourceCard.Clone(); Put64(changed, card.Field(cr, 4), 0xfffffffffffffff1UL); File.WriteAllBytes(cardPath, changed);
            var badHash = DiscoveryArenaLinkAudit.Read(temp).Arenas.Single(r => r.ArenaId == 803);
            Check(badHash.ActualProjectHashes == "FFFFFFFFFFFFFFF1" && !badHash.BinaryLinksMatchSuppliedProfile, "Unsigned 64-bit hashes preserve all bits and differing projects do not pass");
            File.WriteAllBytes(cardPath, new byte[24]);
            var broken = DiscoveryArenaLinkAudit.Read(temp);
            Check(broken.Warnings.Count == 1 && broken.Arenas.All(r => r.CardLink == "Table unavailable") && broken.Arenas.Any(r => r.ArenaTransitionLink == "Matches supplied profile"), "A malformed card table is reported without suppressing independent transition results");
            File.Delete(cardPath);
            Check(DiscoveryArenaLinkAudit.Read(temp).Arenas.All(r => r.CardLink == "Table unavailable"), "A missing card table is not interpreted as empty valid metadata");
            File.WriteAllBytes(cardPath, sourceCard);

            var expected = DiscoveryArenaLinkAudit.SuppliedLinks.Single(r => r.ArenaId == 803);
            string project = Path.Combine(temp, expected.ProjectPath); Directory.CreateDirectory(Path.GetDirectoryName(project));
            File.WriteAllBytes(project, new byte[] { 12, 0, 0, 0, 83, 99, 114, 101, 0, 0, 0, 0 });
            Check(DiscoveryArenaLinkAudit.Read(temp).Arenas.Single(r => r.ArenaId == 803).LooseProject.StartsWith("Scre header present"), "A loose project's header is reported separately from full content/playback validation");
            string wrong = Path.Combine(temp, "UI", expected.ProjectPath); Directory.CreateDirectory(Path.GetDirectoryName(wrong)); File.Move(project, wrong);
            Check(DiscoveryArenaLinkAudit.Read(temp).Arenas.Single(r => r.ArenaId == 803).PathWarning.Contains("UI/Arena/Titavius"), "An Arena tree incorrectly nested inside UI is identified without changing its path");

            string moviePath = Path.Combine(temp, expected.MoviePath); Directory.CreateDirectory(Path.GetDirectoryName(moviePath));
            byte[] movie = new byte[44]; Encoding.ASCII.GetBytes("KB2n").CopyTo(movie, 0);
            Put32(movie, 4, 36); Put32(movie, 8, 35); Put32(movie, 20, 1920); Put32(movie, 24, 1080); Put32(movie, 28, 2997); Put32(movie, 32, 100);
            File.WriteAllBytes(moviePath, movie);
            Check(DiscoveryArenaLinkAudit.Read(temp).Arenas.Single(r => r.ArenaId == 803).LooseTransition == "KB2n header consistent; decoding/playback unverified", "A Bink2 header does not claim successful decoding or corruption from decoder availability");
            Put32(movie, 4, 1); File.WriteAllBytes(moviePath, movie);
            Check(DiscoveryArenaLinkAudit.Read(temp).Arenas.Single(r => r.ArenaId == 803).LooseTransition.StartsWith("Inconsistent"), "An inconsistent stored movie length is detected");

            foreach (string path in paths) Check(hashes[path] == Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(args[0], path)))), "Original supplied " + path + " remains byte-identical");
            if (args.Length > 1) File.WriteAllText(args[1], JsonSerializer.Serialize(new { checks, scope = "Earlier supplied Discovery binary metadata; not the user's current setup", report = actual }, new JsonSerializerOptions { WriteIndented = true }));
            Console.WriteLine(checks + " arena/card/transition checks passed."); return 0;
        }
        catch (Exception error) { Console.Error.WriteLine(error); return 1; }
        finally { if (Directory.Exists(temp)) Directory.Delete(temp, true); }
    }
    private static byte[] DuplicateRow(byte[] source, string identifier, int vector, int duplicate)
    {
        var f = new FlatBufferFile(source, identifier); int[] rows = f.Tables(f.Root, vector).Concat(new[] { duplicate }).ToArray();
        var bytes = new List<byte>(new byte[28 + rows.Length * 4]); while (bytes.Count % 8 != 0) bytes.Add(0);
        int start = bytes.Count; bytes.AddRange(source); Put32(bytes, 0, 16); for (int i = 0; i < 4; i++) bytes[4 + i] = (byte)identifier[i];
        Put16(bytes, 8, 8); Put16(bytes, 10, 8); Put16(bytes, 12 + vector * 2, 4); Put32(bytes, 16, 8); Put32(bytes, 20, 4); Put32(bytes, 24, (uint)rows.Length);
        for (int i = 0; i < rows.Length; i++) Put32(bytes, 28 + i * 4, (uint)(start + rows[i] - 28 - i * 4));
        return bytes.ToArray();
    }
    private static void Put16(IList<byte> b, int at, int value) { b[at] = (byte)value; b[at + 1] = (byte)(value >> 8); }
    private static void Put32(IList<byte> b, int at, uint value) { for (int i = 0; i < 4; i++) b[at + i] = (byte)(value >> (i * 8)); }
    private static void Put64(IList<byte> b, int at, ulong value) { for (int i = 0; i < 8; i++) b[at + i] = (byte)(value >> (i * 8)); }
    private static void Copy(string from, string to) { Directory.CreateDirectory(Path.GetDirectoryName(to)); File.Copy(from, to); }
    private static void Check(bool passed, string message) { if (!passed) throw new Exception("FAIL: " + message); checks++; Console.WriteLine("PASS: " + message); }
}
