using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using GorillaStudio.NameFolders;

internal static class Program
{
    private static int checks;
    private static readonly int[] Missing = { 804, 805, 806 };
    private static int Main(string[] args)
    {
        if (args.Length == 0) return 2;
        string temp = Path.Combine(Path.GetTempPath(), "gorilla-card-export-" + Guid.NewGuid().ToString("N"));
        string root = Path.Combine(temp, "data");
        try
        {
            string[] paths = { "CreateShow/MatchUpScreenAsset.jsfb", "Arena/ArenaData.jsfb", "Movies/MovieDataTable.jsfb" };
            var originalHashes = paths.ToDictionary(p => p, p => Digest(File.ReadAllBytes(Path.Combine(args[0], p))));
            foreach (string p in paths) { string to = Path.Combine(root, p); Directory.CreateDirectory(Path.GetDirectoryName(to)); File.Copy(Path.Combine(args[0], p), to); }
            string cards = Path.Combine(root, paths[0]), arenas = Path.Combine(root, paths[1]);
            // A 173-row fixture with the same missing-ID pattern as the newest
            // report, derived from earlier supplied binary data. It is not a
            // reconstruction of the user's current 173 records.
            byte[] source = Select173(File.ReadAllBytes(cards)); File.WriteAllBytes(cards, source);
            File.WriteAllBytes(arenas, AddArenaRows(File.ReadAllBytes(arenas), new[] { 804, 805, 806, 807 }));
            var report = DiscoveryArenaLinkAudit.Read(root);
            Check(report.Warnings.Count == 0 && report.Arenas.Count(r => r.BinaryLinksMatchSuppliedProfile) == 5, "Fixture matches the latest report's five complete chains and three absent cards");
            Check(DiscoveryCardLinkRepair.Eligible(report).SequenceEqual(Missing), "Only the three absent cards with matching arena/movie links are eligible");
            byte[] output = DiscoveryCardLinkRepair.AppendMissing(source, Missing);
            var before = new FlatBufferFile(source, "StCr"); var after = new FlatBufferFile(output, "StCr");
            int[] oldRows = before.Tables(before.Root, 1).ToArray(), newRows = after.Tables(after.Root, 1).ToArray();
            Check(oldRows.Length == 173 && newRows.Length == 176, "Repair adds exactly three records to the 173-row fixture");
            Check(oldRows.Select(r => Id(before, r)).SequenceEqual(newRows.Take(173).Select(r => Id(after, r))), "Every existing ID remains in its original order");
            int vectorField = before.Field(before.Root, 1), copy = newRows[0] - oldRows[0];
            Check(source.Where((b, i) => i < vectorField || i >= vectorField + 4).SequenceEqual(output.Take(source.Length).Where((b, i) => i < vectorField || i >= vectorField + 4)), "Original prefix bytes change only at the root card-vector pointer");
            Check(output.Skip(copy).Take(source.Length).SequenceEqual(source) && oldRows.Select((r, i) => newRows[i] - r).All(delta => delta == copy), "All existing row payloads, unknown fields and referenced bytes remain in a byte-identical full copy");
            Check(before.U32(before.Field(before.Root, 0)) == after.U32(after.Field(after.Root, 0)), "The other root field retains its exact original value/reference");
            foreach (int id in Missing)
            {
                int row = newRows.Single(r => Id(after, r) == id); var expected = DiscoveryArenaLinkAudit.SuppliedLinks.Single(r => r.ArenaId == id);
                Check(after.U64(after.Field(row, 4)).ToString("X16") == expected.ProjectHash && after.U64(after.Field(row, 5)) == 7425612832715352533UL && after.U32(after.Field(row, 1)) == id, "ID " + id + " retains exact source profile IDs and both unsigned asset hashes");
                string text = id == 806 ? "AEW_Double_or_Nothing_26" : "";
                Check(Text(after, row, 2) == text && Text(after, row, 3) == text, "ID " + id + " retains both exact source template labels");
            }
            Check(Rejected(() => DiscoveryCardLinkRepair.AppendMissing(source, new[] { 803 })) && Rejected(() => DiscoveryCardLinkRepair.AppendMissing(source, new[] { 99999 })) && Rejected(() => DiscoveryCardLinkRepair.AppendMissing(source, new[] { 805, 805 })), "Existing, unknown and duplicate requested IDs are refused");

            var snapshots = paths.ToDictionary(p => p, p => Digest(File.ReadAllBytes(Path.Combine(root, p))));
            var exported = DiscoveryCardLinkRepair.Export(root, Path.Combine(temp, "export"));
            Check(exported.AddedArenaIds.SequenceEqual(Missing) && exported.OriginalRows == 173 && exported.ResultRows == 176, "Export rechecks current eligibility and reports exact added IDs and counts");
            Check(File.ReadAllBytes(exported.OriginalTable).SequenceEqual(source) && File.ReadAllBytes(exported.RepairedTable).SequenceEqual(output), "Export includes a byte-identical original outside BakeMe and the validated repaired table at its canonical CreateShow path");
            Check(paths.All(p => snapshots[p] == Digest(File.ReadAllBytes(Path.Combine(root, p)))), "Export changes none of the selected Discovery tables");
            Check(Rejected(() => DiscoveryCardLinkRepair.Export(root, Path.Combine(root, "bad-export"))) && !Directory.Exists(Path.Combine(root, "bad-export")), "Export inside the Discovery bake root is refused without creating files");
            Check(Rejected(() => DiscoveryCardLinkRepair.Export(root, exported.Directory)) && File.ReadAllBytes(exported.OriginalTable).SequenceEqual(source), "Existing output and its backup are not overwritten");

            File.WriteAllBytes(cards, output);
            Check(DiscoveryArenaLinkAudit.Read(root).Arenas.All(r => r.BinaryLinksMatchSuppliedProfile), "Reading the repaired fixture resolves all eight exact card/arena/movie chains");
            Check(Rejected(() => DiscoveryCardLinkRepair.Export(root, Path.Combine(temp, "nothing-to-export"))) && !Directory.Exists(Path.Combine(temp, "nothing-to-export")), "A repeated repair with no missing links creates no output");
            var excluded = DiscoveryArenaLinkAudit.Read(root); var row805 = excluded.Arenas.Single(r => r.ArenaId == 805);
            row805.CardLink = "Different from supplied profile";
            Check(!DiscoveryCardLinkRepair.Eligible(excluded).Contains(805), "An existing customized card is never treated as a missing link");
            row805.CardLink = "Record absent"; row805.ArenaTransitionLink = "Record absent";
            Check(!DiscoveryCardLinkRepair.Eligible(excluded).Contains(805), "A missing arena record blocks adding its card link");
            row805.ArenaTransitionLink = "Matches supplied profile"; row805.ActualMovieHashes = "0000000000000001";
            Check(!DiscoveryCardLinkRepair.Eligible(excluded).Contains(805), "A different actual transition hash blocks adding its card link");
            File.WriteAllBytes(cards, source); File.WriteAllBytes(Path.Combine(root, paths[2]), new byte[20]);
            Check(Rejected(() => DiscoveryCardLinkRepair.Export(root, Path.Combine(temp, "bad-movies"))) && !Directory.Exists(Path.Combine(temp, "bad-movies")), "Unreadable movie metadata blocks export before any output is created");
            Check(paths.All(p => originalHashes[p] == Digest(File.ReadAllBytes(Path.Combine(args[0], p)))), "All original uploaded source files remain unchanged");
            if (args.Length > 1) File.WriteAllText(args[1], JsonSerializer.Serialize(new { checks, fixture = "Earlier supplied binary data, reduced to 173 card rows and given the latest report's missing-ID pattern; not the user's actual current binary table", added_ids = Missing, original_rows = 173, result_rows = 176, preserves_all_existing_payload_bytes = true, source_game_data_changed = false, Windows_UI_or_gameplay_tested = false }, new JsonSerializerOptions { WriteIndented = true }));
            Console.WriteLine(checks + " card-link export checks passed."); return 0;
        }
        catch (Exception error) { Console.Error.WriteLine(error); return 1; }
        finally { if (Directory.Exists(temp)) Directory.Delete(temp, true); }
    }

    private static byte[] Select173(byte[] source)
    {
        var f = new FlatBufferFile(source, "StCr"); int[] rows = f.Tables(f.Root, 1).ToArray(); int[] required = { 800, 801, 803, 807, 808 };
        int[] keep = rows.Where(r => !Missing.Contains((int)Id(f, r))).ToArray();
        var chosen = new HashSet<int>(keep.Where(r => required.Contains((int)Id(f, r))));
        foreach (int r in keep) { if (chosen.Count == 173) break; chosen.Add(r); }
        int[] selected = rows.Where(chosen.Contains).ToArray();
        int field = f.Field(f.Root, 1), vector = field + (int)f.U32(field); byte[] copy = (byte[])source.Clone();
        Put32(copy, vector, (uint)selected.Length);
        for (int i = 0; i < selected.Length; i++) Put32(copy, vector + 4 + i * 4, (uint)(selected[i] - vector - 4 - i * 4));
        return copy;
    }
    private static byte[] AddArenaRows(byte[] source, int[] ids)
    {
        var f = new FlatBufferFile(source, "Aren"); int[] rows = f.Tables(f.Root, 0).ToArray();
        var b = new List<byte>(new byte[28 + 4 * (rows.Length + ids.Length)]); while (b.Count % 8 != 0) b.Add(0);
        int copy = b.Count; b.AddRange(source); Put32(b, 0, 16); for (int i = 0; i < 4; i++) b[4 + i] = (byte)"Aren"[i];
        Put16(b, 8, 6); Put16(b, 10, 8); Put16(b, 12, 4); Put32(b, 16, 8); Put32(b, 20, 4); Put32(b, 24, (uint)(rows.Length + ids.Length));
        for (int i = 0; i < rows.Length; i++) Put32(b, 28 + 4 * i, (uint)(copy + rows[i] - 28 - 4 * i));
        for (int i = 0; i < ids.Length; i++)
        {
            while (b.Count % 4 != 0) b.Add(0); int vt = b.Count; b.AddRange(new byte[12]);
            Put16(b, vt, 12); Put16(b, vt + 2, 12); Put16(b, vt + 8, 4); Put16(b, vt + 10, 8);
            int row = b.Count; b.AddRange(new byte[12]); Put32(b, row, 12); Put16(b, row + 4, ids[i]); Put32(b, row + 8, (uint)(ids[i] * 100 + 95));
            int at = 28 + 4 * (rows.Length + i); Put32(b, at, (uint)(row - at));
        }
        return b.ToArray();
    }
    private static string Text(FlatBufferFile f, int row, int field) { int at = f.Field(row, field); at += (int)f.U32(at); int n = (int)f.U32(at); return Encoding.UTF8.GetString(Enumerable.Range(0, n).Select(i => f.U8(at + 4 + i)).ToArray()); }
    private static uint Id(FlatBufferFile f, int row) { int at = f.Field(row, 0); return at == 0 ? 0 : f.U32(at); }
    private static bool Rejected(Action action) { try { action(); return false; } catch (Exception e) when (e is IOException || e is InvalidDataException) { return true; } }
    private static void Put16(IList<byte> b, int at, int value) { b[at] = (byte)value; b[at + 1] = (byte)(value >> 8); }
    private static void Put32(IList<byte> b, int at, uint value) { for (int i = 0; i < 4; i++) b[at + i] = (byte)(value >> (8 * i)); }
    private static string Digest(byte[] b) { return Convert.ToHexString(SHA256.HashData(b)); }
    private static void Check(bool ok, string message) { if (!ok) throw new Exception("FAIL: " + message); checks++; Console.WriteLine("PASS: " + message); }
}
