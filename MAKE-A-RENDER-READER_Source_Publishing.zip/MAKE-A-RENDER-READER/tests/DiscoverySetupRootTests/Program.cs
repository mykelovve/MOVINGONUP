using System;
using System.IO;
using GorillaStudio.NameFolders;

internal static class Program
{
    private static int checks;
    private static int Main()
    {
        string root = Path.Combine(Path.GetTempPath(), "gorilla-setup-root-" + Guid.NewGuid().ToString("N"));
        try
        {
            string current = Path.Combine(root, "new-data"), configured = Path.Combine(root, "configured"),
                saved = Path.Combine(root, "saved"), model = Path.Combine(root, "old-model-data");
            foreach (string path in new[] { current, configured, saved, model }) Directory.CreateDirectory(path);
            Directory.CreateDirectory(Path.Combine(current, "UI", "Projects"));
            Directory.CreateDirectory(Path.Combine(model, "Roster"));
            File.WriteAllText(Path.Combine(model, "Roster", "CharProfileTable.jsfb"), "old model roster");
            var choice = DiscoverySetupRoot.Resolve(current, configured, saved, model);
            Check(choice.Path == current && choice.Exists && choice.Error == null, "The newly selected data root wins over an old loaded wrestler's roster");
            choice = DiscoverySetupRoot.Resolve(model, model, model, model, current);
            Check(choice.Path == current && choice.Source == "selected UI bake folder", "An explicitly chosen UI-only bake folder is independent of the character roster");
            choice = DiscoverySetupRoot.Resolve(current, configured, saved, model);
            Check(choice.Source == "current Discovery data choice", "The selected root's provenance is explicit");
            Check(!File.Exists(Path.Combine(current, "Roster", "CharProfileTable.jsfb")), "Screen setup can use a fresh UI-only data root without requiring character mapping or roster metadata");
            choice = DiscoverySetupRoot.Resolve(null, configured, saved, model);
            Check(choice.Path == configured && choice.Exists, "The native current setup folder wins over an older saved roster location");
            choice = DiscoverySetupRoot.Resolve(null, null, saved, model);
            Check(choice.Path == saved && choice.Source == "saved Discovery data choice", "A saved data choice is used before model fallback");
            choice = DiscoverySetupRoot.Resolve(null, null, null, model);
            Check(choice.Path == model && choice.Source == "loaded model's roster folder", "Model context is only the final fallback when no data/setup choice exists");
            string missing = Path.Combine(root, "removed-data");
            choice = DiscoverySetupRoot.Resolve(missing, configured, saved, model);
            Check(choice.Path == missing && !choice.Exists && choice.Error.Contains(missing), "A removed explicit root is reported with its actual path");
            Check(choice.Path != model && choice.Path != configured, "A missing current choice cannot silently redirect game-setup writes to old data");
            choice = DiscoverySetupRoot.Resolve(null, missing, saved, model);
            Check(!choice.Exists && choice.Path == missing, "A missing configured setup root does not silently pick another saved folder");
            string file = Path.Combine(root, "not-a-directory"); File.WriteAllText(file, "keep");
            choice = DiscoverySetupRoot.Resolve(file, configured, saved, model);
            Check(!choice.Exists && choice.Error != null && File.ReadAllText(file) == "keep", "A selected file is not treated as a writable data root");
            choice = DiscoverySetupRoot.Resolve(" ", "", null, null);
            Check(choice.Path == null && !choice.Exists && choice.Error.Contains("Discovery"), "An absent data choice requests selection rather than guessing the working directory");
            choice = DiscoverySetupRoot.Resolve(current + Path.DirectorySeparatorChar + ".." + Path.DirectorySeparatorChar + "new-data", configured, saved, model);
            Check(choice.Exists && choice.Path == current, "Equivalent paths are normalized before use");
            choice = DiscoverySetupRoot.Resolve("\0bad", configured, saved, model);
            Check(!choice.Exists && choice.Path == null && choice.Error.Contains("invalid"), "Invalid explicit path syntax is a readable failure instead of a fallback write");
            Check(File.ReadAllText(Path.Combine(model, "Roster", "CharProfileTable.jsfb")) == "old model roster", "Resolving a fresh root never changes an old model's roster");
            Console.WriteLine(checks + " Discovery setup root checks passed."); return 0;
        }
        finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
    }
    private static void Check(bool value, string message) { if (!value) throw new Exception("FAILED: " + message); checks++; Console.WriteLine("PASS " + message); }
}
