using dnlib.DotNet;
using dnlib.DotNet.Emit;

if (args.Length != 4) {
    Console.Error.WriteLine("Usage: InstallSetupIsolationTests previous.exe previous-helper.dll candidate.exe candidate-helper.dll");
    return 2;
}
int checks = 0;
void Check(bool ok, string text) { if (!ok) throw new InvalidDataException(text); checks++; Console.WriteLine("PASS " + text); }
IEnumerable<MethodDef> Methods(ModuleDef module) => module.GetTypes().SelectMany(type => type.Methods).Where(method => method.HasBody);
IEnumerable<IMethod> Calls(MethodDef method) => method.Body.Instructions.Select(i => i.Operand).OfType<IMethod>();
MethodDef Install(ModuleDef module) => Methods(module).Single(method => method.Name == "MoveNext" && method.DeclaringType.FullName.Contains("<OnInstall>d__", StringComparison.Ordinal));
List<string> SetupCallers(ModuleDef module) => Methods(module).Where(method => Calls(method).Any(call => call.Name == "RunCombinedGameSetupAsync")).Select(method => method.FullName).ToList();
bool Manual(string name) => name.Contains("AttachPlaybackControls", StringComparison.Ordinal) || name.Contains("ShowPlaybackCheck", StringComparison.Ordinal);
try {
    using var oldApp = ModuleDefMD.Load(args[0]);
    using var oldHelper = ModuleDefMD.Load(args[1]);
    using var app = ModuleDefMD.Load(args[2]);
    using var helper = ModuleDefMD.Load(args[3]);
    Check(Calls(Install(oldApp)).Count(call => call.Name == "GameSetup" && call.DeclaringType.FullName == "Gorilla.RenderStudio.MainWindow") == 1,
        "Previous real application contains the automatic post-install setup call");
    Check(Calls(Install(app)).All(call => call.Name != "GameSetup" || call.DeclaringType.FullName != "Gorilla.RenderStudio.MainWindow"),
        "Candidate normal installation cannot directly invoke GameSetup");
    Check(Calls(Install(app)).Count(call => call.Name == "FinishRenderInstall" && call.DeclaringType.FullName == "GorillaStudio.NameFolders.FolderBridge") == 1,
        "Candidate normal installation awaits exactly one setup-preserving completion hook");
    var previousCallers = SetupCallers(oldHelper);
    var currentCallers = SetupCallers(helper);
    Check(previousCallers.Any(name => name.Contains("OpenBatchRosterAsync", StringComparison.Ordinal)),
        "Previous real batch-install completion also invoked full setup");
    Check(!currentCallers.Any(name => name.Contains("OpenBatchRosterAsync", StringComparison.Ordinal)),
        "Candidate batch installation does not invoke full setup");
    Check(currentCallers.Count == 2 && currentCallers.All(Manual),
        "Candidate helper runs combined setup only from its two explicit setup buttons");
    Check(previousCallers.Count(Manual) == 2,
        "Both explicit setup routes are retained from the previous helper");
    var complete = Methods(helper).Single(method => method.Name == "FinishRenderInstall" && method.DeclaringType.FullName == "GorillaStudio.NameFolders.FolderBridge");
    Check(complete.IsPublic && complete.IsStatic && complete.MethodSig.Params.Count == 2 && complete.MethodSig.Params[0].ElementType == ElementType.Object
        && complete.MethodSig.Params[1].ElementType == ElementType.Boolean && complete.MethodSig.RetType.FullName == "System.Threading.Tasks.Task",
        "The new completion signature preserves the original await stack contract");
    Check(Calls(complete).All(call => !call.Name.String.Contains("Setup", StringComparison.Ordinal)
        && !call.DeclaringType.FullName.StartsWith("System.IO.", StringComparison.Ordinal)
        && call.DeclaringType.FullName != "System.Diagnostics.Process"),
        "Install completion cannot invoke setup, filesystem or process side effects");
    Check(Methods(app).Any(method => method.Name == "GameSetup" && method.DeclaringType.FullName == "Gorilla.RenderStudio.MainWindow")
        && Methods(helper).Any(method => method.Name == "RunCombinedGameSetupAsync"),
        "Explicit UI preparation remains available");
    Console.WriteLine(checks + " real-binary install/setup isolation checks passed; Windows UI/game execution was not performed.");
    return 0;
} catch (Exception error) { Console.Error.WriteLine(error.Message); return 1; }
