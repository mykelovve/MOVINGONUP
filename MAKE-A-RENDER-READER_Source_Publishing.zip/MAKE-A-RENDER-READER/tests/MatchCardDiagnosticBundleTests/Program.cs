using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading;
using GorillaStudio.NameFolders;

internal static class Program
{
    private static int checks;
    private static int Main()
    {
        string root = Path.Combine(Path.GetTempPath(), "gorilla-log-bundle-" + Guid.NewGuid().ToString("N"));
        try
        {
            string game = Path.Combine(root, "game"), plugins = Path.Combine(game, "Plugins"), zip = Path.Combine(root, "diagnostics.zip");
            Directory.CreateDirectory(Path.Combine(plugins, "GorillaRenders"));
            string log = Path.Combine(plugins, "WWE2K26_MovingRenders.log"), ids = Path.Combine(plugins, "GorillaRenders", "_scan_ids.txt");
            File.WriteAllText(log, "failed game-run log"); File.WriteAllText(ids, "805\n368\n");
            File.WriteAllText(Path.Combine(plugins, "unrelated-secret.cfg"), "do not collect");
            var result = MatchCardDiagnosticBundle.Save(game, "actual selected folder report", zip, CancellationToken.None);
            Check(result.LogsCopied == 1 && result.InputFilesCopied == 1 && result.Notes.Any(n => n.Contains("Missing runtime log:") && n.Contains("SelectionLoop")), "Collects runtime evidence and explicitly reports the absent optional log");
            using (var archive = ZipFile.OpenRead(zip))
            {
                Check(archive.Entries.Count == 5 && Read(archive, "runtime/WWE2K26_MovingRenders.log") == "failed game-run log", "The ZIP contains readable exact runtime bytes");
                Check(Read(archive, "setup-report.txt") == "actual selected folder report" && Read(archive, "inputs/GorillaRenders/_scan_ids.txt") == "805\n368\n", "The displayed report and optional mapping input are both collected");
                Check(!archive.Entries.Any(e => e.FullName.Contains("secret")), "Unrelated configurations and assets are excluded");
            }
            Check(File.ReadAllText(log) == "failed game-run log" && File.ReadAllText(ids) == "805\n368\n", "Collection leaves game files unchanged");
            MatchCardDiagnosticBundle.Save(game, "replacement report", zip, CancellationToken.None);
            using (var archive = ZipFile.OpenRead(zip)) Check(Read(archive, "setup-report.txt") == "replacement report", "An explicitly chosen existing ZIP is replaced only after its new archive finishes");
            bool refused = false; try { MatchCardDiagnosticBundle.Save(game, "report", Path.Combine(plugins, "bad.zip"), CancellationToken.None); } catch (IOException) { refused = true; }
            Check(refused && !File.Exists(Path.Combine(plugins, "bad.zip")), "Output cannot add or overwrite files inside the installed game");
            byte[] before = File.ReadAllBytes(zip);
            using (var canceled = new CancellationTokenSource())
            {
                canceled.Cancel(); try { MatchCardDiagnosticBundle.Save(game, "canceled", zip, canceled.Token); } catch (OperationCanceledException) { }
            }
            Check(File.ReadAllBytes(zip).SequenceEqual(before) && !Directory.EnumerateFiles(root, "*.partial-*", SearchOption.AllDirectories).Any(), "Cancellation preserves an existing ZIP without leaving a partial file");
            File.WriteAllText(log, new string('A', 8 * 1024 * 1024 + 1024) + "LATEST FAILED RUN");
            result = MatchCardDiagnosticBundle.Save(game, "large log", zip, CancellationToken.None);
            using (var archive = ZipFile.OpenRead(zip)) Check(Read(archive, "runtime/WWE2K26_MovingRenders.log").EndsWith("LATEST FAILED RUN") && archive.GetEntry("runtime/WWE2K26_MovingRenders.log").Length == 8L * 1024 * 1024 && result.Notes.Any(n => n.Contains("latest")), "Oversized logs retain a bounded most-recent tail and disclose truncation");
            File.Delete(log); File.Delete(ids);
            result = MatchCardDiagnosticBundle.Save(game, "no logs", zip, CancellationToken.None);
            using (var archive = ZipFile.OpenRead(zip)) Check(result.LogsCopied == 0 && Read(archive, "included-files.txt").Contains("No runtime logs were found"), "A report-only bundle explicitly records missing runtime evidence");
            string cfg = Path.Combine(plugins, "WWE2K26_MovingRenders.cfg");
            File.WriteAllText(cfg, "enabled 0\nverbose 0\nscan_ids 1\nprivate_token must-never-leak\n");
            result = MatchCardDiagnosticBundle.Save(game, "settings", zip, CancellationToken.None);
            using (var archive = ZipFile.OpenRead(zip)) Check(Read(archive, "logging-status.txt").Contains("verbose 0")
                && Read(archive, "logging-status.txt").Contains("scan_ids 1") && !Read(archive, "logging-status.txt").Contains("must-never-leak"),
                "Known diagnostic settings are exported without unrelated private configuration content");
            Check(File.ReadAllText(cfg).Contains("verbose 0"), "Saving diagnostics never enables logging or changes the configuration");
            Console.WriteLine(checks + " match card diagnostic bundle checks passed."); return 0;
        }
        finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
    }
    private static string Read(ZipArchive zip, string entry) { using (var reader = new StreamReader(zip.GetEntry(entry).Open())) return reader.ReadToEnd(); }
    private static void Check(bool condition, string message) { if (!condition) throw new Exception("FAILED: " + message); checks++; Console.WriteLine("PASS " + message); }
}
