using System;
using System.IO;
using System.Linq;
using System.Text;
using GorillaStudio.NameFolders;

internal static class Program
{
    private static string root, game, config, native;
    private static int checks;
    private static void Main(string[] args)
    {
        if (args.Length != 1) throw new ArgumentException("Provide the original MovingRenders 4.21 plugin path.");
        native = Path.GetFullPath(args[0]); root = Path.Combine(Path.GetTempPath(), "gorilla-logging-" + Guid.NewGuid().ToString("N"));
        try
        {
            Reset(); string text = "# Existing settings – 雪\r\nenabled 0\r\nverbose 0 # retain comment\r\nscan_ids 1\r\ndiag 1\r\nmu_scale_test 42\r\nprivate_token hidden\r\n";
            byte[] before = new UTF8Encoding(true).GetPreamble().Concat(Encoding.UTF8.GetBytes(text)).ToArray(); File.WriteAllBytes(config, before);
            var result = MovingRenderDiagnostics.EnableLogging(game, () => true);
            Check(result.Enabled && result.Changed, "The genuine native plugin accepts a verbose-only logging change");
            byte[] expected = new UTF8Encoding(true).GetPreamble().Concat(Encoding.UTF8.GetBytes(text.Replace("verbose 0", "verbose 1"))).ToArray();
            Check(File.ReadAllBytes(config).SequenceEqual(expected), "Only verbose changes; BOM, Unicode, comments, disabled state and scan flags remain byte-identical");
            Check(File.ReadAllBytes(result.BackupPath).SequenceEqual(before), "The exact original config is backed up before publication");
            byte[] after = File.ReadAllBytes(config);
            result = MovingRenderDiagnostics.EnableLogging(game, () => true);
            Check(result.Enabled && !result.Changed && File.ReadAllBytes(config).SequenceEqual(after), "An already enabled configuration is a byte-identical no-op");
            string snapshot = MovingRenderDiagnostics.SettingsSnapshot(game);
            Check(snapshot.Contains("enabled 0") && snapshot.Contains("verbose 1") && snapshot.Contains("scan_ids 1") && !snapshot.Contains("hidden"), "Snapshot contains known numeric flags and excludes unrelated private content");
            Check(snapshot.Contains("optional mapping input") && snapshot.Contains("do not establish whether the plugin loaded"), "Absent mapping inputs and logs cannot falsely establish plugin activation");
            Reset(); File.WriteAllText(config, "enabled 0\n# verbose 0\n");
            result = MovingRenderDiagnostics.EnableLogging(game, () => true);
            Check(result.Enabled && File.ReadAllText(config) == "enabled 0\n# verbose 0\nverbose 1\n", "A missing verbose key is appended without changing enabled or comments");
            Reset(); File.WriteAllText(config, "enabled 1"); result = MovingRenderDiagnostics.EnableLogging(game, () => true);
            Check(result.Enabled && File.ReadAllText(config) == "enabled 1\nverbose 1\n", "A final line without a newline stays separate from the appended key");
            Reset(); File.WriteAllText(config, "VERBOSE 0\nverbose 0\nverbose 1\n"); result = MovingRenderDiagnostics.EnableLogging(game, () => true);
            Check(result.Enabled && File.ReadAllText(config) == "verbose 1\nverbose 1\nverbose 1\n", "Every active duplicate uses the native case-sensitive key and enabled value");
            Reset(); File.WriteAllText(config, "enabled 1\nverbose 0\n"); before = File.ReadAllBytes(config);
            result = MovingRenderDiagnostics.EnableLogging(game, () => false);
            Check(!result.Enabled && File.ReadAllBytes(config).SequenceEqual(before) && !File.Exists(config + ".before-logging.bak"), "A running game stops the operation before any configuration or backup change");
            File.Delete(config); result = MovingRenderDiagnostics.EnableLogging(game, () => true);
            Check(!result.Enabled && !File.Exists(config), "Missing configuration is reported instead of inventing plugin settings");
            File.WriteAllBytes(config, new byte[] { 0xff, 0xfe, 0xff }); before = File.ReadAllBytes(config);
            result = MovingRenderDiagnostics.EnableLogging(game, () => true);
            Check(!result.Enabled && File.ReadAllBytes(config).SequenceEqual(before), "Unreadable encoding is preserved without replacement");
            File.WriteAllText(config, new string('x', 1024 * 1024 + 1)); result = MovingRenderDiagnostics.EnableLogging(game, () => true);
            Check(!result.Enabled, "Oversized configuration is rejected before modification");
            Reset(); File.WriteAllText(config, "enabled 0\nverbose 0\n"); before = File.ReadAllBytes(config);
            string plugin = Path.Combine(game, "Plugins", "WWE2K26_MovingRenders.dlp"); var tampered = File.ReadAllBytes(plugin); tampered[tampered.Length - 1] ^= 1; File.WriteAllBytes(plugin, tampered);
            result = MovingRenderDiagnostics.EnableLogging(game, () => true);
            Check(!result.Enabled && File.ReadAllBytes(config).SequenceEqual(before), "An unknown same-size plugin cannot authorize assumed native diagnostic options");
            Reset(); File.WriteAllText(config, "enabled 1\nverbose 0\n"); before = File.ReadAllBytes(config); int calls = 0;
            result = MovingRenderDiagnostics.EnableLogging(game, () => ++calls < 3);
            Check(!result.Enabled && File.ReadAllBytes(config).SequenceEqual(before) && !Directory.EnumerateFiles(root, "*.tmp", SearchOption.AllDirectories).Any(), "A game starting before publication leaves config intact and cleans its owned staging file");
            Check(!Directory.Exists(Path.Combine(game, "UI")) && !Directory.Exists(Path.Combine(game, "Plugins", "GorillaRenders")), "Enabling logging creates no UI files, movie files or scan mapping inputs");
            Reset(); File.WriteAllText(config, "enabled 0\nverbose 0\n"); File.WriteAllText(config + ".before-logging.bak", "retain first backup");
            result = MovingRenderDiagnostics.EnableLogging(game, () => true);
            Check(result.Enabled && File.ReadAllText(config + ".before-logging.bak") == "retain first backup", "A later logging change never overwrites the existing original backup");
            Reset(); string outside = Path.Combine(root, "outside.cfg"); File.WriteAllText(outside, "enabled 0\nverbose 0\n"); File.CreateSymbolicLink(config, outside);
            result = MovingRenderDiagnostics.EnableLogging(game, () => true);
            Check(!result.Enabled && File.ReadAllText(outside) == "enabled 0\nverbose 0\n", "A linked configuration cannot redirect logging writes to another file");
            Console.WriteLine(checks + " moving render diagnostic checks passed.");
        }
        finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
    }
    private static void Reset()
    {
        if (Directory.Exists(root)) Directory.Delete(root, true);
        game = Path.Combine(root, "game"); string plugins = Path.Combine(game, "Plugins"); Directory.CreateDirectory(plugins);
        File.Copy(native, Path.Combine(plugins, "WWE2K26_MovingRenders.dlp")); config = Path.Combine(plugins, "WWE2K26_MovingRenders.cfg");
    }
    private static void Check(bool passed, string label) { if (!passed) throw new Exception("FAILED: " + label); checks++; Console.WriteLine("PASS " + label); }
}
