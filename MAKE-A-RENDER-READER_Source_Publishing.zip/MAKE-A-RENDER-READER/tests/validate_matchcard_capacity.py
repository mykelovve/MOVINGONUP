#!/usr/bin/env python3
"""Execute the original and proposed match-card context instructions on Linux x64.

This maps the pinned PE's instruction/data RVAs, not its Windows initialization.
Only external-function continuations are redirected to test return stubs.
It does not execute WWE, CakeHook, Bink decoding or authorization.
"""
import argparse
import ctypes
import json
import mmap
import platform
import struct
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from matchcard_capacity_plan import *


class Image:
    def __init__(self, original, patched, mode='registration', reader=None):
        self.size=IMAGE_SIZE+0x10000
        self.mem=mmap.mmap(-1,self.size,prot=mmap.PROT_READ|mmap.PROT_WRITE)
        self.address=ctypes.addressof(ctypes.c_char.from_buffer(self.mem))
        self.mem[0x1000:0xd800]=original[0x400:0xcc00]
        self.pool=IMAGE_SIZE if patched else OLD_POOL
        self.capacity=CAPACITY if patched else 16
        if patched:
            for rva,before,after in resolved_patches(make_plan(original),self.address,self.address+self.pool):
                assert self.mem[rva:rva+len(before)]==before
                self.mem[rva:rva+len(after)]=after
        self.wrap=IMAGE_SIZE+0x7000
        # Public Win64 lookup: SysV's first argument goes to RCX.
        lookup=bytes.fromhex('48 89 f9')+relative(b'\xe9',self.wrap+3,0x1b30)
        self.mem[self.wrap:self.wrap+len(lookup)]=lookup
        self.lookup_rva=self.wrap
        self.wrap+=0x100
        if mode=='registration':
            body=bytearray.fromhex('55 56 41 57 48 81 ec 00 02 00 00 48 89 e5 41 89 f7 89 95 90 01 00 00')
            body+=relative(b'\xe9',self.wrap+len(body),0xb67e)
            end=self.wrap+len(body)
            body+=bytes.fromhex('48 81 c4 00 02 00 00 41 5f 5e 5d c3')
            self.mem[self.wrap:self.wrap+len(body)]=body
            self.mem[0xb764:0xb769]=relative(b'\xe9',0xb764,end)
        else:
            entry,source,destination,yes,no=reader
            body=bytearray.fromhex('55 53 41 54 57 56 48 83 ec 50 48 89 e5 48 89 74 24 40 48 89 64 24 48 48 89 fe')
            body+=bytes.fromhex('48 b9')+struct.pack('<Q',0x1234567887654321)
            body+=bytes.fromhex('48 ba')+struct.pack('<Q',0xfedcba9876543210)
            body+=relative(b'\xe9',self.wrap+len(body),entry)
            found=self.wrap+len(body)
            body+=self.capture(destination)
            missing=self.wrap+len(body)
            body+=bytes.fromhex('b8 ff ff ff ff')+self.capture('eax')
            self.mem[self.wrap:self.wrap+len(body)]=body
            self.mem[yes:yes+5]=relative(b'\xe9',yes,found)
            self.mem[no:no+5]=relative(b'\xe9',no,missing)
        libc=ctypes.CDLL(None,use_errno=True)
        for offset,length in [(0x1000,0xd000),(IMAGE_SIZE+0x7000,0x1000)]:
            if libc.mprotect(ctypes.c_void_p(self.address+offset),ctypes.c_size_t(length),mmap.PROT_READ|mmap.PROT_EXEC):
                raise OSError(ctypes.get_errno(),'mprotect')
        self.lookup=ctypes.CFUNCTYPE(ctypes.c_int32,ctypes.c_uint64)(self.address+self.lookup_rva)
        if mode=='registration':
            self.register=ctypes.CFUNCTYPE(ctypes.c_uint64,ctypes.c_uint64,ctypes.c_uint32,ctypes.c_uint32)(self.address+self.wrap)
        else:
            self.reader=ctypes.CFUNCTYPE(None,ctypes.c_uint64,ctypes.c_void_p)(self.address+self.wrap)

    @staticmethod
    def capture(destination):
        store={'eax':'41 89 03','ebx':'41 89 1b','r12d':'45 89 23','edi':'41 89 3b'}[destination]
        return bytes.fromhex('4c 8b 5c 24 40 '+store+' 49 89 4b 08 49 89 53 10 4c 8d 14 24 4d 89 53 18 4c 8b 54 24 48 4d 89 53 20 48 83 c4 50 5e 5f 41 5c 5b 5d c3')

    def handles(self):
        return [struct.unpack_from('<Q',self.mem,self.pool+i*STRIDE)[0] for i in range(self.capacity)]

    def close(self):
        self.mem.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--original',type=Path,required=True)
    parser.add_argument('--report',type=Path,required=True)
    args=parser.parse_args()
    if platform.machine()!='x86_64': raise RuntimeError('Native x86_64 required')
    original=args.original.read_bytes(); plan=make_plan(original)
    checks=0
    old=Image(original,False)
    for i in range(17): old.register(0x100000+i, i%8+1, i%20)
    assert old.lookup(0x100000)==-1 and old.lookup(0x100010)==0; checks+=1
    assert len(set(old.handles()))==16; checks+=1
    old.close()
    fixed=Image(original,True)
    guard=fixed.pool+CAPACITY*STRIDE
    fixed.mem[guard:guard+64]=b'\xa5'*64
    for i in range(CAPACITY):
        assert fixed.register(0x100000+i,i%8+1,i%20)==i*STRIDE; checks+=1
        assert fixed.lookup(0x100000+i)==i; checks+=1
    assert fixed.handles()==list(range(0x100000,0x100000+CAPACITY)); checks+=1
    for i in range(CAPACITY):
        assert fixed.lookup(0x100000+i)==i; checks+=1
        assert struct.unpack_from('<II',fixed.mem,fixed.pool+i*STRIDE+8)==(i%8+1,i%20); checks+=1
    assert fixed.lookup(0x99999999)==-1; checks+=1
    assert fixed.mem[guard:guard+64]==b'\xa5'*64; checks+=1
    # A closed context's hole and a re-opened identical handle are reused without
    # modifying any other context. This is the original registration machine code.
    for hole in [0,16,50,100,119]:
        offset=fixed.pool+hole*STRIDE
        fixed.mem[offset:offset+STRIDE]=b'\x5a'*STRIDE
        struct.pack_into('<Q',fixed.mem,offset,0)
        before=fixed.mem[fixed.pool:guard]
        assert fixed.register(0x200000+hole,7,9)==hole*STRIDE; checks+=1
        assert fixed.lookup(0x200000+hole)==hole; checks+=1
        after=fixed.mem[fixed.pool:guard]
        assert before[:hole*STRIDE]==after[:hole*STRIDE] and before[(hole+1)*STRIDE:]==after[(hole+1)*STRIDE:]; checks+=1
        assert after[hole*STRIDE+16:(hole+1)*STRIDE]==b'\0'*(STRIDE-16); checks+=1
        assert fixed.register(0x200000+hole,8,10)==hole*STRIDE; checks+=1
    fixed.close()
    reader_rows=[]
    for reader in READERS:
        test=Image(original,True,'reader',reader)
        for i in range(CAPACITY): struct.pack_into('<Q',test.mem,test.pool+i*STRIDE,0x100000+i)
        for index in list(range(CAPACITY))+[-1]:
            output=ctypes.create_string_buffer(40)
            test.reader(0x99999999 if index<0 else 0x100000+index,ctypes.addressof(output))
            value,rcx,rdx,rsp,saved_rsp=struct.unpack('<I4xQQQQ',output.raw)
            assert value==(index&0xffffffff),(reader,index,hex(value)); checks+=1
            assert rcx==0x1234567887654321 and rdx==0xfedcba9876543210; checks+=1
            assert rsp==saved_rsp and rsp%16==0; checks+=1
        reader_rows.append({'site_rva':hex(reader[0]),'all_120_indices_and_missing_handle_passed':True,'RCX_RDX_and_stack_preserved':True})
        test.close()
    assert args.original.read_bytes()==original; checks+=1
    report={'scope':'Exact original and proposed x64 context instructions executed in an isolated Linux harness; no WWE/Bink/CakeHook execution.',
            'original_sha256':ORIGINAL_SHA,'production_original_changed':False,
            'original_seventeenth_registration_overwrites_first_context':True,
            'fixed_120_distinct_contexts_retained':True,'fixed_closed_holes_and_reopened_handles_reused':True,
            'all_inline_readers':reader_rows,'checks':checks,'patch_sites':len(plan['patches']),
            'gameplay_verified':False,'known_user_graph_contains_movie_layers':101,
            'limits':['The user screenshot does not measure concurrently open Bink handles.','This establishes and fixes a context-capacity defect, not proof that it is the sole cause of the screenshot.','Full-pool replacement policy, authorization, game offsets and native layout routing are unchanged.']}
    args.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'checks':checks,'original_17th_overwrites_first':True,'fixed_retained':120,'reader_sites_tested':len(reader_rows),'gameplay_verified':False}))


if __name__=='__main__': main()
