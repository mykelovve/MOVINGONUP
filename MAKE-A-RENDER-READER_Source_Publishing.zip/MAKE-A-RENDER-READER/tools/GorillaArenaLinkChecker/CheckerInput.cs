using System;
using System.IO;
using System.Linq;
using System.Text;

internal static class CheckerInput
{
    private static readonly string[] Tables = { "CreateShow/MatchUpScreenAsset.jsfb", "Arena/ArenaData.jsfb", "Movies/MovieDataTable.jsfb" };
    private static string PreferenceFile { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GorillaStudio", "ArenaLinkChecker", "last-discovery-root.txt"); } }

    private static string Clean(string input) { return Environment.ExpandEnvironmentVariables((input ?? "").Trim().Trim('"')); }

    internal static string ResolveRoot(string input)
    {
        string value = Clean(input);
        if (string.IsNullOrWhiteSpace(value)) throw new IOException("Paste your Discovery data folder path, or drag the folder or one of its three table files into the path box.");
        value = Path.GetFullPath(value);
        bool isFile = File.Exists(value);
        if (isFile && !Tables.Any(table => Path.GetFileName(table).Equals(Path.GetFileName(value), StringComparison.OrdinalIgnoreCase)))
            throw new IOException("Choose MatchUpScreenAsset.jsfb, ArenaData.jsfb or MovieDataTable.jsfb, or paste the full Discovery data folder path.");
        if (!isFile && !Directory.Exists(value)) throw new DirectoryNotFoundException("That Discovery path does not exist. Paste the full path from File Explorer's address bar.");
        string directory = isFile ? Path.GetDirectoryName(value) : value;
        // Accept a table file or its containing CreateShow/Arena/Movies folder.
        // Inspect only nearby ancestors, never a recursive drive search.
        var candidate = new DirectoryInfo(directory);
        for (int level = 0; candidate != null && level < 4; level++, candidate = candidate.Parent)
            if (Tables.Any(table => File.Exists(Path.Combine(candidate.FullName, table.Replace('/', Path.DirectorySeparatorChar))))) return candidate.FullName;
        if (isFile) throw new IOException("The selected table is not inside a Discovery CreateShow, Arena or Movies folder. Paste the full data root instead.");
        return directory;
    }

    internal static string ExistingDirectory(string input)
    {
        try { string value = Clean(input); return Directory.Exists(value) ? value : File.Exists(value) ? Path.GetDirectoryName(value) : null; }
        catch (Exception error) when (PreferenceError(error)) { return null; }
    }

    internal static string LoadLastOrDefault()
    {
        try
        {
            if (File.Exists(PreferenceFile) && new FileInfo(PreferenceFile).Length < 16384)
            {
                string saved = File.ReadAllText(PreferenceFile).Trim();
                if (Directory.Exists(saved)) return saved;
            }
        }
        catch (Exception error) when (PreferenceError(error)) { }
        string defaultRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Steam", "steamapps", "common", "WWE 2K26", "discovery", "discovery_data");
        return Directory.Exists(defaultRoot) ? defaultRoot : "";
    }

    internal static void Remember(string root)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(PreferenceFile));
            File.WriteAllText(PreferenceFile, root, new UTF8Encoding(false));
        }
        catch (Exception error) when (PreferenceError(error)) { /* A preference cannot block the report. */ }
    }

    private static bool PreferenceError(Exception error)
    { return error is IOException || error is UnauthorizedAccessException || error is ArgumentException || error is NotSupportedException || error is System.Security.SecurityException; }
}
