using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using GorillaStudio.NameFolders;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        if (args.Length != 0)
        {
            try
            {
                if (args.Length != 3) throw new ArgumentException("Usage: GorillaArenaLinkChecker.exe --check|--export-card-links <full-Discovery-data-root> <new-output-folder-outside-data>");
                if (args[0] == "--check") Write(DiscoveryArenaLinkAudit.Read(args[1]), args[2]);
                else if (args[0] == "--export-card-links") DiscoveryCardLinkRepair.Export(args[1], args[2]);
                else throw new ArgumentException("Choose --check or --export-card-links.");
                return 0;
            }
            catch (Exception error) { Console.Error.WriteLine(error.Message); return 1; }
        }
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new CheckerWindow()); return 0;
    }

    internal static void Write(DiscoveryArenaLinkAudit.Report report, string output)
    {
        output = Path.GetFullPath(output);
        string root = report.CheckedRoot.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        if (output.Equals(root, StringComparison.OrdinalIgnoreCase) || output.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new IOException("Save the report outside the checked Discovery folder.");
        if (Directory.Exists(output) || File.Exists(output)) throw new IOException("Choose a new report folder to preserve existing files.");
        Directory.CreateDirectory(output);
        var text = new StringBuilder("CURRENT DISCOVERY ARENA / CARD / TRANSITION LINKS\r\n\r\n");
        text.AppendLine("Checked: " + report.CheckedRoot); text.AppendLine("UTC: " + report.CheckedUtc);
        text.AppendLine("This checker changes no Discovery, game, CAK, plugin or render files. Do not bake this report folder.");
        text.AppendLine(report.Limit); text.AppendLine();
        foreach (string table in report.Tables) text.AppendLine(table);
        foreach (string warning in report.Warnings) text.AppendLine("WARNING: " + warning);
        var csv = new StringBuilder("Arena ID,Show,Card link,Arena transition link,Movie link,Current card hash,Current transition ID,Current movie hash,Expected card hash,Expected transition ID,Expected movie hash,Project path,Transition path,Loose project,Loose transition,Path warning,Binary links match supplied profile\r\n");
        foreach (var row in report.Arenas)
        {
            text.AppendLine(); text.AppendLine(row.ArenaId + " - " + row.Show);
            text.AppendLine("  Card: " + row.CardLink + "; current " + row.ActualProjectHashes + "; expected " + row.ExpectedProjectHash);
            text.AppendLine("  Arena transition: " + row.ArenaTransitionLink + "; current " + row.ActualTransitionIds + "; expected " + row.ExpectedTransitionId);
            text.AppendLine("  Movie: " + row.MovieLink + "; current " + row.ActualMovieHashes + "; expected " + row.ExpectedMovieHash);
            text.AppendLine("  Project: " + row.ProjectPath + " - " + row.LooseProject);
            text.AppendLine("  Transition: " + row.TransitionPath + " - " + row.LooseTransition);
            if (!string.IsNullOrEmpty(row.PathWarning)) text.AppendLine("  PATH WARNING: " + row.PathWarning);
            object[] fields = { row.ArenaId, row.Show, row.CardLink, row.ArenaTransitionLink, row.MovieLink,
                row.ActualProjectHashes, row.ActualTransitionIds, row.ActualMovieHashes, row.ExpectedProjectHash,
                row.ExpectedTransitionId, row.ExpectedMovieHash, row.ProjectPath, row.TransitionPath,
                row.LooseProject, row.LooseTransition, row.PathWarning, row.BinaryLinksMatchSuppliedProfile };
            csv.AppendLine(string.Join(",", fields.Select(value => "\"" + Convert.ToString(value).Replace("\"", "\"\"") + "\"")));
        }
        File.WriteAllText(Path.Combine(output, "arena-links.txt"), text.ToString(), new UTF8Encoding(true));
        File.WriteAllText(Path.Combine(output, "arena-links.csv"), csv.ToString(), new UTF8Encoding(true));
        File.WriteAllText(Path.Combine(output, "arena-links.json"), new JavaScriptSerializer { MaxJsonLength = 1024 * 1024 }.Serialize(report), new UTF8Encoding(false));
    }
}

internal sealed class CheckerWindow : Form
{
    private readonly TextBox path = new TextBox { Dock = DockStyle.Fill, AllowDrop = true, AutoCompleteMode = AutoCompleteMode.SuggestAppend, AutoCompleteSource = AutoCompleteSource.FileSystem };
    private readonly Button browse = new Button { Text = "Browse file...", AutoSize = true };
    private readonly Button check = new Button { Text = "Check", AutoSize = true };
    private readonly Button repair = new Button { Text = "Export missing card links...", AutoSize = true, Enabled = false };
    private readonly Button open = new Button { Text = "Open report folder", AutoSize = true, Enabled = false };
    private readonly Label status = new Label { AutoSize = true, MaximumSize = new Size(1100, 0) };
    private readonly DataGridView grid = new DataGridView { Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells, RowHeadersVisible = false };
    private string lastReport;
    private string checkedRoot;
    public CheckerWindow()
    {
        Text = "Gorilla Studio - Arena card and transition checker 1.2"; Width = 1180; Height = 550; MinimumSize = new Size(760, 390);
        var top = new TableLayoutPanel { Dock = DockStyle.Top, Height = 154, Padding = new Padding(12), ColumnCount = 1, RowCount = 4 };
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        top.RowStyles.Add(new RowStyle(SizeType.Absolute, 44)); top.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        top.RowStyles.Add(new RowStyle(SizeType.Absolute, 34)); top.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var hint = new Label { Text = "Paste your Discovery folder or table file path below, or drop it onto the path box. Press Enter to check.\r\nThe last folder is remembered. Browse file has an address bar. Reports are saved on your Desktop.", Dock = DockStyle.Fill };
        var input = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 1, Margin = Padding.Empty };
        input.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize)); input.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        input.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize)); input.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        input.Controls.Add(new Label { Text = "Discovery path", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 0);
        input.Controls.Add(path, 1, 0); input.Controls.Add(browse, 2, 0); input.Controls.Add(check, 3, 0);
        var actions = new FlowLayoutPanel { Dock = DockStyle.Fill, Margin = Padding.Empty }; actions.Controls.Add(open); actions.Controls.Add(repair);
        top.Controls.Add(hint, 0, 0); top.Controls.Add(input, 0, 1); top.Controls.Add(actions, 0, 2); top.Controls.Add(status, 0, 3);
        var foot = new Label { Dock = DockStyle.Bottom, Height = 42, Padding = new Padding(12, 4, 12, 0), Text = "Matching links do not confirm a bake or in-game playback. A file not extracted here may still exist inside a CAK. Existing arena IDs are compared to the supplied profiles." };
        Controls.Add(grid); Controls.Add(foot); Controls.Add(top);
        path.Text = CheckerInput.LoadLastOrDefault();
        path.TextChanged += (sender, args) => { checkedRoot = null; repair.Enabled = false; };
        AcceptButton = check;
        Shown += (sender, args) => { path.Focus(); path.SelectAll(); };
        check.Click += async (sender, args) => await Check();
        repair.Click += async (sender, args) => await ExportRepair();
        browse.Click += async (sender, args) =>
        {
            using (var picker = new OpenFileDialog { Title = "Choose MatchUpScreenAsset.jsfb, ArenaData.jsfb or MovieDataTable.jsfb", Filter = "Discovery tables (*.jsfb)|*.jsfb|All files (*.*)|*.*", CheckFileExists = true, Multiselect = false, AutoUpgradeEnabled = true })
            {
                string initial = CheckerInput.ExistingDirectory(path.Text);
                if (initial != null) picker.InitialDirectory = Directory.Exists(Path.Combine(initial, "CreateShow")) ? Path.Combine(initial, "CreateShow") : initial;
                if (picker.ShowDialog(this) != DialogResult.OK) return;
                path.Text = picker.FileName;
            }
            await Check();
        };
        path.DragEnter += (sender, args) =>
        {
            var paths = args.Data.GetData(DataFormats.FileDrop) as string[];
            args.Effect = paths != null && paths.Length == 1 ? DragDropEffects.Copy : DragDropEffects.None;
        };
        path.DragDrop += async (sender, args) =>
        {
            var paths = args.Data.GetData(DataFormats.FileDrop) as string[];
            if (paths == null || paths.Length != 1) return;
            path.Text = paths[0]; await Check();
        };
        open.Click += (sender, args) => Process.Start(new ProcessStartInfo(lastReport) { UseShellExecute = true });
    }

    private async Task Check()
    {
        check.Enabled = false; browse.Enabled = false; path.Enabled = false; open.Enabled = false; repair.Enabled = false;
        status.Text = "Reading the three binary tables...";
        try
        {
            string selected = path.Text;
            var report = await Task.Run(() => DiscoveryArenaLinkAudit.Read(CheckerInput.ResolveRoot(selected)));
            path.Text = report.CheckedRoot;
            lastReport = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "GorillaStudio-Arena-Check-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0, 6));
            await Task.Run(() => Program.Write(report, lastReport));
            if (report.Tables.Count > 0) CheckerInput.Remember(report.CheckedRoot);
            checkedRoot = report.CheckedRoot;
            int count = DiscoveryCardLinkRepair.Eligible(report).Length;
            repair.Text = count == 0 ? "Export missing card links..." : "Export " + count + " missing card link(s)...";
            repair.Enabled = count > 0;
            grid.DataSource = report.Arenas.Select(row => new { row.ArenaId, row.Show, row.CardLink, row.ArenaTransitionLink, row.MovieLink, row.LooseProject, row.LooseTransition, row.PathWarning }).ToList();
            status.Text = report.Arenas.Count(row => row.BinaryLinksMatchSuppliedProfile) + "/8 binary link chains match the supplied profiles; " + report.Warnings.Count + " table warning(s). Report saved.";
            open.Enabled = true;
            open.Text = "Open report folder";
        }
        catch (Exception error) { status.Text = "Check stopped."; MessageBox.Show(this, error.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error); }
        finally { check.Enabled = true; browse.Enabled = true; path.Enabled = true; }
    }

    private async Task ExportRepair()
    {
        if (checkedRoot == null) return;
        check.Enabled = false; browse.Enabled = false; path.Enabled = false; repair.Enabled = false; open.Enabled = false;
        status.Text = "Rechecking current tables and exporting missing links with an original backup...";
        try
        {
            string root = checkedRoot;
            string output = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "GorillaStudio-Card-Link-Repair-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0, 6));
            var result = await Task.Run(() => DiscoveryCardLinkRepair.Export(root, output));
            lastReport = result.Directory; open.Text = "Open repair folder"; open.Enabled = true;
            status.Text = "Exported " + result.AddedArenaIds.Length + " missing card link(s), " + result.OriginalRows + " -> " + result.ResultRows + " rows. Source data unchanged. Open repair folder for bake/rollback steps.";
        }
        catch (Exception error) { status.Text = "Export stopped; run Check again."; MessageBox.Show(this, error.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error); }
        finally { check.Enabled = true; browse.Enabled = true; path.Enabled = true; }
    }
}
