using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using GorillaStudio.NameFolders;

internal static class Program
{
    private static int Main(string[] args)
    {
        if (args.Length != 2) { Console.Error.WriteLine("Usage: GorillaFreshUiPack original-app-root new-empty-output-root"); return 2; }
        string app = Path.GetFullPath(args[0]), output = Path.GetFullPath(args[1]);
        if (Directory.Exists(output) || File.Exists(output)) throw new IOException("Fresh UI output must be a new directory.");
        string pack = Path.Combine(app, "data", "gamepack", "screens", "BakeMe");
        if (!Directory.Exists(pack)) throw new IOException("The original supplied screen pack was not found.");
        Directory.CreateDirectory(output);
        foreach (string source in Directory.GetFiles(pack, "*", SearchOption.AllDirectories))
        {
            string target = Path.Combine(output, Path.GetRelativePath(pack, source));
            Directory.CreateDirectory(Path.GetDirectoryName(target)); File.Copy(source, target, false);
        }
        var prepared = MatchCardLayouts.Apply(app, output, false);
        var check = MatchCardLayouts.Apply(app, output, true);
        if (prepared.Failed.Count + prepared.Unsupported.Count + check.Failed.Count + check.Unsupported.Count != 0
            || check.Patched != 0 || check.AddedMovies != 0 || check.AddedSlots != 0 || check.RepairedSlots != 0
            || Directory.GetFiles(Path.Combine(output, "UI", "Assets", "movies", "gorilla_renders"), "ph_*.bk2").Length != 101)
            throw new IOException("The fresh screen pack failed final structural validation.");
        var report = new { source = "Original user-supplied Gorilla Studio v1.0.2 stock screen pack", prepared, check,
            uiFiles = Directory.GetFiles(Path.Combine(output, "UI"), "*", SearchOption.AllDirectories).Length,
            placeholderMovies = 101, WindowsOrGameTested = false, vanillaGameUi = false };
        File.WriteAllText(Path.Combine(output, "PREPARATION.json"), JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));
        Console.WriteLine(JsonSerializer.Serialize(report)); return 0;
    }
}
