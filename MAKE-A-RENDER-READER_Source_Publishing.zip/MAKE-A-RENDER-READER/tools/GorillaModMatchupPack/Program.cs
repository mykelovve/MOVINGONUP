using System.Security.Cryptography;
using System.Text.Json;
using GorillaStudio.NameFolders;

if (args.Length < 3) throw new ArgumentException("Usage: GorillaModMatchupPack original-app-root new-output-root extracted-project-root [...]");
string output = Path.GetFullPath(args[1]), data = Path.Combine(output, "BakeMe");
if (Directory.Exists(output) || File.Exists(output)) throw new IOException("Output must be a new directory.");
var originals = new List<object>();
var paths = new List<string>();
foreach (string sourceRoot in args.Skip(2).Select(Path.GetFullPath))
foreach (string source in Directory.GetFiles(sourceRoot, "*.jsfb", SearchOption.AllDirectories).OrderBy(x => x, StringComparer.Ordinal))
{
    string relative = Path.GetRelativePath(sourceRoot, source), destination = Path.Combine(data, relative);
    byte[] bytes = File.ReadAllBytes(source);
    if (bytes.Length < 8 || System.Text.Encoding.ASCII.GetString(bytes, 4, 4) != "Scre") throw new InvalidDataException("Not a Scre project: " + source);
    Directory.CreateDirectory(Path.GetDirectoryName(destination)!); File.WriteAllBytes(destination, bytes);
    paths.Add(destination);
    originals.Add(new { path = relative.Replace('\\', '/'), bytes = bytes.Length, sha256 = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant() });
}
if (paths.Count == 0) throw new IOException("No projects supplied.");
var prepared = MatchCardLayouts.Apply(args[0], data, false, paths);
var check = MatchCardLayouts.Apply(args[0], data, true, paths);
var report = new { originals, prepared, check, windowsOrGameTested = false };
Directory.CreateDirectory(output);
File.WriteAllText(Path.Combine(output, "PREPARATION.json"), JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine(JsonSerializer.Serialize(report));
if (prepared.Failed.Count + prepared.Unsupported.Count + check.Failed.Count + check.Unsupported.Count != 0
    || check.Patched != 0 || check.CheckedSlots == 0 || check.AddedMovies != 0 || check.AddedSlots != 0 || check.RepairedSlots != 0)
    throw new InvalidDataException("Some actual mod projects need further work; see PREPARATION.json. Do not distribute this incomplete output.");
if (!string.IsNullOrWhiteSpace(prepared.BackupDirectory))
{
    Directory.Move(prepared.BackupDirectory, Path.Combine(output, "Original project backups"));
    string parent = Path.GetDirectoryName(prepared.BackupDirectory);
    if (Directory.Exists(parent) && !Directory.EnumerateFileSystemEntries(parent).Any()) Directory.Delete(parent);
}
