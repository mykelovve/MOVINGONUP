#!/usr/bin/env python3
"""Build the optional Windows x64 match-card capacity companion and test host."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
from matchcard_capacity_plan import make_plan, header

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--zig',type=Path,required=True)
parser.add_argument('--original',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
source=root/'src/MatchCardCapacityPlugin'
out=args.output.resolve(); out.mkdir(parents=True,exist_ok=True)
plan=make_plan(args.original.read_bytes())
if (source/'patch_plan.h').read_text()!=header(plan):
    raise SystemExit('Generated plan header changed; regenerate and rerun native checks before building')
env=dict(os.environ)
common=['-target','x86_64-windows-gnu','-std=c++17','-O2','-fno-exceptions','-fno-rtti',
        '-fno-builtin-memchr','-fno-builtin-wcschr','-fno-builtin-wcsrchr','-Wall','-Wextra','-Werror']
def run(tail):
    subprocess.run([str(args.zig.resolve()),'c++',*common,*map(str,tail)],cwd=root,env=env,check=True)
plugin=out/'WWE2K26_MatchCardCapacity.dlp'
run(['-shared',source/'plugin.cpp','-lbcrypt','-luser32','-o',plugin])
run(['-municode',source/'tests/windows_host.cpp','-lbcrypt','-luser32','-o',out/'MatchCardCapacityHostTests.exe'])
shutil.copyfile(source/'WWE2K26_MatchCardCapacity.cfg',out/'WWE2K26_MatchCardCapacity.cfg')
manifest={'schema':1,'experimental':True,'plugin':plugin.name,'bytes':plugin.stat().st_size,
          'sha256':sha256(plugin.read_bytes()).hexdigest(),'original_sha256':plan['original_sha256'],
          'old_capacity':16,'new_capacity':120,'patch_sites':len(plan['patches']),
          'original_file_changed':False,'UI_or_GMR_payload_changes':False,'gameplay_verified':False}
(out/'BUILD_INFO.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest))
