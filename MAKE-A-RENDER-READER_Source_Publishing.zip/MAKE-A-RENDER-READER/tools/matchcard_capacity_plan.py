#!/usr/bin/env python3
"""Build the exact 4.21 match-card context-capacity patch plan.

This does not change the original file. The companion applies the plan only to
an already initialized, SHA-pinned original in memory. No authorization, game
offset, GMR parser, layout identifier or Bink routing instruction is changed.
"""
from hashlib import sha256
from pathlib import Path
import argparse
import json
import struct

ORIGINAL_SHA = 'b752da3c9a9dc48dc377972a7183db0194c2b3b551074f7d0f0c9766432bf75c'
CAPACITY = 120  # Even, fits the original signed imm8 loop bound, covers 101 slots.
STRIDE = 0xc0
OLD_POOL = 0x137e0
IMAGE_SIZE = 0xf4f000
# Entry, original match pointer register, destination index, found, not found.
READERS = [
    (0x119a, 'rsi', 'ebx', 0x12d7, 0x125a),
    (0x16a7, 'rsi', 'eax', 0x17c6, 0x17f1),
    (0x1ee3, 'rdi', 'eax', 0x2002, 0x2058),
    (0xa3b7, 'rsi', 'eax', 0xa4d6, 0xa512),
    (0xa578, 'rsi', 'r12d', 0xa6db, 0xa648),
    (0xa878, 'rsi', 'edi', 0xa97f, 0xa98f),
]
BASES = [0x12eb, 0x17cd, 0x2009, 0xa4dd, 0xa6f0, 0xb684, 0xb704]


def raw_offset(rva):
    if not 0x1000 <= rva < 0xd776:
        raise ValueError('Only pinned original text instructions may be patched')
    return rva - 0x1000 + 0x400


def relative(op, at, destination):
    return op + struct.pack('<i', destination - at - len(op) - 4)


def make_plan(original):
    if len(original) != 69632 or sha256(original).hexdigest() != ORIGINAL_SHA:
        raise ValueError('Expected the exact original MovingRenders 4.21 file')
    patches = []

    def add(rva, after, purpose, relocation=None):
        before = original[raw_offset(rva):raw_offset(rva) + len(after)]
        patches.append(dict(rva=rva, before=before.hex(), after=after.hex(),
                            purpose=purpose, pool_displacement_offset=relocation))

    # Keep the public lookup's original RBP prologue/unwind information. Its new
    # body preserves RDX as well as all other original non-result GPRs. The
    # temporary push is below the stable RBP frame and there are no external calls.
    lookup_rva = 0x1b34
    assert original[raw_offset(0x1b30):raw_offset(0x1b30) + 4] == bytes.fromhex('55 48 89 e5')
    body = bytearray.fromhex('52 48 8d 15 00 00 00 00 31 c0')
    loop = len(body)
    body += bytes.fromhex('48 39 0a 74 00 ff c0 48 81 c2 c0 00 00 00 83 f8') + bytes([CAPACITY])
    body += bytes([0x72, (loop - (len(body) + 2)) & 255])
    body += bytes.fromhex('b8 ff ff ff ff')
    found = len(body)
    body[loop + 4] = found - (loop + 5)
    body += bytes.fromhex('5a 5d c3')
    add(lookup_rva, body, 'Lookup all 120 match-card contexts', 4)

    # Each mid-function call keeps RCX/RDX, all nonvolatile registers other than
    # its documented index result, and the original stack. Reserve real Win64
    # shadow space and preserve 16-byte call alignment. Both outcomes jump to
    # their original continuations, including original critical-section release.
    for entry, source, destination, yes, no in READERS:
        body = bytearray.fromhex('51 52 48 83 ec 20')
        body += bytes.fromhex('48 89 f1' if source == 'rsi' else '48 89 f9')
        body += relative(b'\xe8', entry + len(body), 0x1b30)
        body += bytes.fromhex('48 83 c4 20 5a 59 85 c0')
        body += relative(bytes.fromhex('0f 88'), entry + len(body), no)
        body += {'eax': b'', 'ebx': bytes.fromhex('89 c3'),
                 'r12d': bytes.fromhex('41 89 c4'), 'edi': bytes.fromhex('89 c7')}[destination]
        body += relative(b'\xe9', entry + len(body), yes)
        assert entry + len(body) < min(yes, no)
        add(entry, body, 'Expanded reader: ' + destination)

    for rva in BASES:
        code = original[raw_offset(rva):raw_offset(rva) + 7]
        assert code[:3] in [bytes.fromhex(s) for s in ['48 8d 0d', '4c 8d 35', '48 8d 05', '48 8d 35']]
        assert rva + 7 + struct.unpack_from('<i', code, 3)[0] == OLD_POOL
        add(rva, code[:3] + b'\0' * 4, 'Relocate match-card context base', 3)

    assert original[raw_offset(0xb6a6):raw_offset(0xb6a6)+4] == bytes.fromhex('48 83 f9 10')
    add(0xb6a6, bytes.fromhex('48 83 f9') + bytes([CAPACITY]), 'Registration scans 120 entries')
    assert original[raw_offset(0xa7b7):raw_offset(0xa7b7)+7] == bytes.fromhex('49 81 fd 00 0c 00 00')
    add(0xa7b7, bytes.fromhex('49 81 fd') + struct.pack('<I', CAPACITY * STRIDE),
        'Cross-layout visibility scan covers the same 120 entries')
    spans = sorted((p['rva'], p['rva'] + len(bytes.fromhex(p['before']))) for p in patches)
    assert all(a[1] <= b[0] for a, b in zip(spans, spans[1:]))
    return dict(original_sha256=ORIGINAL_SHA, original_bytes=69632,
                image_size=IMAGE_SIZE, old_pool_rva=OLD_POOL, stride=STRIDE,
                old_capacity=16, capacity=CAPACITY, patches=patches,
                authentication_or_game_offsets_changed=False)


def resolved_patches(plan, module_base, pool):
    result = []
    for item in plan['patches']:
        after = bytearray.fromhex(item['after'])
        offset = item['pool_displacement_offset']
        if offset is not None:
            displacement = pool - (module_base + item['rva'] + offset + 4)
            struct.pack_into('<i', after, offset, displacement)
        result.append((item['rva'], bytes.fromhex(item['before']), bytes(after)))
    return result


def header(plan):
    def array(value):
        return '{' + ','.join('0x' + value[i:i+2] for i in range(0,len(value),2)) + '}'
    lines = ['// Generated by tools/matchcard_capacity_plan.py from the SHA-pinned original.',
             '#pragma once', '#include <stdint.h>', '#include <stddef.h>',
             'struct PatchSpec { uint32_t rva; uint16_t length; int16_t pool_offset; unsigned char before[64], after[64]; };',
             'static constexpr unsigned kCapacity = 120, kStride = 192;',
             'static constexpr uintptr_t kOldPool = 0x137e0;',
             'static constexpr const char* kOriginalSha = "' + ORIGINAL_SHA + '";',
             'static const PatchSpec kPatches[] = {']
    for p in plan['patches']:
        assert len(bytes.fromhex(p['before'])) <= 64
        lines.append('    {0x%x,%d,%d,%s,%s}, // %s' % (p['rva'],len(bytes.fromhex(p['before'])),
                     -1 if p['pool_displacement_offset'] is None else p['pool_displacement_offset'],
                     array(p['before']),array(p['after']),p['purpose']))
    lines += ['};', 'static constexpr size_t kPatchCount = sizeof(kPatches)/sizeof(kPatches[0]);', '']
    return '\n'.join(lines)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--original',type=Path,required=True)
    parser.add_argument('--json',type=Path,required=True)
    parser.add_argument('--header',type=Path,required=True)
    args=parser.parse_args()
    plan=make_plan(args.original.read_bytes())
    args.json.write_text(json.dumps(plan,indent=2)+'\n')
    args.header.parent.mkdir(parents=True,exist_ok=True)
    args.header.write_text(header(plan))
    print('Built guarded plan:',len(plan['patches']),'sites; 16 -> 120 contexts; original file unchanged')
