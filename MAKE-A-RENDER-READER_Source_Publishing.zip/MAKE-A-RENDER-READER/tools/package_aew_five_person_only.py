"""Copy the earlier small AEW checkpoint into one isolated BakeMe ZIP."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo
import json

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "downloads/GorillaStudio_Dynamite_Collision_Five_Person_Isolation_Test.zip"
SOURCE_HASH = "40a1e3b621ad9a54ed4fe12baedadb42044cd2d45c5595863cc4994679473ecc"
OUTPUT = ROOT / "downloads/GorillaStudio_AEW_Only_Five_Person_BakeMe_UI.zip"
README = """AEW ONLY - EARLIER FIVE-PERSON CHECKPOINT

Dynamite and Collision only: the two AEW projects in the smaller checkpoint
associated with your report that five-person was perfect and six-person went
back to regular portraits. All 16 game input files are copied byte for byte.

MOVING LAYOUTS
One-on-one, normal 2v2 tag, triple threat, five-person free-for-all (5man).
Six-person, 3v3, 4v4, eight-person and other omitted layouts retain their
original portrait nodes. This is the earlier four-layout scope.

ONE INPUT FOLDER - 16 FILES
  BakeMe/UI/Projects/ShowAssets/matchup/       2 AEW projects
  BakeMe/UI/Assets/movies/gorilla_renders/    14 shared movies

RECOVERY / BAKE
1. Close WWE. Keep the actual restored, working FULL discovery_data.cak and
   original arena/character archives installed. Back up the working files and
   saved source outside the game/bake folders.
2. Extract this ZIP into a NEW folder. In Discovery, use a DEDICATED UI bake
   entry whose input is this BakeMe folder (CONTAINING UI), not the full
   discovery_data folder. The input has exactly 16 files. Use WWE 2K26 / 9.9
   and your working bake settings. Set the dedicated CAK output name before
   baking and retain that exact filename afterwards.
3. Keep one dedicated matchup override active. Put aside the old dedicated
   all-layout/SummerSlam test CAK, while keeping the working full data CAK.
   Do not replace the working full data CAK with these UI-only inputs.
4. Keep original MovingRenders/config and installed GMRs. Leave the later
   optional MatchCardCapacity companion put aside, as in the smaller recovery.
5. Bake once, fully restart WWE and check the earlier five-person case, then
   six-person regular portraits.

Do not merge old all-layout source into this folder. Do not run full Studio
Game setup on this isolated input: it adds the omitted layouts back again.
The received 1,113-file discovery_data.cak still had 101 movie slots per card;
this pack has 14 per card. Removing loose files alone does not undo an old bake.

CHECKS
Payloads match the earlier source exactly. Source audits preserve all omitted
layout properties; all 14 placeholder movies decode. This is a source rollback,
not a newly verified startup-crash fix. WWE gameplay cannot be run here.
No prebuilt CAK is supplied. README/checksums/checks stay OUTSIDE BakeMe.
"""


def package():
    hold = ROOT / "docs/RECURRING_UI_STARTUP_CRASH.json"
    if hold.exists() and json.loads(hold.read_text()).get("status") == "held":
        raise SystemExit("UI rebake trials held after reported startup crash; inspect the actual latest CAK before recreating downloads.")
    assert sha256(SOURCE.read_bytes()).hexdigest() == SOURCE_HASH
    with ZipFile(SOURCE) as archive:
        assert archive.testzip() is None
        payload = {name: archive.read(name) for name in archive.namelist()
                   if name.startswith("BakeMe/")}
    audit = json.loads((ROOT / "docs/FIVE_PERSON_RECOVERY_AUDIT.json").read_text())
    expected = {row["path"]: row for row in audit["files"]}
    assert payload.keys() == expected.keys() and len(payload) == 16
    projects = sorted(name for name in payload if name.endswith(".jsfb"))
    assert projects == [
        "BakeMe/UI/Projects/ShowAssets/matchup/AEW_Collision_2026.jsfb",
        "BakeMe/UI/Projects/ShowAssets/matchup/AEW_Dynamite_2026.jsfb"]
    for name, data in payload.items():
        assert len(data) == expected[name]["bytes"]
        assert sha256(data).hexdigest() == expected[name]["sha256"]
    report = {"scope": "Exact smaller Dynamite/Collision checkpoint; AEW-only isolated input.",
              "source_zip": SOURCE.name, "source_zip_sha256": SOURCE_HASH,
              "source_commit": "cc089cda6ec9d1f55abf8a7344846d36ccf0866c",
              "payload_files": 16, "movie_layers_per_project": 14,
              "source_payloads_unchanged": True,
              "layouts": ["1on1", "2on2", "triple_threat", "5man"],
              "omitted_layouts_keep_original_properties": True,
              "new_gameplay_or_startup_fix_verified": False,
              "files": audit["files"]}
    files = {**payload, "README.txt": README.encode(),
             "CHECKS.json": (json.dumps(report, indent=2) + "\n").encode()}
    files["SHA256SUMS.txt"] = "".join(
        f"{sha256(data).hexdigest()}  {name}\n"
        for name, data in sorted(files.items())).encode()
    with ZipFile(OUTPUT, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            info = ZipInfo(name, date_time=(2026, 10, 26, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    with ZipFile(OUTPUT) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == 19
        assert {n: archive.read(n) for n in archive.namelist()
                if n.startswith("BakeMe/")} == payload
        assert not any(n.endswith((".cak", ".dlp", ".gmr", ".cfg"))
                       for n in archive.namelist())
    digest = sha256(OUTPUT.read_bytes()).hexdigest()
    OUTPUT.with_suffix(".SHA256.txt").write_text(f"{digest}  {OUTPUT.name}\n")
    receipt = {"file": OUTPUT.name, "bytes": OUTPUT.stat().st_size,
               "sha256": digest, "payload_files": 16, "unchanged_source_files": 16,
               "only_AEW_projects": ["Dynamite", "Collision"],
               "source_commit": report["source_commit"],
               "gameplay_retested": False}
    (ROOT / "docs/AEW_ONLY_FIVE_PERSON_PACKAGE.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    package()
