"""Package the small read-only checker after its Release/net48 build.

Usage: python3 tools/package_arena_link_checker.py
No game or uploaded metadata bytes are included.
"""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import csv
import io
import json

repo = Path(__file__).resolve().parents[1]
source = json.loads((repo / "docs/MOD_ARENA_CARD_LINKS.json").read_text())
build = repo / "tools/GorillaArenaLinkChecker/bin/Release/net48"
out = repo / "downloads/GorillaStudio_Arena_Card_Transition_Checker.zip"
rows = [{key: row[key] for key in ("arena_id", "matchup_project_hash", "matchup_project", "transition_movie_id", "transition_hash", "transition_path")}
        for row in source["arenas"]]
assert len(rows) == 8
files = {name: (build / name).read_bytes()
         for name in ("GorillaArenaLinkChecker.exe", "GorillaArenaLinkChecker.exe.config")}
files["README.txt"] = b"""ARENA CARD / TRANSITION CHECKER 1.2 - CHECKS AND OPTIONAL REPAIR EXPORT

Extract this ZIP. Run GorillaArenaLinkChecker.exe on Windows (.NET Framework 4.8).
Save your Discovery edits first. Paste the full Discovery data folder path into
the path box and press Enter or click Check. You can also drag a folder or table
file onto the path box, or use Browse file with its normal Windows address bar.
Choose MatchUpScreenAsset.jsfb, ArenaData.jsfb or MovieDataTable.jsfb; the data
root is found automatically. The full root contains Arena, CreateShow and Movies;
the isolated Dynamite/Collision BakeMe input is not the data root for this check.
Click Open report folder afterward.

OPTIONAL MISSING-CARD REPAIR
After Check, click Export missing card links... if it is enabled. The tool
rereads your CURRENT local tables and creates a NEW Desktop folder with:
  BakeMe/CreateShow/MatchUpScreenAsset.jsfb  (repaired table)
  Original/CreateShow/MatchUpScreenAsset.jsfb  (byte-identical original)
  README.txt and checksums
The selected Discovery folder is unchanged. Existing custom card records are
preserved. Only ABSENT records with matching original arena/transition links
are added. Existing zero/different/conflicting cards and absent arenas are not
overwritten. A later data edit is checked again at export time.

For the supplied 2026-10-25 17:35:53Z report, the three absent card IDs are
804 ROH Supercard, 805 Dynasty and 806 Double or Nothing. Forbidden Door's links
are now present. Revolution and Redemption already have matching references;
this export is not a runtime loading fix for those shows.

Close WWE. Back up the working dedicated CAK AND its input outside game/bake
folders. Copy ONLY the exported BakeMe/CreateShow into your working dedicated
BakeMe input BESIDE UI. Preserve its existing UI/Arena files. Bake the SAME
working Discovery entry/output filename once and restart WWE. Do not bake the
whole export folder, import Original, or run full Studio Game setup on this
isolated input. Read the generated README for source-data updates and rollback.
Keep the original Titavius arena CAK and arena/movie data installed.

This repairs missing card references only. It does not add moving movie layers,
replace transitions, or confirm that the game selected the baked override.

The last successfully read folder is remembered for next time in
%LOCALAPPDATA%/GorillaStudio/ArenaLinkChecker/last-discovery-root.txt.
On first use the usual Steam/WWE 2K26 discovery/discovery_data path is prefilled
if it exists. Other drive locations can be pasted directly. The legacy folder
tree dialog is no longer used. The command-line folder check still works.

A new GorillaStudio-Arena-Check-... folder on your Desktop contains
arena-links.txt, arena-links.csv and arena-links.json. Send arena-links.txt
so the CURRENT binary links can be compared with the supplied source profiles.
The report contains the selected local path and three file hashes.

Checks: Dynamite, Collision, Revolution, ROH Supercard of Honor, Dynasty,
Double or Nothing, Forbidden Door and Redemption. The tool reads the actual
card hash, arena transition ID and movie hash, and checks loose file headers.
Different, absent, zero, duplicate and unreadable links are reported separately.
JSON exports cannot silently fill incomplete binary tables. Files may remain
inside CAKs; not loose here does not mean absent from your installed game.

Earlier uploaded data has all eight card links and expected movie records but
four absent binary arena rows (804/805/806/807). Your current data may differ.
Revolution's references match in that earlier copy; its runtime cause is still
unresolved. A matching link is not confirmation of a bake or game playback.

This is NOT a BakeMe pack. Do not bake it. It installs no game files and changes no
Discovery, game, CAK, plugin, profile or render files. Keep your working
Dynamite/Collision setup. The tool does not add moving layers to other arenas.

Nineteen audit checks and 26 repair-export checks pass. The repair tests use a
fixture derived from earlier uploaded binary data with the latest report's
missing-ID pattern, not a reconstruction of the current 173 records. The repair
is generated from YOUR local data at runtime. Windows GUI and gameplay for this
new version are untested here.
More details and source:
https://github.com/janeg7207-droid/MAKE-A-RENDER-READER/blob/main/docs/ARENA_LINK_CHECKER.md
"""
files["EXPECTED_SOURCE_LINKS.json"] = (json.dumps({"baseline": "Original supplied Titavius profiles; active user data and winning archives are not inferred", "arenas": rows}, indent=2) + "\n").encode()
files["REPAIR_EXPORT_CHECKS.json"] = (repo / "docs/CARD_LINK_REPAIR_TESTS.json").read_bytes()
table = io.StringIO(newline="")
writer = csv.DictWriter(table, fieldnames=list(rows[0]), lineterminator="\r\n")
writer.writeheader()
writer.writerows(rows)
files["EXPECTED_SOURCE_LINKS.csv"] = table.getvalue().encode("utf-8-sig")
files["SHA256SUMS.txt"] = "".join(f"{sha256(value).hexdigest()}  {name}\n" for name, value in sorted(files.items())).encode()
with ZipFile(out, "w", compression=ZIP_DEFLATED, compresslevel=9) as z:
    for name, value in sorted(files.items()):
        info = ZipInfo(name, date_time=(2026, 10, 25, 0, 0, 0))
        info.compress_type = ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, value)
with ZipFile(out) as z:
    assert z.testzip() is None
    assert not any(name.endswith((".jsfb", ".bk2", ".cak", ".gmr", ".dlp")) or name.startswith("BakeMe/") for name in z.namelist())
digest = sha256(out.read_bytes()).hexdigest()
(out.with_suffix(".SHA256.txt")).write_text(f"{digest}  {out.name}\n")
print(json.dumps({"file": out.name, "bytes": out.stat().st_size, "sha256": digest, "files": list(files)}, indent=2))
