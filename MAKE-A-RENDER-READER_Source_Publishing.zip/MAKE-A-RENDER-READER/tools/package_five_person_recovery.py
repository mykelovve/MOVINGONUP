"""Repackage the exact smaller checkpoint, without generating any new game data."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo
import json

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "downloads/GorillaStudio_Dynamite_Collision_Five_Person_Isolation_Test.zip"
SOURCE_SHA256 = "40a1e3b621ad9a54ed4fe12baedadb42044cd2d45c5595863cc4994679473ecc"
OUTPUT = ROOT / "downloads/GorillaStudio_Five_Person_Recovery_BakeMe_UI.zip"

README = """DYNAMITE / COLLISION - EARLIER FIVE-PERSON RECOVERY

This restores the smaller source checkpoint associated with your report:
"It was perfect for the five, and then the six man, it went back to renders."
All 16 BakeMe files have the exact same paths and bytes as that smaller pack.
This is a rollback, not another all-layout/capacity experiment.

MOVING LAYOUTS INCLUDED
One-on-one, normal 2v2 tag, triple threat, and five-person free-for-all.
Triple threat is retained from the earlier input, not newly gameplay-verified.
This does NOT enable every match type with five or fewer participants.
Six-person, 3v3, eight-person, 4v4 and all other omitted layouts keep their
original project nodes and regular still portraits. Only Dynamite and Collision
are overridden here. Other arenas are being reviewed separately.

RESTORE
1. Close WWE completely. Back up the current dedicated matchup CAK and its
   source folder outside the game and Discovery bake input.
2. If you installed the later capacity companion, move BOTH
   WWE2K26_MatchCardCapacity.dlp and WWE2K26_MatchCardCapacity.cfg outside Plugins.
   Keep the original WWE2K26_MovingRenders.dlp/config and existing GMRs.
   This ZIP contains no plugin or config changes.
3. If you saved the actual smaller CAK that worked for five, restore it with
   its exact original filename and its saved source. Otherwise rebuild using
   the fresh BakeMe folder in this ZIP as described below.
4. Put aside the current dedicated all-layout/capacity-test matchup CAK outside
   the game's loaded folders. Keep ONE dedicated matchup override active.
   Keep original arena, character and normal game/setup archives installed.
   Do not remove your original Titavius arena CAK or installed render library.

IF REBUILDING IN DISCOVERY
Extract this ZIP to a NEW folder. Select BakeMe (the folder CONTAINING UI) as
input in the same working Discovery entry. Keep the same working output CAK
filename/path, WWE 2K26 version 9.9 and other settings. Bake once and fully
restart WWE. No prebuilt CAK is included.

    BakeMe/
      UI/
        Projects/ShowAssets/matchup/    2 projects
        Assets/movies/gorilla_renders/  14 movies

Do not merge this into the old all-layout folder. That retains unwanted files.
Do not run full Studio Game setup on this isolated input: it proposes the
deliberately omitted 87 extra slots per project and expands the rollback again.
Merely deleting loose files does not undo an already baked CAK.

CHECK
Try the same earlier successful five-person match first, then a six-person match.
The six-person card should use the regular original portraits. File checks
confirm all omitted layout properties match the original supplied projects.
All 14 placeholders fully decode; this environment cannot retest WWE gameplay.
If either case still stalls, restore the saved working CAK/input; a different
active UI override, game loading or model mapping can still affect the match.

CHECKS.json records source/payload hashes and original-layout comparisons.
README, CHECKS and SHA256SUMS stay OUTSIDE BakeMe and are not game input.
"""


def package():
    hold = ROOT / "docs/RECURRING_UI_STARTUP_CRASH.json"
    if hold.exists() and json.loads(hold.read_text()).get("status") == "held":
        raise SystemExit("UI rebake trials held after reported startup crash; inspect the actual latest CAK before recreating downloads.")
    assert sha256(SOURCE.read_bytes()).hexdigest() == SOURCE_SHA256
    with ZipFile(SOURCE) as source:
        assert source.testzip() is None
        payload = {name: source.read(name) for name in source.namelist()
                   if name.startswith("BakeMe/")}
    report = json.loads((ROOT / "docs/FIVE_PERSON_RECOVERY_AUDIT.json").read_text())
    expected = {row["path"]: row for row in report["files"]}
    assert set(payload) == set(expected) and len(payload) == 16
    assert report["source_zip_sha256"] == SOURCE_SHA256
    assert report["six_or_more_movie_layers"] == 0
    assert report["six_or_more_original_layout_properties_preserved"] is True
    for name, data in payload.items():
        assert name.startswith("BakeMe/UI/") and ".." not in name.split("/")
        assert len(data) == expected[name]["bytes"]
        assert sha256(data).hexdigest() == expected[name]["sha256"]
    files = dict(payload)
    files["README.txt"] = README.encode()
    files["CHECKS.json"] = (json.dumps(report, indent=2) + "\n").encode()
    files["SHA256SUMS.txt"] = "".join(
        f"{sha256(data).hexdigest()}  {name}\n"
        for name, data in sorted(files.items())
    ).encode()
    with ZipFile(OUTPUT, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            info = ZipInfo(name, date_time=(2026, 10, 26, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    with ZipFile(OUTPUT) as archive:
        assert archive.testzip() is None
        assert {name: archive.read(name) for name in archive.namelist()
                if name.startswith("BakeMe/")} == payload
        assert len(archive.namelist()) == 19
        assert not any(name.endswith((".dlp", ".cfg", ".gmr", ".cak"))
                       for name in archive.namelist())
    digest = sha256(OUTPUT.read_bytes()).hexdigest()
    OUTPUT.with_suffix(".SHA256.txt").write_text(f"{digest}  {OUTPUT.name}\n")
    print(json.dumps({"file": str(OUTPUT), "bytes": OUTPUT.stat().st_size,
                      "sha256": digest, "unchanged_checkpoint_payloads": len(payload)}))


if __name__ == "__main__":
    package()
