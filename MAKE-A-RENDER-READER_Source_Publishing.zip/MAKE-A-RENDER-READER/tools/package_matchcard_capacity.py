#!/usr/bin/env python3
"""Package the separately validated capacity companion; never bundles an original plugin or UI."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--work',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
work=args.work; build=work/'build'
info=json.loads((build/'BUILD_INFO.json').read_text())
native=json.loads((work/'NATIVE_CHECKS.json').read_text())
windows=json.loads((work/'WINDOWS_HOST_CHECKS.json').read_text())
static=json.loads((work/'STATIC_CHECKS.json').read_text())
plugin=(build/info['plugin']).read_bytes()
assert sha256(plugin).hexdigest()==info['sha256']==windows['tested_plugin_sha256']
assert native['checks']==2689 and native['original_seventeenth_registration_overwrites_first_context']
assert native['fixed_120_distinct_contexts_retained'] and len(native['all_inline_readers'])==6
assert windows['host_exit_code']==0 and windows['guarded_patch_transaction_succeeded']
assert windows['thread_inside_native_code_refused_and_resumed'] and windows['production_DLL_normal_load_and_imports_passed']
assert static['all_passed'] and len(static['all_live_base_references_covered'])==7
assert not info['gameplay_verified'] and not windows['actual_WWE_activation_or_playback_verified']
cfg=(build/'WWE2K26_MatchCardCapacity.cfg').read_bytes()
assert cfg==b'enabled 1\n'
readme='''MATCH-CARD CAPACITY FIX TEST

1. Close WWE 2K26 completely.
2. Copy this ZIP's Plugins folder into your WWE 2K26 game folder and merge.
   It adds only WWE2K26_MatchCardCapacity.dlp and its .cfg (enabled 1).
3. KEEP the original WWE2K26_MovingRenders.dlp, its configuration, current
   combined CAK, original arena archives and installed GMRs in place.
4. Restart WWE. Retest the same five-person Dynamite match, then 3v3.

NO NEW BAKE, GAME SETUP OR MAKE IS NEEDED FOR THIS TEST.

This corrects a reproduced native movie-tracking defect: registration 17
overwrites the first live record. The companion expands the table AND all
readers from 16 to 120. The original plugin file, UI and GMRs are unchanged.

Activation appears in Plugins/WWE2K26_MatchCardCapacity.log:
ACTIVE: match-card contexts expanded from 16 to 120; original file and UI unchanged
The log also records sampled peaks of active contexts. An activation refusal
includes its reason. If playback still fails, send this new log directly;
older Studio diagnostics versions do not collect it.

Supported original: the exact unchanged MovingRenders 4.21 supplied with Studio.
The original must initialize normally. This companion does not enable a missing
original or bypass its initialization/authorization.

REMOVE: close WWE, move only WWE2K26_MatchCardCapacity.dlp and its .cfg out of
Plugins, then restart. The changes existed only in process memory, so the
original native behavior returns without rebaking.

VALIDATION: 2,689 exact native instruction checks and the Win64 mapped-PE,
thread-refusal, transaction, lookup and production-load hosts passed under Wine.
Actual WWE/CakeHook activation, Bink decoding and gameplay remain UNVERIFIED.
The capacity defect is established; it is not proof of the sole screenshot
cause or of all-match-type compatibility. No prebuilt CAK is supplied.

Source, details and updated results:
https://github.com/mykelovve/MOVE-A-RENDER-/blob/main/docs/MATCHCARD_CAPACITY_TEST.md
'''
payload={
    'Plugins/WWE2K26_MatchCardCapacity.dlp':plugin,
    'Plugins/WWE2K26_MatchCardCapacity.cfg':cfg,
    'README.txt':readme.encode(),
    'BUILD_INFO.json':(build/'BUILD_INFO.json').read_bytes(),
    'NATIVE_CHECKS.json':(work/'NATIVE_CHECKS.json').read_bytes(),
    'WINDOWS_HOST_CHECKS.json':(work/'WINDOWS_HOST_CHECKS.json').read_bytes(),
    'STATIC_CHECKS.json':(work/'STATIC_CHECKS.json').read_bytes(),
}
payload['SHA256SUMS.txt']=''.join(sha256(b).hexdigest()+'  '+n+'\n' for n,b in sorted(payload.items())).encode()
args.output.parent.mkdir(parents=True,exist_ok=True)
with ZipFile(args.output,'w',ZIP_DEFLATED,compresslevel=9) as z:
    for name,blob in sorted(payload.items()):
        entry=ZipInfo(name,date_time=(2026,10,25,0,0,0)); entry.compress_type=ZIP_DEFLATED
        entry.external_attr=0o100644<<16
        z.writestr(entry,blob,compresslevel=9)
with ZipFile(args.output) as z:
    assert z.testzip() is None and set(z.namelist())==set(payload)
    assert all(z.read(n)==b for n,b in payload.items())
    assert len([n for n in z.namelist() if n.lower().endswith('.dlp')])==1
    assert all(not n.lower().endswith(('.cak','.gmr','.bk2','.exe')) for n in z.namelist())
result={'file':args.output.name,'bytes':args.output.stat().st_size,'sha256':sha256(args.output.read_bytes()).hexdigest(),
        'plugin_sha256':info['sha256'],'original_UI_and_GMR_files_in_package':False,'CRC_and_payload_checks_passed':True}
(work/'PACKAGE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
