AEW ARENA MATCH CARDS - one-on-one, 2 vs 2, triple threat, fatal four-way
(same recipe that works on Dynamite/Collision; 14 movies per card, under the limit of 16)

  Arena/Titavius/803_-_AEW_Revolution_2026/...      (earlier Revolution tests failed loading - test it alone if trouble)
  Arena/Titavius/805_-_AEW_Dynasty_2026/...         (may also need its card link - see below)
  Arena/Titavius/807_-_AEW_Forbidden_Door_2026/...
  Arena/Titavius/808_-_AEW_Redemption_2026/...

1. Close WWE. Back up your current CAK.
2. Extract this zip into discovery_data (the folder that contains UI and Arena). Choose Replace.
3. Bake once in Discovery (output TITAVUSREVATCHCARD). Keep only the newest TITAVUSREVATCHCARD cak in mods.
4. Test a one-on-one on Forbidden Door or Redemption first.

Not included yet: ROH Supercard (804) and Double or Nothing 2026 (806) - send me their matchup .jsfb
(matchup_rohsupercardofhonor_26.jsfb / matchup_doubleornothing_26.jsfb).
Dynasty, ROH Supercard and Double or Nothing were missing their card link in older notes; if one still shows
the plain card, its link needs repair (send CreateShow/MatchUpScreenAsset.jsfb).
