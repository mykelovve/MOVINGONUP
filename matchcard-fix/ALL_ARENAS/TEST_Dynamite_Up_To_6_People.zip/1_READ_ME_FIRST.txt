TEST: Dynamite with all 13 match types up to 6 people (59 render slots).
Copy TITAVUSREVATCHCARD into ...\discovery\ (Replace), bake, restart, test Dynamite:
1on1, 6-pack, triple threat tag, 1v4. If it freezes, re-run your installer and bake to undo.
