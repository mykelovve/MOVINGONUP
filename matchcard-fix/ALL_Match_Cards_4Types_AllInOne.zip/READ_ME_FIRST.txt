ALL MATCH CARDS - ALL IN ONE (154 cards)
Moving portraits: one-on-one, 2 vs 2, triple threat, fatal four-way. Every card <= 16 movies.
Original plugin only - make sure the capacity add-on is NOT in Plugins.

1. Close WWE. Back up your current working CAK and your discovery_data\UI and Arena folders.
2. Extract into discovery_data (the folder that contains UI and Arena). Choose Replace.
   - UI\...   your own 130 match cards (fixed) + SummerSlam 09 at its exact path
   - Arena\...  AEW Revolution, Dynasty, Forbidden Door, Redemption and Rev's SummerSlam 26
3. "Put in its original folder" (18 cards): move each one back to the folder its original came from,
   same file name, then delete that helper folder. (All Out 19/25, All In 18, ROH 26, WCW Nitro,
   Lucha Underground, RAW 11, DoN 25, Forbidden Door 25, Full Gear 25, No Mercy 07, SummerSlam 11,
   Troops 09, Unforgiven 2007, Worlds End 25, WrestleDream 25, SNME 46, unnamed card.)
4. Do NOT run Game setup. Bake once (output TITAVUSREVATCHCARD). Keep only the newest
   TITAVUSREVATCHCARD cak in mods.
5. Restart WWE. Dynamite/Collision first (known good), then the others.
If the game crashes at launch, put your backup CAK back and tell me.
