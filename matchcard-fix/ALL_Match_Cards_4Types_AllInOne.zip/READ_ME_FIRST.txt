ALL MATCH CARDS - ALL IN ONE v2 (159 cards)
Moving portraits: one-on-one, 2 vs 2, triple threat, fatal four-way. Every card <= 16 movies.
Original plugin only - the capacity add-on must NOT be in Plugins.
Studio match_card_types.txt must list only: 1on1, 2on2, triple_threat, fatal_4way.

1. Close WWE. Back up your working CAK and discovery_data\UI and Arena folders.
2. Extract into discovery_data (the folder that contains UI and Arena). Choose Replace.
   UI\Projects\ShowAssets\matchups\ now also has: WrestleMania 22, Cyber Sunday 08, Extreme Rules 11,
   Judgment Day 06, MITB 2011, SummerSlam 09/11, No Mercy 07, Troops 09, Unforgiven 2007, RAW 11.
3. "Put in its original folder" (13 cards): move each back to where its original came from:
   Lucha_Underground.jsfb
   allin18/MatchUp.jsfb
   matchup_075_WCWNITRO_00.jsfb
   matchup_All_Out_25.jsfb
   matchup_DoN_25.jsfb
   matchup_Forbidden_Door_25.jsfb
   matchup_Full_Gear_25.jsfb
   matchup_ROH_26.jsfb
   matchup_Worlds_End_25.jsfb
   matchup_WrestleDream_25.jsfb
   matchup_allout_19.jsfb
   snme46matchup.jsfb
   unnamed card from UIFIXES/matchup.jsfb
4. Do NOT run Game setup. Bake once (output TITAVUSREVATCHCARD). Keep only the newest one in mods.
5. Restart WWE.
