One-on-one, 2 vs 2, triple threat, fatal four-way moving (under the 16-movie limit).
Replace each original file with the one here, same name, same folder it came from.
(allin18/MatchUp.jsfb and matchup_ROH_26.jsfb). Then bake once and restart WWE.
