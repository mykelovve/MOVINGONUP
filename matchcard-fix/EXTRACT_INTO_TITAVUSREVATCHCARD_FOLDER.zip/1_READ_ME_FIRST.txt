YOUR BAKE FOLDER IS:  ...\WWE 2K26\discovery\TITAVUSREVATCHCARD

PROBLEM: Arena is inside UI there (TITAVUSREVATCHCARD\UI\Arena). The bake then stores the AEW cards as
"UI/Arena/...", but the game looks for "Arena/...". So Redemption & co. never change.

FIX
1. Close WWE. Back up your current TITAVUSREVATCHCARD .cak.
2. DELETE the wrong folder:  ...\discovery\TITAVUSREVATCHCARD\UI\Arena
3. Extract THIS zip into:     ...\discovery\TITAVUSREVATCHCARD     (choose Replace)
   Result - Arena NEXT TO UI:
     TITAVUSREVATCHCARD\
        UI\Projects\...         (Dynamite, Collision, AAA, matchups...)
        Arena\Titavius\808_-_AEW_Redemption_2026\Interface\Matchup\matchup_redemption_26.jsfb
        Arena\Titavius\803 Revolution / 805 Dynasty / 807 Forbidden Door
        Arena\Rev's_Arenas\SUMMERSLAM_2026\Data\matchup.jsfb
        Arena\Rev's_Arenas\NIGHT_OF_CHAMPIONS_2026\Data\matchup.jsfb
   CHECK: TITAVUSREVATCHCARD\Arena exists and TITAVUSREVATCHCARD\UI\Arena does NOT.
4. Bake with your usual TITAVUSREVATCHCARD entry (input = the TITAVUSREVATCHCARD folder, the one that
   CONTAINS UI and Arena - not UI itself).
5. mods: keep only the newest TITAVUSREVATCHCARD .cak. Restart WWE.
6. Test Dynamite (known good), then Redemption.

All cards here: one-on-one, 2 vs 2, triple threat, fatal four-way; every card <= 16 movies.
