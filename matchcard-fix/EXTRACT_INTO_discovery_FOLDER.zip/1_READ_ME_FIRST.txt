WHERE TO EXTRACT  (one place only)
=================================
Extract this zip into:

   C:\Program Files (x86)\Steam\steamapps\common\WWE 2K26\discovery

(the folder that CONTAINS discovery_data - NOT inside discovery_data, NOT inside UI).
When Windows asks, choose "Replace the files in the destination".

It merges into your existing folders like this:

   discovery\
     discovery_data\
        UI\Projects\...                      <- 130+ cards incl. Dynamite, Collision, AAA, matchups\
        Arena\                                <- NEXT TO UI (not inside it)
           Titavius\808_-_AEW_Redemption_2026\Interface\Matchup\matchup_redemption_26.jsfb
           Titavius\803_-_AEW_Revolution_2026\...   805 Dynasty   807 Forbidden Door
           Rev's_Arenas\SUMMERSLAM_2026\Data\matchup.jsfb
           Rev's_Arenas\NIGHT_OF_CHAMPIONS_2026\Data\matchup.jsfb
     NOT_FOR_GAME_put_these_by_hand\         <- the game ignores this folder (see below)

CHECK AFTER EXTRACTING
  This file must exist:
  ...\discovery\discovery_data\Arena\Titavius\808_-_AEW_Redemption_2026\Interface\Matchup\matchup_redemption_26.jsfb
  If you instead see discovery_data\discovery_data\... or UI\Arena\..., you extracted one level too deep.

ANY OTHER FOLDER WITH Assets + Projects (e.g. a "Titavius" folder holding Assets/Projects):
  That is an old BakeMe-style test folder, not where the game reads cards. Leave it out of the bake
  (move it to your Desktop if it sits inside discovery_data).

THEN
  1. Studio: match_card_types.txt = 1on1 / 2on2 / triple_threat / fatal_4way   (no plugin_limit line)
  2. Studio: Match cards... -> Run game setup -> wait -> Check again (0 need repair)
  3. Discovery: bake the WHOLE discovery_data folder (so Arena is included), output TITAVUSREVATCHCARD
  4. mods: keep only the newest TITAVUSREVATCHCARD .cak
  5. Restart WWE. Test Dynamite (known good), then Redemption.

NOT_FOR_GAME_put_these_by_hand (15 cards I have no folder path for):
  Run game setup usually finds these on its own. Only if one arena still shows the default render,
  copy its file over the original in that arena's folder. Then you can delete this folder.
  Lucha_Underground.jsfb
  allin18/MatchUp.jsfb
  matchup_075_WCWNITRO_00.jsfb
  matchup_All_Out_25.jsfb
  matchup_DoN_25.jsfb
  matchup_Forbidden_Door_25.jsfb
  matchup_Full_Gear_25.jsfb
  matchup_ROH_26.jsfb
  matchup_Worlds_End_25.jsfb
  matchup_WrestleDream_25.jsfb
  matchup_allout_19.jsfb
  snme46matchup.jsfb
  unnamed card from UIFIXES/matchup.jsfb
  GrandSlamMX_26.jsfb
  matchup_spring_break_x.jsfb
