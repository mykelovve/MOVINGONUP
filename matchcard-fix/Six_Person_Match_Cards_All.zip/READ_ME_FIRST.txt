SIX-PERSON MATCH CARDS - all 25 cards
=====================================
Moving portraits ONLY for the two six-person match types:
  - six-person free-for-all (6man)
  - 3 vs 3 tag (3on3)
That's 12 clips per card, under the plugin's 16-movie limit.
Every other match type (including one-on-one) shows the normal still photo.

Want triple-threat tag or 1 vs 5 (also six people) instead of one of these? Tell me.
Only two six-person types fit on a card at once.

INSTALL (same as before)
  1. Back up your working CAK and the original card files.
  2. Extract into the folder that CONTAINS your UI and Arena folders. Choose Replace.
  3. Move each file in "Put in its original folder" back to the folder its original
     came from (same name), then delete that helper folder.
  4. Do NOT run Game setup. Bake once with your usual input. Restart WWE.
  5. Test a 6-person match or a 3 vs 3 tag on Dynamite first (known path).
