WORKING MATCH CARDS - every card you sent
==========================================
Moving portraits on every card: 1-on-1, 2 vs 2, triple threat, fatal four-way.
This is the recipe confirmed in-game on Dynamite and Collision.
Other match types show the normal photo. Every card stays under the
plugin's 16-movie limit.

FILES
  UI/Projects/ShowAssets/matchup/AEW_Dynamite_2026.jsfb    (confirmed working)
  UI/Projects/ShowAssets/matchup/AEW_Collision_2026.jsfb   (confirmed working)
  Arena/Rev's_Arenas/SUMMERSLAM_2026/Data/matchup.jsfb     (not tested in game yet)
  AllOut19 - put in its original folder/matchup_allout_19.jsfb  (not tested in game yet)

INSTALL
  1. Back up your working CAK and the four original files.
  2. Extract into the folder that CONTAINS your UI and Arena folders. Choose Replace.
  3. Move matchup_allout_19.jsfb from the "AllOut19 - put in its original folder"
     folder into the folder your original came from (same name), then delete that
     helper folder.
  4. Do NOT run Game setup.
  5. Bake once with your usual input and entry/output filename. Don't bake the whole
     Discovery data folder or the "Gorilla Studio Layout Backups" folder.
  6. Restart WWE.

IF THE GAME CRASHES AT LAUNCH
  Put your backup CAK back. Earlier, a SummerSlam test crashed at launch for an
  unknown reason. If that happens again, rebake without the SummerSlam file
  (Dynamite/Collision/All Out only) and tell me.
