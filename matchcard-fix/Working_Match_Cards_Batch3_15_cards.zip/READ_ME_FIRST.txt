WORKING MATCH CARDS v3 - every card you have sent (25)
=====================================================
Moving portraits on every card: 1-on-1, 2 vs 2, triple threat, fatal four-way.
This is the recipe confirmed in-game on Dynamite and Collision. Other match types
show the normal photo. Every card stays under the plugin's 16-movie limit.

CARDS
  UI/Projects/ShowAssets/matchup/AEW_Dynamite_2026.jsfb             confirmed working
  UI/Projects/ShowAssets/matchup/AEW_Collision_2026.jsfb            confirmed working
  Arena/Rev's_Arenas/SUMMERSLAM_2026/Data/matchup.jsfb              not tested yet (*1)
  Arena/Titavius/803_-_AEW_Revolution_2026/.../matchup_aewrevolution_26.jsfb      not tested yet (*2)
  Arena/Titavius/805_-_AEW_Dynasty_2026/.../matchup_aewdynasty_26.jsfb            not tested yet (*3)
  Arena/Titavius/807_-_AEW_Forbidden_Door_2026/.../matchup_aewforbiddendoor_26.jsfb  not tested yet
  Arena/Titavius/808_-_AEW_Redemption_2026/.../matchup_redemption_26.jsfb         not tested yet
  Put in its original folder/matchup_allout_19.jsfb                 not tested yet
  Put in its original folder/matchup_075_WCWNITRO_00.jsfb           not tested yet
  Put in its original folder/unnamed card from UIFIXES/matchup.jsfb not tested yet
  Put in its original folder/ - 15 more from the latest UIFIXES:
    Lucha_Underground, matchup_0464_RAW_11, matchup_All_Out_25, matchup_DoN_25,
    matchup_Forbidden_Door_25, matchup_Full_Gear_25, matchup_NOMERCY07, matchup_ROH_26,
    matchup_SUMMERSLAM_09, matchup_summerslam11, matchup_Troops09, matchup_Unforgiven2007,
    matchup_Worlds_End_25, matchup_WrestleDream_25, snme46matchup   (all not tested yet)
  (SSmatchup.jsfb from UIFIXES is byte-identical to the SummerSlam card, so it's covered above.)

INSTALL
  1. Back up your working CAK and the original card files.
  2. Extract into the folder that CONTAINS your UI and Arena folders. Choose Replace.
  3. Move each file in "Put in its original folder" back to the folder its original
     came from (same name). Then delete the "Put in its original folder" folder.
  4. Do NOT run Game setup.
  5. Bake once with your usual input and entry/output filename. Don't bake the whole
     Discovery data folder or the "Gorilla Studio Layout Backups" folder.
  6. Restart WWE.

SAFEST WAY: add a few at a time. Dynamite + Collision are known good. Add the
others in small groups so that if something breaks, you know which card did it.

NOTES
  *1 An earlier SummerSlam test crashed WWE at launch, cause unknown. If the game
     crashes at launch, put your backup CAK back and rebake without SummerSlam.
  *2 Earlier Revolution tests failed to load. Those used much bigger cards; this one
     is under the limit, but test it on its own.
  *3 Earlier notes found Dynasty (805), Double or Nothing (806) and ROH Supercard (804)
     missing their card record in the show table. If Dynasty still shows the plain
     card, the card link needs repair (Studio's arena-link checker).
