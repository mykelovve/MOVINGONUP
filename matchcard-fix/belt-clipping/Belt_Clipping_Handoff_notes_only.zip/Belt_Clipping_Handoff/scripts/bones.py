import sys; sys.path.insert(0, sys.argv[1])
import gorilla_mcd as g, numpy as np
def load(p):
    m = g.Model(p); out = {}
    for b in m.bones:
        out[b['name']] = b
    return m, out
mk, ko = load(sys.argv[2]); mb, br = load(sys.argv[3])
print("bone keys:", list(next(iter(ko.values())).keys()))
print("in KO not Brock:", [n for n in ko if n not in br])
print("in Brock not KO:", [n for n in br if n not in ko])
for n in ko:
    if any(t in n.lower() for t in ('belt','waist','spine','pelvis','hip','root')):
        a = ko[n]; b = br.get(n)
        def pos(x):
            for k in ('head','pos','world','position','translation'):
                if k in x: return np.round(np.asarray(x[k]).ravel()[:3],2)
            return None
        print("%-18s KO %s  Brock %s" % (n, pos(a), pos(b) if b else 'MISSING'))
