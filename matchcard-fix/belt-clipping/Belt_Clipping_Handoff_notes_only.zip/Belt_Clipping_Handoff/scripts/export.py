import sys, struct, json; sys.path.insert(0, sys.argv[1])
import gorilla_mcd as g, numpy as np
path, out = sys.argv[2], sys.argv[3]
m = g.Model(path); b = open(path, 'rb').read(); names = list(m.names)
doc = {"file": path.split('scratchpad/')[1], "version": m.version,
       "sections": {k: {"offset": v[0], "size": v[1]} for k, v in m.sections.items()},
       "bones": [{"index": i, "name": x['name'], "parent": x['parent'],
                  "world_matrix": np.round(np.asarray(x['world']), 5).tolist()} for i, x in enumerate(m.bones)],
       "render_meshes": [], "names_table": names}
for x in m.meshes:
    p = np.asarray(x['position']) if 'position' in x else None
    doc["render_meshes"].append({"name": x['name'], "verts": int(x['verts']),
        "bbox_min": None if p is None else np.round(p.min(0), 3).tolist(),
        "bbox_max": None if p is None else np.round(p.max(0), 3).tolist()})
if 'GtPt' in m.sections:
    off, size = m.sections['GtPt']; cnt = struct.unpack_from('<I', b, off)[0]
    doc["GtPt_face_anchor_points"] = [dict(zip(("name", "group", "slot", "vertex"),
        (names[a], names[c], s, v))) for a, c, s, v in (struct.unpack_from('<4H', b, off + 4 + 8*k) for k in range(cnt))]
if 'AtPt' in m.sections:
    off, size = m.sections['AtPt']; cnt = struct.unpack_from('<I', b, off)[0]; rows = []
    for k in range(cnt):
        a, c, w, x, y, z, tail = struct.unpack_from('<HHI3fI', b, off + 4 + 24*k)
        rows.append({"u16_a": a, "u16_b": c, "u32_c": w,
                     "u32_c_as_bone": m.bones[w]['name'] if w < len(m.bones) else None,
                     "xyz": [round(x, 4), round(y, 4), round(z, 4)], "tail_hex": "%08x" % tail})
    doc["AtPt_attach_points_raw"] = {"count": cnt, "record_layout_guess": "u16,u16,u32,float3,u32 (24 bytes)", "records": rows}
json.dump(doc, open(out, 'w'), indent=1)
print(out, len(doc["bones"]), "bones", list(doc["sections"]))
