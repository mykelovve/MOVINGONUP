import sys, struct; sys.path.insert(0, sys.argv[1])
import gorilla_mcd as g
for path in sys.argv[2:]:
    m = g.Model(path); n = list(m.names); b = open(path,'rb').read()
    print("==", path.split('scratchpad/')[1].split('/')[0], "bones", len(m.bones), "names", len(n))
    print("  names 170-205:", [(i, n[i]) for i in range(170, min(205, len(n)))])
    if 'GtPt' in m.sections:
        off, size = m.sections['GtPt']; cnt = struct.unpack_from('<I', b, off)[0]
        for k in range(cnt):
            a, c, s, v = struct.unpack_from('<4H', b, off + 4 + 8*k)
            print("   ap %2d: name %-14s group %-10s vertex %d" % (s, n[a], n[c], v))
