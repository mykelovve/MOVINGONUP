import sys; sys.path.insert(0, sys.argv[1])
import gorilla_mcd as g
m = g.Model(sys.argv[2]); b = open(sys.argv[2],'rb').read()
s = m.sections
print(type(s))
items = s.items() if isinstance(s, dict) else enumerate(s)
for k, v in items: print(k, v if len(str(v)) < 300 else str(v)[:300])
for key in (b'belt_APs', b'belt_dyn_APs', b'body_limit_APs', b'APs'):
    i = b.find(key); print(key, i)
