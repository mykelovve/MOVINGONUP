MOVING HAIR - test version 1
============================
Makes long hair (bone chains named Hair_..., e.g. Roman Reigns) swing, lag behind the head and settle
while a render plays. Body animation is untouched. Nothing on disk in your character folders changes.

INSTALL
 1. Close Gorilla Studio.
 2. Open your Studio folder (the one with GorillaStudio.exe) -> engine folder.
 3. Rename engine\gr_render.py to gr_render.py.old  (backup)
 4. Copy engine\gr_render.py and engine\hair_motion.cfg from this zip into that engine folder.
 5. Open Studio.

TEST
 Roman Reigns + any taunt with head/body movement -> Preview (or MAKE).
 Watch his hair: it should swing a little behind his head and settle.

TUNE (no reinstall needed - just edit engine\hair_motion.cfg in Notepad and Preview again)
 Too floppy / wild      -> stiffness 0.2   and/or damping 0.75
 Too stiff / no movement -> stiffness 0.06  and/or damping 0.9
 Hair droops too much   -> gravity 0
 Turn it off            -> enabled 0   (or delete hair_motion.cfg)

IF A RENDER FAILS
 Delete engine\gr_render.py, rename gr_render.py.old back. Send me the render's error text.
 (The hair step is written so a hair error skips the effect for that frame instead of failing the render.)

Tested here on a simulated rig only - Blender with your models hasn't been run yet.
