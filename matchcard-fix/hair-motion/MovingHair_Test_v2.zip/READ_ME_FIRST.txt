MOVING HAIR - test version 2
============================
FIX: in version 1 the hair could be simulated only once per render. If the renderer poses the
body for each picture without changing the scene's frame number, v1 treated every picture as
"the same frame" and the hair never moved. v2 advances the hair once for EVERY rendered picture
(and still once per frame when the frame number does change). Hair names are matched without
caring about capital letters.

NEW: after each render it writes  engine\hair_motion_report.txt  - how many hair bones it found,
how many pictures it simulated, and how far the hair swung. If hair still doesn't move, send me
that file.

INSTALL
 1. Close Gorilla Studio.
 2. Studio folder -> engine folder. Rename engine\gr_render.py to gr_render.py.old (backup).
    (If you installed v1, its gr_render.py is the one being replaced - that's fine.)
 3. Copy engine\gr_render.py and engine\hair_motion.cfg from this zip into that engine folder.
 4. Open Studio. Preview Roman Reigns with a taunt that moves his head.
    (Taunt previews re-render once because the renderer file changed.)

TUNE (edit engine\hair_motion.cfg in Notepad, Preview again)
 More swing / looser  -> stiffness 0.06   damping 0.9
 Too floppy / wild    -> stiffness 0.2    damping 0.75
 Hair droops          -> gravity 0
 Off                  -> enabled 0

IF A RENDER FAILS: put gr_render.py.old back and send me the render error text.
Tested on a simulated rig (including "frame number never changes"); not yet with Blender + your models.
