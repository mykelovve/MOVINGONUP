MOVING HAIR - test version 3
============================
FIX for "hair goes all over the place" (v2): hair could swing too far, and on long strands every
segment added its own swing to the one before it, so a strand could curl right up.
v3 adds a swing LIMIT measured against the strand's normal hanging shape: no part of any strand
can point more than max_angle (default 20 degrees) away from where it normally hangs, however
hard the head moves. Defaults are also calmer (stiffness 0.2, damping 0.8, gravity 0.02).
Still advances on every rendered picture (v2 fix) and writes engine\hair_motion_report.txt.

INSTALL (replaces v1/v2)
 1. Close Gorilla Studio.
 2. Copy engine\gr_render.py and engine\hair_motion.cfg from this zip into your Studio engine
    folder (replace). Keep your gr_render.py.old backup from before.
 3. Open Studio, Preview Roman Reigns with a taunt that moves his head.

TUNE (engine\hair_motion.cfg in Notepad, then Preview again)
 Still too wild     -> max_angle 10
 Too little motion  -> max_angle 30   and/or stiffness 0.12
 Off                -> enabled 0

If it looks wrong, send me a screenshot + engine\hair_motion_report.txt.
Tested on a simulated rig with violent head shaking; not yet with Blender + your models.
