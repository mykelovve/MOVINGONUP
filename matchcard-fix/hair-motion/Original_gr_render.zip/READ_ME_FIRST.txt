ORIGINAL STUDIO RENDERER (from MAKE-A-RENDER-READER_Source_Publishing.zip)
This is gr_render.py exactly as Studio shipped it - no moving hair.
Copy engine\gr_render.py into your Studio engine folder (replace) to undo the hair test.
You can also delete engine\hair_motion.cfg and engine\hair_motion_report.txt.
