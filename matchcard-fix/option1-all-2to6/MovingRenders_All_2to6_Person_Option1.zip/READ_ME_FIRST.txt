OPTION 1 - EVERY 2-TO-6-PERSON MATCH TYPE MOVING
================================================
Moving portraits for all 13 normal match types with 2 to 6 people:
  one-on-one, triple threat, 1 vs 2, fatal four-way, 2 vs 2, 1 vs 3,
  five-person, 2 vs 3, 1 vs 4, six-person, 3 vs 3, triple-threat tag, 1 vs 5
That's 59 portrait clips per card. The original plugin only holds 16 movies, so
this ships with the capacity add-on, which raises that to 120.

WHAT'S IN HERE
  Plugins\WWE2K26_MatchCardCapacity.dlp + .cfg   capacity add-on (16 -> 120)
  Studio\GorillaStudio.NameFolders.dll          Gorilla Studio helper 1.7.28
  Studio\match_card_types.txt                   all 13 match types + "plugin_limit 120"
  Studio\presets\                               no-add-on fallbacks

INSTALL
  1. Close WWE 2K26 and Gorilla Studio. Back up your working CAK.
  2. Copy BOTH files from Plugins\ into
       C:\Program Files (x86)\Steam\steamapps\common\WWE 2K26\Plugins
     next to WWE2K26_MovingRenders.dlp. Keep the original plugin. Don't rename anything.
  3. In your Gorilla Studio folder, rename GorillaStudio.NameFolders.dll to
     GorillaStudio.NameFolders.dll.old. Copy in the new DLL and match_card_types.txt.
  4. Open Studio. The red badge at the top should say v1.7.28.
  5. Match cards... -> Check again. It should list the 13 match types and say
     "Plugin movie limit: 120".
  6. Press Run game setup. Then Check again: "need repair" should be gone.
  7. Bake ONCE in Discovery with your usual input/entry/output filename.
     (Not the whole discovery_data folder, not "Gorilla Studio Layout Backups".)
  8. Restart WWE. Then open Plugins\WWE2K26_MatchCardCapacity.log. It must say:
       ACTIVE: match-card contexts expanded from 16 to 120
     If it doesn't, the add-on didn't switch on and every card will stay still.
  9. Test a one-on-one, then a six-person match.

IF YOU SEE GREEN/PINK PORTRAITS, A LOADING STALL, OR A CRASH
  1. Close WWE. Move WWE2K26_MatchCardCapacity.dlp and .cfg out of Plugins.
  2. In Studio, replace match_card_types.txt with presets\confirmed_no_addon.txt
     (renamed to match_card_types.txt). Run game setup, bake once.
  3. Send me both logs:
       Plugins\WWE2K26_MovingRenders.log and Plugins\WWE2K26_MatchCardCapacity.log
  That puts you back on the known-working setup, and tells me what to fix in option 2.

The add-on changes nothing on disk: it only patches the original plugin in memory
while the game runs. Removing it restores the original 16-movie behaviour.
