MATCH-CARD SLOT RELEASE FIX (test add-on)
=========================================
Why: MovingRenders 4.21 never frees a match card's movie slots when the card closes.
After a card or two, its table is full of dead entries, new portraits aren't tracked,
and you get the DEFAULT render on the match card. This happens with or without the
capacity add-on (it just fills 16 or 120 slots).

What it does: when the game closes a match-card movie, this add-on frees that slot,
then lets the plugin close it as normal. It writes Plugins\WWE2K26_MatchCardRelease.log.
Nothing on disk is changed; remove the two files to undo it.

INSTALL (game closed)
  Copy WWE2K26_MatchCardRelease.dlp and WWE2K26_MatchCardRelease.cfg into
    C:\Program Files (x86)\Steam\steamapps\common\WWE 2K26\Plugins
  next to WWE2K26_MovingRenders.dlp. Keep everything else (including the capacity add-on).

TEST
  1. Start WWE, open a match card, back out, open another card (different match type),
     then a third. Note which cards move and which show the default render.
  2. Close WWE and send me Plugins\WWE2K26_MatchCardRelease.log
     (plus WWE2K26_MovingRenders.log and WWE2K26_MatchCardCapacity.log).
  The log should start with "ACTIVE". If it says anything else, it switched itself off safely.

IF THE GAME CRASHES
  Close WWE, move the two WWE2K26_MatchCardRelease files out of Plugins, and send me the log.

Not run on Windows or in WWE yet - this is a test build.
