GORILLA RENDERER FIXES - test 5  (one gr_render.py with everything)
==================================================================
NEW: BODY HAIR NO LONGER SHOWS AS WHITE PATCHES (all wrestlers, automatic)
 Body hair (the "combinations" mesh: chest/arm/leg hair), beards, goatees and similar are drawn
 as many small "hair cards". The engine only cuts the strand shapes out of meshes named in its
 hair setting; the others rendered every card as a SOLID patch - the pale blotches you saw on
 Kevin Owens' shirt and pants (exactly where his body hair grows).
 This renderer now cuts the strands out of any such mesh using the coverage stored in its own
 hair texture (the green channel of *_rai.dds), the same way the engine's hair material does.
 Meshes that already have a cut-out, bodies and clothing are not touched.

ALSO INCLUDED: moving hair v4 (swing limit, no eye side effects). Turn hair off with
 enabled 0 in engine\hair_motion.cfg - the body hair fix stays on either way.

INSTALL
 1. Close Gorilla Studio.
 2. Copy engine\gr_render.py and engine\hair_motion.cfg into your Studio engine folder (replace).
    (Original_gr_render.zip undoes everything.)
 3. Preview Kevin Owens. Shirt and pants should be black; body hair shows as fine strands only.

Tested here with a model of Blender's material nodes; not yet in Blender with your models.
If something looks wrong, send a screenshot and the render log lines starting with "hair coverage".
