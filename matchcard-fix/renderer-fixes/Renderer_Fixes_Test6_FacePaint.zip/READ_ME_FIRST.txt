GORILLA RENDERER FIXES - test 6  (one gr_render.py with everything)
==================================================================
NEW: FACE PAINT STAYS ON IN MOVING RENDERS (automatic, every wrestler)
 Studio's renderer only gave the head its plain head_color texture, so face paint
 shipped with a character never reached the render and the face came out clean.
 Before every rendered frame, this renderer now looks next to the wrestler's head
 textures (selected attire first, then BaseModel) and:
  - lays a face paint layer over the face by its own transparency. That means any
    texture named with paint / facepaint / makeup / warpaint / decal, or a
    hash-named texture that the head material (head.jmtl) points to.
  - uses the attire's own head_color.dds when the attire ships a different
    (painted) head than the BaseModel.
 Normal maps, masks, flush/wrinkle maps and clothing textures are never used as
 paint. Wrestlers without paint render exactly as before.

 Each render writes engine\face_paint_report.txt: which character, what paint it
 found, and what it did ("paint layer applied over the head ...", or "no face paint
 layer next to this character's head textures").

ALSO INCLUDED: test 5 (body hair no longer white patches) and moving hair v4
 (turn hair off with enabled 0 in engine\hair_motion.cfg).

INSTALL
 1. Close Gorilla Studio.
 2. Copy engine\gr_render.py and engine\hair_motion.cfg into your Studio engine
    folder (replace). Keep your old gr_render.py as gr_render.py.old to undo.
 3. Preview or MAKE a wrestler with face paint. Taunt previews re-render once
    because the renderer file changed.

IF THE PAINT STILL DOESN'T SHOW
 Send me engine\face_paint_report.txt and a screenshot of that wrestler's
 Textures folders (BaseModel and the attire). If it says "no face paint layer",
 his paint isn't in his character folder (the Jeff Hardy folder you sent earlier
 had none), and I need to know where that mod keeps it.

Tested here with a model of Blender's material nodes and with your Jeff Hardy,
Kevin Owens and Brock Lesnar folders (no false paint picked up); not yet in
Blender with a painted wrestler.
