SUMMERSLAM 09 [ID 9] - the card Game setup reported as "project not found"

The game looks for it at:
  UI/Projects/ShowAssets/matchups/matchup_SUMMERSLAM_09.jsfb
(confirmed: that path's hash is 69D86CA276340FE0, the exact reference in your report)

This is your ORIGINAL card, unchanged. Extract this zip into your discovery_data folder
(the folder that contains UI), so the file lands at the path above. Then Run game setup:
it will find it and add the six-person layers itself, like every other card.
