TEST BAKE - DYNAMITE + COLLISION ONLY
Purpose: find out whether the big bake is being skipped. This bake has only the two cards that
always worked (Dynamite, Collision) plus the placeholder movies - like your first working bake.

1. Close WWE and Discovery.
2. In ...\WWE 2K26\discovery\ rename the current TITAVUSREVATCHCARD folder to TITAVUSREVATCHCARD_big
3. Copy the TITAVUSREVATCHCARD folder from this zip into ...\WWE 2K26\discovery\
4. In mods: move EVERY TITAVUSREVATCHCARD*.cak out (to your Desktop).
5. Bake TITAVUSREVATCHCARD once. Note the size of the new .cak in mods.
6. Start WWE, 1on1 on Dynamite.

RESULT
 - Dynamite MOVES  -> the big bake is the problem (too big, or one bad file). Tell me; I'll split it
                      into smaller bakes that each stay working.
 - Dynamite STILL STILL -> something outside our bake overrides the cards (another mod .cak or
                      CakeHook not loading it). Send me a screenshot of mods sorted by Date modified.
Afterwards: rename TITAVUSREVATCHCARD_big back if you want it.
