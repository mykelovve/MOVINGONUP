TEST - 6-PERSON MOVING RENDERS (DYNAMITE ONLY)
This Dynamite card has: 1on1, 2on2, triple threat, fatal 4-way  +  6-man tag (3 vs 3)  +  6-pack challenge.
That is 25 render slots (+2 Dynamite background movies) on one card. Plugin 4.21 froze with big cards;
4.23 skips renders of other match sizes, so it may handle this. This test tells us.

1. Close WWE. Make sure revap_plug.dlp / revap_studio.dlp stay renamed to .off.
2. Copy the TITAVUSREVATCHCARD folder from this zip into ...\WWE 2K26\discovery\ (choose Replace).
   It only replaces the Dynamite card; your other cards stay.
3. Bake TITAVUSREVATCHCARD, keep only the newest TITAVUSREVATCHCARD .cak in mods, restart WWE.
4. On Dynamite test, in this order:
     a) 1on1           -> should still move
     b) 6-man tag (3v3)
     c) 6-pack challenge
     d) another 1on1 on a different arena afterwards
5. Tell me what moved, and whether anything froze or went black. Send _status.txt.

IF THE GAME FREEZES on the Dynamite match card: close WWE, put your previous TITAVUSREVATCHCARD
.cak back in mods (or re-run Install_All_Match_Cards.ps1 and bake) - that undoes this test.
